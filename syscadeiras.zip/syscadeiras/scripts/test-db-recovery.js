#!/usr/bin/env node
// ============================================
// test-db-recovery.js — SysCadeiras
// ============================================
// Simula, de ponta a ponta, o cenário que mais assusta quem opera este
// tipo de sistema: "o banco corrompeu/sumiu, o backup realmente salva?".
//
// Passos:
//   1. Cria um banco novo com alguns registros de exemplo.
//   2. Faz um backup (.db) com o BackupManager, do jeito que o app faz.
//   3. Simula perda total do banco (apaga o arquivo).
//   4. Restaura a partir do backup.
//   5. Confere que os dados voltaram exatamente iguais.
//   6. Confere que a restauração deixou uma cópia de segurança do estado
//      anterior (.antes-restaurar.bak) — mesmo quando o "antes" já estava
//      corrompido, para nunca destruir a única pista de o que deu errado.
//   7. Testa o caminho alternativo de recuperação: exportar para JSON e
//      reimportar (útil quando o .db em si está corrompido demais para
//      abrir, mas foi possível extrair um JSON antes disso acontecer).
//
// Uso:  npm run test:recovery
// Sai com código 0 se tudo passar, 1 se algo falhar (apropriado para rodar
// em CI — ver .github/workflows/ci.yml).
// ============================================

const fs = require('fs');
const path = require('path');
const os = require('os');
const assert = require('node:assert/strict');
const Module = require('module');

// Mock do módulo 'electron' — mesmo padrão usado em tests/_setupElectronMock.js
const pastaTemporaria = fs.mkdtempSync(path.join(os.tmpdir(), 'syscadeiras-recovery-'));
const originalLoad = Module._load;
Module._load = function (request, parent, isMain) {
    if (request === 'electron') {
        return { app: { getPath: () => pastaTemporaria, getVersion: () => '0.0.0-test', isPackaged: false } };
    }
    return originalLoad.apply(this, arguments);
};

const Database = require('../src/main/services/database');
const BackupManager = require('../src/main/services/backup');

let falhas = 0;
async function passo(nome, fn) {
    process.stdout.write(`→ ${nome}... `);
    try {
        await fn();
        console.log('OK');
    } catch (e) {
        falhas++;
        console.log('FALHOU');
        console.error(`   ${e.message}`);
    }
}

async function main() {
    console.log(`📁 Ambiente de teste isolado: ${pastaTemporaria}\n`);

    const pastaBackup = fs.mkdtempSync(path.join(os.tmpdir(), 'syscadeiras-recovery-backup-'));
    let db, backupManager, backupInfo, idPecaCriada;

    await passo('Criar banco e popular com dados de exemplo', async () => {
        db = new Database();
        await db.init();
        const r = await db.run(`INSERT INTO Pecas (nome, ativo) VALUES ('Armação Teste Recovery', 1)`);
        idPecaCriada = r.lastID;
        await db.run(`INSERT INTO Cores (nome) VALUES ('Preto Teste Recovery')`);
        await db.run(`INSERT INTO Funcionarios (nome, ativo) VALUES ('Funcionário Teste Recovery', 1)`);
    });

    await passo('Criar backup (.db)', async () => {
        backupManager = new BackupManager();
        await backupManager.init();
        backupInfo = await backupManager.criarBackup(pastaBackup);
        assert.equal(backupInfo.success, true, backupInfo.error);
        assert.ok(fs.existsSync(backupInfo.caminho), 'arquivo de backup deveria existir em disco');
    });

    await passo('Simular perda total do banco (apagar o arquivo .db)', async () => {
        db.close();
        fs.unlinkSync(db.dbPath);
        assert.ok(!fs.existsSync(db.dbPath));
    });

    await passo('Restaurar a partir do backup', async () => {
        const r = await backupManager.restaurarBackup(backupInfo.caminho);
        assert.equal(r.success, true, r.error);
        assert.ok(fs.existsSync(db.dbPath), 'banco deveria existir de novo após restaurar');
    });

    await passo('Confirmar que os dados voltaram intactos', async () => {
        const db2 = new Database();
        await db2.init();
        const peca = await db2.get(`SELECT * FROM Pecas WHERE id = ?`, [idPecaCriada]);
        assert.ok(peca, 'peça de teste deveria existir após restauração');
        assert.equal(peca.nome, 'Armação Teste Recovery');
        assert.ok(peca.uuid, 'uuid deveria continuar preenchido após restauração');
        const cores = await db2.all(`SELECT * FROM Cores WHERE nome = 'Preto Teste Recovery'`);
        assert.equal(cores.length, 1);
        db2.close();
    });

    await passo('Confirmar que a restauração guardou uma cópia de segurança do estado anterior', async () => {
        const seguranca = db.dbPath + '.antes-restaurar.bak';
        assert.ok(fs.existsSync(seguranca), 'arquivo .antes-restaurar.bak deveria ter sido criado');
    });

    await passo('Exportar para JSON e reimportar (caminho alternativo de recuperação)', async () => {
        const pastaExport = fs.mkdtempSync(path.join(os.tmpdir(), 'syscadeiras-recovery-export-'));
        const exportado = await backupManager.exportarJSON(pastaExport);
        assert.equal(exportado.success, true, exportado.error);
        assert.ok(exportado.totalRegistros > 0);

        // Simula perda total de novo, agora recuperando via JSON em vez do .db
        const db3 = new Database();
        await db3.init();
        db3.close();
        fs.unlinkSync(db3.dbPath);

        const importado = await backupManager.importarJSON(exportado.caminho, true);
        assert.equal(importado.success, true, importado.error);

        const db4 = new Database();
        await db4.init();
        const peca = await db4.get(`SELECT * FROM Pecas WHERE nome = 'Armação Teste Recovery'`);
        assert.ok(peca, 'peça de teste deveria existir após reimportação do JSON');
        db4.close();
    });

    console.log('');
    if (falhas > 0) {
        console.error(`❌ ${falhas} passo(s) falharam.`);
        process.exit(1);
    } else {
        console.log('✅ Recuperação de banco validada: backup/restore e export/import JSON funcionam de ponta a ponta.');
        process.exit(0);
    }
}

main().catch(e => {
    console.error('❌ Erro inesperado no teste de recuperação:', e);
    process.exit(1);
});

/**
 * dashboard.js
 * Dashboard e gráficos
 * (Extraído de script.js, linhas 3549-4229 do arquivo original)
 */

// ============================================
// FUNÇÕES DO DASHBOARD
// ============================================

async function mostrarEstatisticas() {
    const modal = document.getElementById('modalEstatisticas');
    const conteudo = document.getElementById('estatisticasConteudo');
    
    try {
        const stats = await calcularEstatisticasDashboard();
        
        let html = `
            <div class="periodo-selector">
                <button class="periodo-btn active" onclick="atualizarDashboard('7dias', event)">7 Dias</button>
                <button class="periodo-btn" onclick="atualizarDashboard('30dias', event)">30 Dias</button>
                <button class="periodo-btn" onclick="atualizarDashboard('mesAtual', event)">Mês Atual</button>
                <button class="periodo-btn" onclick="atualizarDashboard('personalizado', event)">Personalizado</button>
            </div>
            
            <div id="dataRangePersonalizado" style="display: none;" class="data-range">
                <input type="date" id="dataInicioDash" class="form-control" value="${stats.ultimos7Dias.inicio}">
                <input type="date" id="dataFimDash" class="form-control" value="${stats.ultimos7Dias.fim}">
                <button class="btn-primary" onclick="aplicarDataPersonalizada()">Aplicar</button>
            </div>
            
            <div class="kpi-grid">
                <div class="kpi-card entrada">
                    <div class="kpi-icon">📥</div>
                    <div class="kpi-label">Total de Entradas</div>
                    <div class="kpi-number" id="totalEntradas">${stats.totalEntradas}</div>
                </div>
                <div class="kpi-card saida">
                    <div class="kpi-icon">📤</div>
                    <div class="kpi-label">Total de Saídas</div>
                    <div class="kpi-number" id="totalSaidas">${stats.totalSaidas}</div>
                </div>
                <div class="kpi-card producao">
                    <div class="kpi-icon">🏭</div>
                    <div class="kpi-label">Produções</div>
                    <div class="kpi-number" id="totalProducoes">${stats.totalProducoes}</div>
                </div>
                <div class="kpi-card estoque">
                    <div class="kpi-icon">📦</div>
                    <div class="kpi-label">Saldo Atual</div>
                    <div class="kpi-number" id="saldoAtual">${stats.saldoAtual}</div>
                </div>
            </div>
            
            <div class="dashboard-grid">
                <div class="dashboard-card">
                    <h3>📊 Entradas vs Saídas (${stats.periodoAtual})</h3>
                    <div class="chart-container">
                        <canvas id="graficoEntradaSaida"></canvas>
                    </div>
                    <div class="stats-row">
                        <div class="stats-item">
                            <div class="stats-value" id="mediaEntradas">${stats.mediaEntradas}</div>
                            <div class="stats-label">Média Entradas/dia</div>
                        </div>
                        <div class="stats-item">
                            <div class="stats-value" id="mediaSaidas">${stats.mediaSaidas}</div>
                            <div class="stats-label">Média Saídas/dia</div>
                        </div>
                        <div class="stats-item">
                            <div class="stats-value" id="totalMovimentacoes">${stats.totalMovimentacoes}</div>
                            <div class="stats-label">Total Mov.</div>
                        </div>
                    </div>
                </div>
                
                <div class="dashboard-card">
                    <h3>📈 Movimentações por Dia</h3>
                    <div class="chart-container">
                        <canvas id="graficoMovimentacoesDia"></canvas>
                    </div>
                    <div class="stats-row stats-total">
                        <div class="stats-item">
                            <div class="stats-value" id="diaPico">${stats.diaPico.data}</div>
                            <div class="stats-label">Dia de Pico</div>
                        </div>
                        <div class="stats-item">
                            <div class="stats-value" id="movimentosPico">${stats.diaPico.total}</div>
                            <div class="stats-label">Movimentações</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="dashboard-grid">
                <div class="dashboard-card">
                    <h3>🏆 Top 5 Itens Mais Movimentados</h3>
                    <div class="chart-container" style="height: 250px;">
                        <canvas id="graficoTopItens"></canvas>
                    </div>
                    <div class="top-itens" id="listaTopItens">
                        ${gerarListaTopItens(stats.topItens)}
                    </div>
                </div>
                
                <div class="dashboard-card">
                    <h3>👷 Produção por Funcionário</h3>
                    <div class="chart-container">
                        <canvas id="graficoProducaoFuncionarios"></canvas>
                    </div>
                    <div class="top-itens" id="listaTopFuncionarios">
                        ${gerarListaTopFuncionarios(stats.producaoFuncionarios)}
                    </div>
                </div>
            </div>
        `;
        
        conteudo.innerHTML = html;
        
        setTimeout(() => {
            criarGraficoEntradaSaida(stats.dadosGrafico);
            criarGraficoMovimentacoesDia(stats.movimentosPorDia);
            criarGraficoTopItens(stats.topItens);
            criarGraficoProducaoFuncionarios(stats.producaoFuncionarios);
        }, 100);
        
        window.dashboardData = stats;
        
    } catch (error) {
        console.error('Erro ao carregar dashboard:', error);
        conteudo.innerHTML = '<p style="color: #e74c3c; text-align: center; padding: 40px;">❌ Erro ao carregar dashboard</p>';
    }
    
    modal.style.display = 'flex';
}

async function calcularEstatisticasDashboard(periodo = '7dias', dataInicio = null, dataFim = null) {
    const hoje = new Date();
    let inicio = new Date(hoje);
    let fim = new Date(hoje);
    
    if (periodo === '7dias') {
        inicio.setDate(hoje.getDate() - 7);
    } else if (periodo === '30dias') {
        inicio.setDate(hoje.getDate() - 30);
    } else if (periodo === 'mesAtual') {
        inicio = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
        fim = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0);
    } else if (periodo === 'personalizado' && dataInicio && dataFim) {
        inicio = new Date(dataInicio);
        fim = new Date(dataFim);
    }
    
    const dataInicioStr = inicio.toISOString().split('T')[0];
    const dataFimStr = fim.toISOString().split('T')[0];
    
    const movPeriodo = movimentacoes.filter(m => 
        m.data >= dataInicioStr && m.data <= dataFimStr
    );
    
    const producoesPeriodo = producoesVisiveisParaUsuario().filter(p => 
        p.data >= dataInicioStr && p.data <= dataFimStr
    );
    
    const totalEntradas = movPeriodo
        .filter(m => m.tipo === 'entrada')
        .reduce((acc, m) => acc + m.quantidade, 0);
    
    const totalSaidas = movPeriodo
        .filter(m => m.tipo === 'saida')
        .reduce((acc, m) => acc + m.quantidade, 0);
    
    const totalProducoes = producoesPeriodo.length;
    
    const saldoAtual = movimentacoes.reduce((acc, m) => 
        acc + (m.tipo === 'entrada' ? m.quantidade : -m.quantidade), 0
    );
    
    const diasMap = new Map();
    for (let d = new Date(inicio); d <= fim; d.setDate(d.getDate() + 1)) {
        const dataStr = d.toISOString().split('T')[0];
        diasMap.set(dataStr, { entrada: 0, saida: 0, total: 0 });
    }
    
    movPeriodo.forEach(mov => {
        if (diasMap.has(mov.data)) {
            const dia = diasMap.get(mov.data);
            dia[mov.tipo] += mov.quantidade;
            dia.total += mov.quantidade;
        }
    });
    
    const diasArray = Array.from(diasMap.entries()).sort((a, b) => a[0].localeCompare(b[0]));
    
    const itensCount = {};
    movPeriodo.forEach(mov => {
        const key = `${mov.pecaId}-${mov.corId}`;
        if (!itensCount[key]) {
            itensCount[key] = { total: 0, entradas: 0, saidas: 0, pecaId: mov.pecaId, corId: mov.corId };
        }
        itensCount[key].total += mov.quantidade;
        itensCount[key][mov.tipo + 's'] += mov.quantidade;
    });
    
    const topItens = Object.values(itensCount)
        .sort((a, b) => b.total - a.total)
        .slice(0, 5)
        .map(item => {
            const peca = pecas.find(p => p.id === item.pecaId);
            const cor = cores.find(c => c.id === item.corId);
            return {
                ...item,
                pecaNome: peca?.nome || 'N/A',
                corNome: cor?.nome || 'Sem cor',
                valorTotal: (peca?.valor || 0) * item.total
            };
        });
    
    const producaoPorFuncionario = {};
    producoesPeriodo.forEach(prod => {
        const funcId = prod.funcionarioId;
        if (!producaoPorFuncionario[funcId]) {
            producaoPorFuncionario[funcId] = {
                quantidade: 0,
                valorTotal: 0,
                dias: new Set()
            };
        }
        
        const peca = pecas.find(p => p.id === prod.pecaId);
        const valorUnitarioBase = peca ? peca.valor : 0;
        const valorUnitario = prod.horaExtra ? valorUnitarioBase * 1.5 : valorUnitarioBase;
        const valorTotal = valorUnitario * prod.quantidade;
        
        producaoPorFuncionario[funcId].quantidade += prod.quantidade;
        producaoPorFuncionario[funcId].valorTotal += valorTotal;
        producaoPorFuncionario[funcId].dias.add(prod.data);
    });
    
    const producaoFuncionarios = Object.entries(producaoPorFuncionario)
        .map(([funcId, dados]) => {
            const funcionario = funcionarios.find(f => f.id == funcId);
            return {
                id: funcId,
                nome: funcionario?.nome || 'Funcionário Removido',
                cargo: funcionario?.cargo || 'N/A',
                quantidade: dados.quantidade,
                valorTotal: dados.valorTotal,
                diasTrabalhados: dados.dias.size
            };
        })
        .sort((a, b) => b.valorTotal - a.valorTotal);
    
    let diaPico = { data: '', total: 0 };
    diasArray.forEach(([data, valores]) => {
        if (valores.total > diaPico.total) {
            diaPico = { data: formatarData(data).slice(0,5), total: valores.total };
        }
    });
    
    return {
        totalEntradas,
        totalSaidas,
        totalProducoes,
        saldoAtual,
        mediaEntradas: diasArray.length > 0 ? (totalEntradas / diasArray.length).toFixed(1) : '0',
        mediaSaidas: diasArray.length > 0 ? (totalSaidas / diasArray.length).toFixed(1) : '0',
        totalMovimentacoes: movPeriodo.length,
        periodoAtual: periodo === '7dias' ? 'Últimos 7 dias' : 
                     periodo === '30dias' ? 'Últimos 30 dias' : 
                     periodo === 'mesAtual' ? 'Mês atual' : 'Período personalizado',
        dadosGrafico: {
            labels: diasArray.map(([data]) => formatarData(data).slice(0,5)),
            entradas: diasArray.map(([, v]) => v.entrada),
            saidas: diasArray.map(([, v]) => v.saida)
        },
        movimentosPorDia: {
            labels: diasArray.map(([data]) => formatarData(data).slice(0,5)),
            valores: diasArray.map(([, v]) => v.total)
        },
        topItens: {
            labels: topItens.map(item => `${item.pecaNome} (${item.corNome})`),
            valores: topItens.map(item => item.total)
        },
        producaoFuncionarios: {
            labels: producaoFuncionarios.map(f => f.nome.split(' ')[0] + (f.nome.split(' ')[1] ? ' ' + f.nome.split(' ')[1][0] + '.' : '')),
            nomesCompletos: producaoFuncionarios.map(f => f.nome),
            quantidades: producaoFuncionarios.map(f => f.quantidade),
            valores: producaoFuncionarios.map(f => f.valorTotal),
            detalhes: producaoFuncionarios
        },
        diaPico,
        ultimos7Dias: {
            inicio: new Date(hoje.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            fim: hojeISO()
        }
    };
}

function criarGraficoEntradaSaida(dados) {
    const ctx = document.getElementById('graficoEntradaSaida')?.getContext('2d');
    if (!ctx) return;
    
    if (entradaSaidaChart) {
        entradaSaidaChart.destroy();
    }
    
    entradaSaidaChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: dados.labels,
            datasets: [
                {
                    label: 'Entradas',
                    data: dados.entradas,
                    backgroundColor: '#27ae60',
                    borderRadius: 6,
                    barPercentage: 0.7
                },
                {
                    label: 'Saídas',
                    data: dados.saidas,
                    backgroundColor: '#e74c3c',
                    borderRadius: 6,
                    barPercentage: 0.7
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        usePointStyle: true,
                        boxWidth: 8
                    }
                },
                tooltip: {
                    mode: 'index',
                    intersect: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        drawBorder: false,
                        color: 'rgba(0,0,0,0.05)'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

function criarGraficoMovimentacoesDia(dados) {
    const ctx = document.getElementById('graficoMovimentacoesDia')?.getContext('2d');
    if (!ctx) return;
    
    if (movimentacoesPorDiaChart) {
        movimentacoesPorDiaChart.destroy();
    }
    
    movimentacoesPorDiaChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dados.labels,
            datasets: [{
                label: 'Movimentações',
                data: dados.valores,
                borderColor: '#1abc9c',
                backgroundColor: 'rgba(26, 188, 156, 0.1)',
                tension: 0.4,
                fill: true,
                pointBackgroundColor: '#16a085',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        drawBorder: false
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

function criarGraficoTopItens(dados) {
    const ctx = document.getElementById('graficoTopItens')?.getContext('2d');
    if (!ctx) return;
    
    if (topItensChart) {
        topItensChart.destroy();
    }
    
    topItensChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: dados.labels,
            datasets: [{
                data: dados.valores,
                backgroundColor: [
                    '#1abc9c',
                    '#3498db',
                    '#9b59b6',
                    '#f39c12',
                    '#e74c3c'
                ],
                borderWidth: 0,
                hoverOffset: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        boxWidth: 12,
                        padding: 15
                    }
                }
            },
            cutout: '65%'
        }
    });
}

function criarGraficoProducaoFuncionarios(dados) {
    const ctx = document.getElementById('graficoProducaoFuncionarios')?.getContext('2d');
    if (!ctx) return;
    
    if (producaoFuncionariosChart) {
        producaoFuncionariosChart.destroy();
    }
    
    producaoFuncionariosChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: dados.labels,
            datasets: [
                {
                    label: 'Quantidade Produzida',
                    data: dados.quantidades,
                    backgroundColor: '#3498db',
                    borderRadius: 6,
                    barPercentage: 0.6,
                    yAxisID: 'y'
                },
                {
                    label: 'Valor Produzido (R$)',
                    data: dados.valores,
                    backgroundColor: '#f39c12',
                    borderRadius: 6,
                    barPercentage: 0.6,
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: {
                        usePointStyle: true,
                        boxWidth: 8
                    }
                },
                tooltip: {
                    callbacks: {
                        label: (context) => {
                            const label = context.dataset.label || '';
                            const value = context.raw;
                            if (context.dataset.label.includes('Valor')) {
                                return `${label}: ${formatarMoeda(value)}`;
                            }
                            return `${label}: ${value} unidades`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    position: 'left',
                    title: {
                        display: true,
                        text: 'Quantidade'
                    },
                    grid: {
                        drawBorder: false
                    }
                },
                y1: {
                    beginAtZero: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: 'Valor (R$)'
                    },
                    grid: {
                        drawOnChartArea: false
                    },
                    ticks: {
                        callback: (value) => formatarMoeda(value)
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            }
        }
    });
}

function gerarListaTopItens(topItens) {
    if (!topItens.labels || topItens.labels.length === 0) {
        return '<p class="text-center" style="padding: 20px;">Nenhum item movimentado no período</p>';
    }
    
    let html = '';
    for (let i = 0; i < topItens.labels.length; i++) {
        html += `
            <div class="top-item">
                <div class="position">${i + 1}</div>
                <div class="info">
                    <div class="name">${esc(topItens.labels[i])}</div>
                    <div class="details">${topItens.valores[i]} unidades</div>
                </div>
                <div class="value">
                    ${topItens.valores[i]}
                </div>
            </div>
        `;
    }
    return html;
}

function gerarListaTopFuncionarios(dados) {
    if (!dados.detalhes || dados.detalhes.length === 0) {
        return '<p class="text-center" style="padding: 20px;">Nenhuma produção no período</p>';
    }
    
    let html = '';
    dados.detalhes.slice(0, 5).forEach((func, index) => {
        html += `
            <div class="top-item">
                <div class="position">${index + 1}</div>
                <div class="info">
                    <div class="name">${esc(func.nome)}</div>
                    <div class="details">${func.quantidade} itens • ${func.diasTrabalhados} dias</div>
                </div>
                <div class="value" style="color: #f39c12;">
                    ${formatarMoeda(func.valorTotal)}
                </div>
            </div>
        `;
    });
    return html;
}

async function atualizarDashboard(periodo, event) {
    if (event) {
        const botoes = document.querySelectorAll('.periodo-btn');
        botoes.forEach(btn => btn.classList.remove('active'));
        event.target.classList.add('active');
    }
    
    const dataRangeDiv = document.getElementById('dataRangePersonalizado');
    
    if (periodo === 'personalizado') {
        dataRangeDiv.style.display = 'grid';
        return;
    } else {
        dataRangeDiv.style.display = 'none';
    }
    
    const stats = await calcularEstatisticasDashboard(periodo);
    
    document.getElementById('totalEntradas').textContent = stats.totalEntradas;
    document.getElementById('totalSaidas').textContent = stats.totalSaidas;
    document.getElementById('totalProducoes').textContent = stats.totalProducoes;
    document.getElementById('saldoAtual').textContent = stats.saldoAtual;
    document.getElementById('mediaEntradas').textContent = stats.mediaEntradas;
    document.getElementById('mediaSaidas').textContent = stats.mediaSaidas;
    document.getElementById('totalMovimentacoes').textContent = stats.totalMovimentacoes;
    document.getElementById('diaPico').textContent = stats.diaPico.data;
    document.getElementById('movimentosPico').textContent = stats.diaPico.total;
    
    criarGraficoEntradaSaida(stats.dadosGrafico);
    criarGraficoMovimentacoesDia(stats.movimentosPorDia);
    criarGraficoTopItens(stats.topItens);
    criarGraficoProducaoFuncionarios(stats.producaoFuncionarios);
    
    document.getElementById('listaTopItens').innerHTML = gerarListaTopItens(stats.topItens);
    document.getElementById('listaTopFuncionarios').innerHTML = gerarListaTopFuncionarios(stats.producaoFuncionarios);
    
    window.dashboardData = stats;
}

async function aplicarDataPersonalizada() {
    const dataInicio = document.getElementById('dataInicioDash').value;
    const dataFim = document.getElementById('dataFimDash').value;
    
    if (!dataInicio || !dataFim) {
        toast('Selecione as datas de início e fim.', 'warn');
        return;
    }
    
    const stats = await calcularEstatisticasDashboard('personalizado', dataInicio, dataFim);
    
    document.getElementById('totalEntradas').textContent = stats.totalEntradas;
    document.getElementById('totalSaidas').textContent = stats.totalSaidas;
    document.getElementById('totalProducoes').textContent = stats.totalProducoes;
    document.getElementById('saldoAtual').textContent = stats.saldoAtual;
    document.getElementById('mediaEntradas').textContent = stats.mediaEntradas;
    document.getElementById('mediaSaidas').textContent = stats.mediaSaidas;
    document.getElementById('totalMovimentacoes').textContent = stats.totalMovimentacoes;
    document.getElementById('diaPico').textContent = stats.diaPico.data;
    document.getElementById('movimentosPico').textContent = stats.diaPico.total;
    
    criarGraficoEntradaSaida(stats.dadosGrafico);
    criarGraficoMovimentacoesDia(stats.movimentosPorDia);
    criarGraficoTopItens(stats.topItens);
    criarGraficoProducaoFuncionarios(stats.producaoFuncionarios);
    document.getElementById('listaTopItens').innerHTML = gerarListaTopItens(stats.topItens);
    document.getElementById('listaTopFuncionarios').innerHTML = gerarListaTopFuncionarios(stats.producaoFuncionarios);
    
    window.dashboardData = stats;
}

function fecharModalEstatisticas() {
    document.getElementById('modalEstatisticas').style.display = 'none';
    if (entradaSaidaChart) entradaSaidaChart.destroy();
    if (movimentacoesPorDiaChart) movimentacoesPorDiaChart.destroy();
    if (topItensChart) topItensChart.destroy();
    if (producaoFuncionariosChart) producaoFuncionariosChart.destroy();
}

function fecharComprovante() {
    document.getElementById('comprovanteSaida').classList.add('oculto');
}

function fecharComprovanteProducao() {
    document.getElementById('comprovanteProducao').classList.add('oculto');
}

function fecharModalSalvar() {
    document.getElementById('modalSalvar').style.display = 'none';
    document.getElementById('statusSalvar').innerHTML = '';
}

function salvarComprovante(tipo) {
    toast('Funcionalidade em desenvolvimento.', 'info');
}


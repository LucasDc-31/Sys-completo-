/**
 * delete.js
 * Funções de exclusão e apagar todos os dados (com confirmação)
 * (Extraído de script.js, linhas 1354-1702 do arquivo original)
 */

// ============================================
// FUNÇÕES DE EXCLUSÃO
// ============================================

async function excluirPeca(id) {
    if (!confirm('⚠️ Tem certeza que deseja excluir esta peça?')) return;
    
    try {
        await window.electronAPI.database.run('DELETE FROM Pecas WHERE id=?', [id]);
        await syncDeletar('Pecas', id);
        await DataManager.refreshData();
        toast('Modelo excluído com sucesso!', 'success');
    } catch (error) {
        console.error('❌ Erro ao excluir peça:', error);
        toast('Erro ao excluir: ' + error.message, 'error');
    }
}

async function excluirFuncionario(id) {
    if (!confirm('⚠️ Tem certeza que deseja excluir este funcionário?\nO login pessoal dele (se existir) também será removido.')) return;

    try {
        const res = await window.electronAPI.funcionarios.excluir(id);
        if (!res.success) { toast(res.error, 'error'); return; }
        await syncDeletar('Funcionarios', id);
        await DataManager.refreshData();
        toast('Funcionário excluído com sucesso!', 'success');
    } catch (error) {
        console.error('❌ Erro ao excluir funcionário:', error);
        toast('Erro ao excluir funcionário: ' + error.message, 'error');
    }
}

// Mostra ao administrador o e-mail e a senha gerados automaticamente para
// o login pessoal do funcionário recém-cadastrado. Essas credenciais só
// aparecem esta vez — o admin deve anotar/repassar ao funcionário agora.
function mostrarCredenciaisFuncionario(nome, credenciais) {
    const modal = document.getElementById('modalCredenciaisFuncionario');
    if (!modal) { // fallback caso o modal não exista no HTML por algum motivo
        alert(`Login criado para ${nome}:\nE-mail: ${credenciais.email}\nSenha: ${credenciais.senha}`);
        return;
    }
    document.getElementById('credNomeFuncionario').textContent = nome;
    document.getElementById('credEmailFuncionario').textContent = credenciais.email;
    document.getElementById('credSenhaFuncionario').textContent = credenciais.senha;
    document.getElementById('credRoleFuncionario').textContent = credenciais.role === 'admin' ? 'Administrador' : 'Operador (acesso apenas à própria produção)';
    modal.style.display = 'flex';
}

function fecharModalCredenciaisFuncionario() {
    const modal = document.getElementById('modalCredenciaisFuncionario');
    if (modal) modal.style.display = 'none';
}

// Copia e-mail + senha para a área de transferência, facilitando repassar
// as credenciais ao funcionário (ex: colar num WhatsApp/bilhete).
async function copiarCredenciaisFuncionario() {
    const email = document.getElementById('credEmailFuncionario')?.textContent || '';
    const senha = document.getElementById('credSenhaFuncionario')?.textContent || '';
    const texto = `Acesso ao SysCadeiras\nE-mail: ${email}\nSenha: ${senha}`;
    try {
        await navigator.clipboard.writeText(texto);
        toast('Credenciais copiadas!', 'success');
    } catch (e) {
        toast('Não foi possível copiar automaticamente. Copie manualmente.', 'warn');
    }
}

async function excluirCor(id) {
    if (!confirm('⚠️ Tem certeza que deseja excluir esta cor?')) return;
    
    try {
        await window.electronAPI.database.run('DELETE FROM Cores WHERE id=?', [id]);
        await syncDeletar('Cores', id);
        await DataManager.refreshData();
        toast('Cor excluída com sucesso!', 'success');
    } catch (error) {
        console.error('❌ Erro ao excluir cor:', error);
        toast('Erro ao excluir cor: ' + error.message, 'error');
    }
}

async function excluirProducao(id) {
    if (!confirm('⚠️ Tem certeza que deseja excluir este registro de produção?')) return;
    
    try {
        const producao = DataManager.findById(producoes, id);
        if (producao) {
            const itens = [{
                pecaId: producao.pecaId,
                quantidade: producao.quantidade
            }];
            
            await FormManager.atualizarEstoqueArmacaoProducao(itens, 'adicionar');
        }
        
        await window.electronAPI.database.run('DELETE FROM Producoes WHERE id=?', [id]);
        await syncDeletar('Producoes', id);
        const movs = movimentacoes.filter(m => m.producaoId === id);
        for (const mov of movs) {
            await window.electronAPI.database.run('DELETE FROM Movimentacoes WHERE id=?', [mov.id]);
            await syncDeletar('Movimentacoes', mov.id);
        }
        await DataManager.refreshData();
        toast('Produção excluída com sucesso!', 'success');
        
    } catch (error) {
        console.error('❌ Erro ao excluir produção:', error);
        toast('Erro ao excluir produção: ' + error.message, 'error');
    }
}

async function excluirArmacao(id) {
    if (!confirm('⚠️ Tem certeza que deseja excluir este registro de chegada?')) return;
    
    try {
        const armacao = DataManager.findById(armacoes, id);
        if (!armacao) return;
        
        await window.electronAPI.database.run('DELETE FROM Armações WHERE id=?', [id]);
        await syncDeletar('Armacoes', id);
        await FormManager.recalcularEstoqueArmacao(armacao.modeloId);
        const _eaDel = estoqueArmacoes.find(e => e.modeloId === armacao.modeloId);
        if (_eaDel) await syncEspelhar('EstoqueArmacoes', { modeloid: armacao.modeloId, quantidade: _eaDel.quantidade }, 'modeloid');
        await DataManager.refreshData();
        toast('Registro excluído com sucesso!', 'success');
        
    } catch (error) {
        console.error('❌ Erro ao excluir armação:', error);
        toast('Erro ao excluir registro: ' + error.message, 'error');
    }
}

// ============================================
// FUNÇÃO PARA APAGAR TODOS OS DADOS (CORRIGIDA)
// ============================================

// ============================================
// MODAL DE APAGAR DADOS — ETAPA 1: Senha
// ============================================

function apagarTodosDados() {
    // Resetar estado completo do modal
    document.getElementById('inputSenhaApagar').value = '';
    document.getElementById('erroSenha').textContent = '';
    document.getElementById('erroSelecao').textContent = '';
    document.getElementById('etapaSenha').style.display = 'block';
    document.getElementById('etapaSelecao').style.display = 'none';
    // Desmarcar todos os checkboxes
    ['chkTudo','chkProducoes','chkMovimentacoes','chkArmacoes','chkPecas','chkFuncionarios','chkCores']
        .forEach(id => { const el = document.getElementById(id); if (el) el.checked = false; });
    _atualizarEstilosCheckboxes();
    document.getElementById('modalSenha').style.display = 'flex';
    setTimeout(() => document.getElementById('inputSenhaApagar').focus(), 50);
}

function fecharModalSenha() {
    document.getElementById('modalSenha').style.display = 'none';
}

function confirmarSenhaApagar() {
    const senha  = document.getElementById('inputSenhaApagar').value;
    const erroEl = document.getElementById('erroSenha');

    if (senha !== 'dantas3101') {
        erroEl.textContent = '❌ Senha incorreta. Tente novamente.';
        document.getElementById('inputSenhaApagar').focus();
        return;
    }

    // Avança para a etapa 2
    erroEl.textContent = '';
    document.getElementById('etapaSenha').style.display = 'none';
    document.getElementById('etapaSelecao').style.display = 'block';
}

// ============================================
// MODAL DE APAGAR DADOS — ETAPA 2: Checkboxes
// ============================================

function toggleTudoApagar(marcado) {
    ['chkProducoes','chkMovimentacoes','chkArmacoes','chkPecas','chkFuncionarios','chkCores']
        .forEach(id => { document.getElementById(id).checked = marcado; });
    _atualizarEstilosCheckboxes();
}

function atualizarCheckTudo() {
    const todos = ['chkProducoes','chkMovimentacoes','chkArmacoes','chkPecas','chkFuncionarios','chkCores'];
    const todosMarcados = todos.every(id => document.getElementById(id).checked);
    document.getElementById('chkTudo').checked = todosMarcados;
    _atualizarEstilosCheckboxes();
}

function _atualizarEstilosCheckboxes() {
    const mapa = {
        chkProducoes:     'lblProducoes',
        chkMovimentacoes: 'lblMovimentacoes',
        chkArmacoes:      'lblArmacoes',
        chkPecas:         'lblPecas',
        chkFuncionarios:  'lblFuncionarios',
        chkCores:         'lblCores',
    };
    for (const [chkId, lblId] of Object.entries(mapa)) {
        const chk = document.getElementById(chkId);
        const lbl = document.getElementById(lblId);
        if (!chk || !lbl) continue;
        if (chk.checked) {
            lbl.style.borderColor  = '#e74c3c';
            lbl.style.background   = '#fff5f5';
        } else {
            lbl.style.borderColor  = '#eee';
            lbl.style.background   = '#fff';
        }
    }
}

async function executarApagarSelecionados() {
    const selecionados = {
        producoes:     document.getElementById('chkProducoes').checked,
        movimentacoes: document.getElementById('chkMovimentacoes').checked,
        armacoes:      document.getElementById('chkArmacoes').checked,
        pecas:         document.getElementById('chkPecas').checked,
        funcionarios:  document.getElementById('chkFuncionarios').checked,
        cores:         document.getElementById('chkCores').checked,
    };

    const algumMarcado = Object.values(selecionados).some(Boolean);
    if (!algumMarcado) {
        document.getElementById('erroSelecao').textContent = '⚠️ Selecione pelo menos uma categoria para apagar.';
        return;
    }

    // Monta lista legível para a confirmação
    const nomes = {
        producoes: '🏭 Produções', movimentacoes: '📊 Movimentações',
        armacoes: '🔩 Armações', pecas: '🪑 Modelos/Peças',
        funcionarios: '👷 Funcionários', cores: '🎨 Cores'
    };
    const listaLegivel = Object.entries(selecionados)
        .filter(([, v]) => v)
        .map(([k]) => '• ' + nomes[k])
        .join('\n');

    fecharModalSenha();

    const ok = confirm(
        `⚠️ CONFIRMAÇÃO FINAL\n\nOs seguintes dados serão apagados permanentemente:\n\n${listaLegivel}\n\nTem certeza absoluta?`
    );
    if (!ok) return;

    // Loading
    const loadingMsg = document.createElement('div');
    loadingMsg.className = 'loading-spinner';
    loadingMsg.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:10001;width:50px;height:50px;';
    document.body.appendChild(loadingMsg);

    try {
        // Ordem respeita chaves estrangeiras:
        // Primeiro as dependentes (Movimentacoes, Producoes, Comprovantes, EstoqueArmacoes, Armações)
        // Depois as base (Pecas, Funcionarios, Cores)

        if (selecionados.movimentacoes) {
            // FIX: busca IDs antes de deletar para sincronizar com Supabase
            const todasMovs = await window.electronAPI.database.all('SELECT id FROM Movimentacoes');
            await window.electronAPI.database.run('DELETE FROM Movimentacoes');
            if (todasMovs.success) {
                for (const m of todasMovs.result) await syncDeletar('Movimentacoes', m.id);
            }
            console.log('✅ Movimentações apagadas');
        }

        if (selecionados.producoes) {
            const todasProds = await window.electronAPI.database.all('SELECT id FROM Producoes');
            await window.electronAPI.database.run('DELETE FROM Producoes');
            await window.electronAPI.database.run('DELETE FROM Comprovantes');
            if (todasProds.success) {
                for (const p of todasProds.result) await syncDeletar('Producoes', p.id);
            }
            console.log('✅ Produções/Comprovantes apagados');
        }

        if (selecionados.armacoes) {
            const todasArms = await window.electronAPI.database.all('SELECT id FROM Armações');
            await window.electronAPI.database.run('DELETE FROM EstoqueArmacoes');
            await window.electronAPI.database.run('DELETE FROM Armações');
            if (todasArms.success) {
                for (const a of todasArms.result) await syncDeletar('Armacoes', a.id);
            }
            console.log('✅ Armações apagadas');
        }

        // Peças, Funcionários e Cores só podem ser apagados se as tabelas dependentes
        // (Producoes e Movimentacoes) já foram limpas ou também foram selecionadas
        if (selecionados.pecas) {
            const todasPecas = await window.electronAPI.database.all('SELECT id FROM Pecas');
            await window.electronAPI.database.run('DELETE FROM Pecas');
            if (todasPecas.success) {
                for (const p of todasPecas.result) await syncDeletar('Pecas', p.id);
            }
            console.log('✅ Peças apagadas');
        }

        if (selecionados.funcionarios) {
            const todosFuncs = await window.electronAPI.database.all('SELECT id FROM Funcionarios');
            await window.electronAPI.database.run('DELETE FROM Funcionarios');
            if (todosFuncs.success) {
                for (const f of todosFuncs.result) await syncDeletar('Funcionarios', f.id);
            }
            console.log('✅ Funcionários apagados');
        }

        if (selecionados.cores) {
            const todasCores = await window.electronAPI.database.all('SELECT id FROM Cores');
            await window.electronAPI.database.run('DELETE FROM Cores');
            if (todasCores.success) {
                for (const c of todasCores.result) await syncDeletar('Cores', c.id);
            }
            console.log('✅ Cores apagadas');
        }

        // Resetar auto-incremento apenas se esvaziou todas as tabelas
        try {
            await window.electronAPI.database.run('DELETE FROM sqlite_sequence');
        } catch (err) {
            console.warn('sqlite_sequence não encontrado:', err);
        }

        await DataManager.loadDataFromDB();
        UIManager.refreshAllSelects();
        UIManager.refreshAllTables();

        document.body.removeChild(loadingMsg);

        const categorias = Object.entries(selecionados).filter(([,v])=>v).map(([k])=>nomes[k]).join(', ');
        toast('Dados apagados: ' + categorias, 'success');

        FormManager.resetForm('peca');
        FormManager.resetForm('funcionario');
        FormManager.resetForm('cor');
        FormManager.resetForm('armacao');

    } catch (error) {
        const currentLoading = document.querySelector('.loading-spinner');
        if (currentLoading) document.body.removeChild(currentLoading);
        console.error('❌ Erro ao apagar dados:', error);
        toast('Erro: ' + error.message + ' — Apague dependências primeiro.', 'error');
    }
}


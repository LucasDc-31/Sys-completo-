/**
 * auth-ui.js
 * Módulo de autenticação/usuários (interface desktop)
 * (Extraído de script.js, linhas 4428-4855 do arquivo original)
 */

// ============================================
// MÓDULO DE AUTENTICAÇÃO — Desktop
// ============================================

// ── Login ────────────────────────────────────
async function fazerLogin() {
    const email = document.getElementById('loginEmail').value.trim();
    const senha = document.getElementById('loginSenha').value;
    const errEl = document.getElementById('loginErro');
    const btn   = document.getElementById('btnEntrar');

    errEl.textContent = '';
    if (!email || !senha) { errEl.textContent = '⚠️ Preencha e-mail e senha.'; return; }

    btn.disabled = true;
    btn.textContent = 'Entrando...';

    try {
        const res = await window.electronAPI.auth.login(email, senha);
        if (!res.success) {
            errEl.textContent = '❌ ' + res.error;
            btn.disabled = false;
            btn.textContent = '🔐 Entrar';
            return;
        }

        currentUser = res.user;
        currentUser.permissoes = currentUser.permissoes || [];
        document.getElementById('loginOverlay').classList.add('hidden');
        document.getElementById('mainApp') && (document.getElementById('mainApp').style.display = '');
        const _tb=document.getElementById('appTopbar'); if(_tb)_tb.style.display='flex';
        const _ly=document.getElementById('appLayout'); if(_ly)_ly.style.display='flex';
        atualizarBadgeUsuario();
        aplicarPermissoesNaSidebar();
        await inicializarSistema();
        abrirPrimeiraSecaoPermitida();

    } catch (e) {
        errEl.textContent = '❌ Erro ao conectar: ' + e.message;
        btn.disabled = false;
        btn.textContent = '🔐 Entrar';
    }
}

function fazerLogout() {
    if (!confirm('Deseja sair do sistema?')) return;
    currentUser = null;
    // Avisa o processo principal para encerrar a sessão guardada lá (é ela
    // que autoriza/bloqueia as escritas no banco — ver main.js).
    if (window.electronAPI?.auth?.logout) window.electronAPI.auth.logout().catch(() => {});
    document.getElementById('loginOverlay').classList.remove('hidden');
    document.getElementById('mainApp') && (document.getElementById('mainApp').style.display = 'none');
    const _tb2=document.getElementById('appTopbar'); if(_tb2)_tb2.style.display='none';
    const _ly2=document.getElementById('appLayout'); if(_ly2)_ly2.style.display='none';
    document.getElementById('loginEmail').value = '';
    document.getElementById('loginSenha').value = '';
    document.getElementById('loginErro').textContent = '';
    // Nova frase motivacional a cada retorno à tela de login
    exibirFraseLogin();
    // Remover listeners de sync para evitar acúmulo na próxima sessão
    if (window.electronAPI?.sync) window.electronAPI.sync.removerListeners();
    // Desfaz travas visuais aplicadas para a conta que acabou de sair (select
    // de funcionário reduzido a 1 opção, campo de data com min/max, botões
    // de relatório escondidos) — sem isso, se o próximo login for de um
    // admin, ele herdaria por um instante a tela travada da conta anterior.
    resetarRestricoesVisuaisDaSessao();
}

// Devolve ao estado neutro tudo que as restrições de "conta pessoal de
// funcionário" alteraram na tela (ver aplicarRestricaoDataProducao e
// aplicarRestricaoTiposRelatorio). Chamado no logout; o próximo login
// reaplica a restrição certa para a conta que entrar, via inicializarSistema().
function resetarRestricoesVisuaisDaSessao() {
    const campoData = document.getElementById('dataProducao');
    if (campoData) {
        campoData.readOnly = false;
        campoData.removeAttribute('min');
        campoData.removeAttribute('max');
        campoData.style.opacity = '';
        campoData.style.cursor = '';
    }
    const avisoData = document.getElementById('avisoDataProducaoTravada');
    if (avisoData) avisoData.style.display = 'none';

    const selectFunc = document.getElementById('funcionarioProducao');
    if (selectFunc) {
        selectFunc.disabled = false;
        selectFunc.style.opacity = '';
        selectFunc.style.cursor = '';
    }
    const avisoFunc = document.getElementById('avisoFuncionarioProducaoTravado');
    if (avisoFunc) avisoFunc.style.display = 'none';

    const btnEstoque = document.getElementById('btnRelatorioEstoque');
    const btnArmacoes = document.getElementById('btnRelatorioArmacoes');
    const btnGeral = document.getElementById('btnRelatorioGeral');
    const btnModelos = document.getElementById('btnRelatorioModelos');
    const btnFolha = document.getElementById('btnRelatorioFolha');
    [btnEstoque, btnArmacoes, btnGeral, btnModelos, btnFolha].forEach(b => { if (b) b.style.display = ''; });

    const filtroFunc = document.getElementById('filtroFuncionario');
    if (filtroFunc) filtroFunc.disabled = false;
    const linhaFiltroFunc = filtroFunc?.closest('.fg');
    if (linhaFiltroFunc) linhaFiltroFunc.style.display = '';

    tipoRelatorioAtual = 'geral';
}
window.resetarRestricoesVisuaisDaSessao = resetarRestricoesVisuaisDaSessao;

function atualizarBadgeUsuario() {
    if (!currentUser) return;
    const inicial = currentUser.nome.charAt(0).toUpperCase();
    const roleLabel = currentUser.role === 'admin' ? 'Administrador' : 'Operador';

    // legacy userBadge (caso exista)
    const badge = document.getElementById('userBadge');
    if (badge) {
        badge.innerHTML = `
            <div class="user-avatar">${esc(inicial)}</div>
            <div class="user-info">
                <div class="user-name">${esc(currentUser.nome)}</div>
                <div class="user-role">${esc(roleLabel)}</div>
            </div>
        `;
    }
    // dark topbar elements
    const av = document.getElementById('userAvatar');
    if (av) av.textContent = inicial;
    const nm = document.getElementById('userNome');
    if (nm) nm.textContent = currentUser.nome;
    const rl = document.getElementById('userRole');
    if (rl) rl.textContent = roleLabel;

    // Mostrar/ocultar menu de usuários conforme role
    const menuUsuarios = document.getElementById('btnMenuUsuarios');
    if (menuUsuarios) {
        menuUsuarios.style.display = currentUser.role === 'admin' ? '' : 'none';
        menuUsuarios.classList.toggle('hidden', currentUser.role !== 'admin');
    }
    // Mostrar/ocultar menu de histórico conforme role (só administradores)
    const menuHistorico = document.getElementById('btnMenuHistorico');
    if (menuHistorico) {
        menuHistorico.style.display = currentUser.role === 'admin' ? '' : 'none';
        menuHistorico.classList.toggle('hidden', currentUser.role !== 'admin');
    }
}

// Enter no campo senha faz login
document.addEventListener('DOMContentLoaded', () => {
    const senhaInput = document.getElementById('loginSenha');
    if (senhaInput) {
        senhaInput.addEventListener('keydown', e => { if (e.key === 'Enter') fazerLogin(); });
    }
    const emailInput = document.getElementById('loginEmail');
    if (emailInput) {
        emailInput.addEventListener('keydown', e => { if (e.key === 'Enter') document.getElementById('loginSenha').focus(); });
    }
});

// ── Gestão de Usuários (admin only) ──────────
let _editandoUsuarioId = null;

async function abrirGestaoUsuarios() {
    if (currentUser?.role !== 'admin') {
        toast('Acesso restrito a administradores.', 'error');
        return;
    }
    await carregarUsuariosTela();
    showSection('usuarios', document.getElementById('btnMenuUsuarios') || document.querySelector('.menu button[onclick*="usuarios"]'));
}

async function carregarUsuariosTela() {
    const res = await window.electronAPI.auth.listarUsuarios();
    usuarios = res.success ? res.result : [];
    renderizarUsuarios();
}

function renderizarUsuarios() {
    const container = document.getElementById('listaUsuarios');
    if (!container) return;

    if (usuarios.length === 0) {
        container.innerHTML = '<p style="color:#7f8c8d;text-align:center;padding:30px">Nenhum usuário cadastrado.</p>';
        return;
    }

    container.innerHTML = usuarios.map(u => {
        const inicial = u.nome.charAt(0).toUpperCase();
        const roleLabel = u.role === 'admin' ? 'Admin' : 'Operador';
        const statusClass = !u.ativo ? 'inativo' : u.role;
        const statusLabel = !u.ativo ? '🔒 Bloqueado' : roleLabel;
        const isSelf = currentUser && u.email === currentUser.email;
        const permissoesLabel = u.role === 'admin'
            ? 'Acesso total'
            : ((u.permissoes && u.permissoes.length)
                ? u.permissoes
                    .filter(id => !id.startsWith(PREFIXO_PERMISSAO_RELATORIO)) // sub-tipos vão no rótulo de "Relatórios" abaixo, não soltos aqui
                    .map(id => (PERMISSOES_DISPONIVEIS.find(p => p.id === id)?.label || id))
                    .join(', ')
                : 'Nenhum acesso definido');
        const tiposRelatorioLabel = (u.permissoes || [])
            .filter(id => id.startsWith(PREFIXO_PERMISSAO_RELATORIO))
            .map(id => id.slice(PREFIXO_PERMISSAO_RELATORIO.length))
            .map(id => TIPOS_RELATORIO_DISPONIVEIS.find(t => t.id === id)?.label || id)
            .join(', ');

        return `
        <div class="usuario-card${!u.ativo ? ' usuario-bloqueado' : ''}">
            <div class="usuario-avatar ${u.role === 'admin' ? 'admin' : ''}">${esc(inicial)}</div>
            <div class="usuario-info">
                <div class="u-nome">${esc(u.nome)} ${isSelf ? '<span style="font-size:.75rem;color:#1abc9c">(você)</span>' : ''}</div>
                <div class="u-email">${esc(u.email)}</div>
                <span class="u-role ${statusClass}">${esc(statusLabel)}</span>
                <div style="font-size:11px;color:var(--muted);margin-top:4px;">${esc(permissoesLabel)}</div>
                ${tiposRelatorioLabel ? `<div style="font-size:11px;color:var(--muted);margin-top:2px;">📊 Relatórios: ${esc(tiposRelatorioLabel)}</div>` : ''}
            </div>
            <div class="usuario-actions">
                <button class="btn-action btn-edit" onclick="abrirEditarUsuario(${u.id})" title="Editar">✏️</button>
                ${!isSelf ? `<button class="btn-action ${u.ativo ? 'btn-block' : 'btn-unblock'}" onclick="alternarBloqueioUsuario(${u.id}, ${u.ativo ? 'true' : 'false'})" title="${u.ativo ? 'Bloquear acesso' : 'Desbloquear acesso'}">${u.ativo ? '🔒' : '🔓'}</button>` : ''}
                ${!isSelf ? `<button class="btn-action btn-delete" onclick="deletarUsuario(${u.id})" title="Excluir">🗑️</button>` : ''}
            </div>
        </div>`;
    }).join('');
}

// Desenha os checkboxes de permissão dentro do modal de usuário. Logo após
// o checkbox "📊 Relatórios" insere um sub-bloco recuado com os tipos de
// relatório (Produção, Modelo/Cor, Folha de Pagamento, Armações, Estoque) —
// esse sub-bloco só aparece/importa quando "Relatórios" está marcado, e é
// ele que decide o que a conta pode abrir dentro da tela de Relatórios.
function renderListaPermissoesUsuario(selecionadas = []) {
    const container = document.getElementById('listaPermissoesUsuario');
    if (!container) return;

    const tiposRelatorioSelecionados = selecionadas
        .filter(p => p.startsWith(PREFIXO_PERMISSAO_RELATORIO))
        .map(p => p.slice(PREFIXO_PERMISSAO_RELATORIO.length));

    container.innerHTML = PERMISSOES_DISPONIVEIS.map(p => {
        const linhaPrincipal = `
        <label style="display:flex;align-items:center;gap:8px;font-size:13px;color:var(--text);cursor:pointer;">
            <input type="checkbox" class="chk-permissao-usuario" value="${p.id}"
                   ${selecionadas.includes(p.id) ? 'checked' : ''}
                   ${p.id === 'relatorios' ? "onchange=\"atualizarVisibilidadeTiposRelatorio()\"" : ''}
                   style="width:16px;height:16px;cursor:pointer;accent-color:var(--green);">
            ${p.label}
        </label>`;

        if (p.id !== 'relatorios') return linhaPrincipal;

        // Sub-bloco de tipos de relatório, logo abaixo do checkbox "Relatórios"
        const subBloco = `
        <div id="blocoTiposRelatorioUsuario" style="grid-column:1 / -1;display:${selecionadas.includes('relatorios') ? 'flex' : 'none'};flex-direction:column;gap:6px;margin:2px 0 4px 26px;padding:8px 12px;background:rgba(255,255,255,.03);border-left:2px solid var(--green);border-radius:6px;">
            <div style="font-size:11px;color:var(--muted);margin-bottom:2px;">Quais relatórios esta conta pode ver:</div>
            ${TIPOS_RELATORIO_DISPONIVEIS.map(t => `
            <label style="display:flex;align-items:center;gap:8px;font-size:12.5px;color:var(--text);cursor:pointer;">
                <input type="checkbox" class="chk-tipo-relatorio-usuario" value="${t.id}"
                       ${tiposRelatorioSelecionados.includes(t.id) ? 'checked' : ''}
                       style="width:14px;height:14px;cursor:pointer;accent-color:var(--green);">
                ${t.label}
            </label>`).join('')}
        </div>`;

        return linhaPrincipal + subBloco;
    }).join('');
}

// Mostra/esconde o sub-bloco de tipos de relatório conforme o checkbox
// "Relatórios" é marcado/desmarcado no modal.
function atualizarVisibilidadeTiposRelatorio() {
    const chkRelatorios = document.querySelector('.chk-permissao-usuario[value="relatorios"]');
    const bloco = document.getElementById('blocoTiposRelatorioUsuario');
    if (bloco) bloco.style.display = chkRelatorios?.checked ? 'flex' : 'none';
}
window.atualizarVisibilidadeTiposRelatorio = atualizarVisibilidadeTiposRelatorio;

// Lê tanto as permissões principais quanto, se "Relatórios" estiver
// marcado, os sub-tipos escolhidos (salvos com o prefixo "relatorio:" no
// mesmo array — ex: 'relatorio:producao', 'relatorio:folha').
function lerPermissoesSelecionadas() {
    const principais = Array.from(document.querySelectorAll('.chk-permissao-usuario:checked')).map(c => c.value);
    if (!principais.includes('relatorios')) return principais;

    const tipos = Array.from(document.querySelectorAll('.chk-tipo-relatorio-usuario:checked'))
        .map(c => PREFIXO_PERMISSAO_RELATORIO + c.value);
    return [...principais, ...tipos];
}

// Administrador tem acesso total automaticamente — some com os checkboxes nesse caso.
function atualizarVisibilidadePermissoes() {
    const role = document.getElementById('formUsuarioRole').value;
    const bloco = document.getElementById('blocoPermissoesUsuario');
    if (bloco) bloco.style.display = role === 'admin' ? 'none' : '';
}

function abrirNovoUsuario() {
    _editandoUsuarioId = null;
    document.getElementById('modalUsuarioTitulo').textContent = '➕ Novo Usuário';
    document.getElementById('formUsuarioNome').value  = '';
    document.getElementById('formUsuarioEmail').value = '';
    document.getElementById('formUsuarioSenha').value = '';
    document.getElementById('lblFormUsuarioSenha').textContent = 'Senha';
    document.getElementById('dicaSenhaUsuario').textContent = 'Defina a senha de acesso desta conta (mín. 4 caracteres).';
    document.getElementById('formUsuarioRole').value  = 'operador';
    document.getElementById('formUsuarioAtivo').checked = true;
    document.getElementById('erroModalUsuario').textContent = '';
    document.getElementById('formConfirmacaoAdmin').value = '';
    document.getElementById('blocoConfirmacaoAdmin').style.display = '';
    renderListaPermissoesUsuario([]);
    atualizarVisibilidadePermissoes();
    document.getElementById('modalUsuario').style.display = 'flex';
}

function abrirEditarUsuario(id) {
    const u = usuarios.find(x => x.id === id);
    if (!u) return;
    _editandoUsuarioId = id;
    document.getElementById('modalUsuarioTitulo').textContent = '✏️ Editar Usuário';
    document.getElementById('formUsuarioNome').value  = u.nome;
    document.getElementById('formUsuarioEmail').value = u.email;
    document.getElementById('formUsuarioSenha').value = '';
    document.getElementById('lblFormUsuarioSenha').textContent = 'Nova senha (opcional)';
    document.getElementById('dicaSenhaUsuario').textContent = 'Deixe em branco para não alterar a senha atual.';
    document.getElementById('formUsuarioRole').value  = u.role;
    document.getElementById('formUsuarioAtivo').checked = !!u.ativo;
    document.getElementById('erroModalUsuario').textContent = '';
    document.getElementById('formConfirmacaoAdmin').value = '';
    // Confirmação de admin só é exigida para CRIAR usuário, não para editar.
    document.getElementById('blocoConfirmacaoAdmin').style.display = 'none';
    renderListaPermissoesUsuario(u.permissoes || []);
    atualizarVisibilidadePermissoes();
    document.getElementById('modalUsuario').style.display = 'flex';
}

function fecharModalUsuario() {
    document.getElementById('modalUsuario').style.display = 'none';
    _editandoUsuarioId = null;
}

async function salvarUsuario() {
    const nome  = document.getElementById('formUsuarioNome').value.trim();
    const email = document.getElementById('formUsuarioEmail').value.trim();
    const senha = document.getElementById('formUsuarioSenha').value;
    const role  = document.getElementById('formUsuarioRole').value;
    const ativo = document.getElementById('formUsuarioAtivo').checked;
    const permissoes = lerPermissoesSelecionadas();
    const confirmacaoAdmin = document.getElementById('formConfirmacaoAdmin').value;
    const errEl = document.getElementById('erroModalUsuario');

    errEl.textContent = '';
    if (!nome || !email) { errEl.textContent = '⚠️ Nome e e-mail são obrigatórios.'; return; }
    if (!_editandoUsuarioId && !senha) { errEl.textContent = '⚠️ Defina uma senha para a nova conta.'; return; }
    if (role !== 'admin' && permissoes.length === 0) {
        errEl.textContent = '⚠️ Marque ao menos uma seção que esta conta pode acessar.';
        return;
    }
    // Criar usuário exige a senha de confirmação do administrador
    if (!_editandoUsuarioId && confirmacaoAdmin !== 'admadd') {
        errEl.textContent = '⚠️ Senha de confirmação do administrador incorreta.';
        return;
    }

    try {
        let res;
        if (_editandoUsuarioId) {
            res = await window.electronAPI.auth.editarUsuario(_editandoUsuarioId, { nome, email, role, ativo, senha, permissoes });
        } else {
            res = await window.electronAPI.auth.criarUsuario({ nome, email, role, senha, permissoes, confirmacaoAdmin });
        }

        if (!res.success) { errEl.textContent = '❌ ' + res.error; return; }

        fecharModalUsuario();
        await carregarUsuariosTela();
        toast(_editandoUsuarioId ? 'Usuário atualizado!' : 'Usuário criado!', 'success');
    } catch (e) {
        errEl.textContent = '❌ Erro: ' + e.message;
    }
}

async function deletarUsuario(id) {
    const u = usuarios.find(x => x.id === id);
    if (!u) return;
    if (!confirm(`⚠️ Excluir o usuário "${u.nome}"?\nEsta ação não pode ser desfeita.`)) return;

    const res = await window.electronAPI.auth.deletarUsuario(id);
    if (!res.success) { toast(res.error, 'error'); return; }

    await carregarUsuariosTela();
    toast('Usuário excluído.', 'success');
}

// Bloqueia (ou desbloqueia) o acesso de um usuário ao sistema. Um usuário
// bloqueado não consegue mais fazer login (nem no Desktop, nem no Mobile),
// mas seu cadastro, produção e histórico continuam intactos — é reversível
// a qualquer momento pelo mesmo botão.
async function alternarBloqueioUsuario(id, estaAtivo) {
    const u = usuarios.find(x => x.id === id);
    if (!u) return;

    const bloquear = !!estaAtivo; // se está ativo agora, a ação é bloquear
    const confirmMsg = bloquear
        ? `🔒 Bloquear o acesso de "${u.nome}"?\nEle não conseguirá mais fazer login no sistema até ser desbloqueado.`
        : `🔓 Desbloquear o acesso de "${u.nome}"?\nEle voltará a conseguir fazer login normalmente.`;
    if (!confirm(confirmMsg)) return;

    const res = await window.electronAPI.auth.alternarBloqueio(id, bloquear);
    if (!res.success) { toast(res.error, 'error'); return; }

    await carregarUsuariosTela();
    toast(bloquear ? `🔒 Acesso de "${u.nome}" bloqueado.` : `🔓 Acesso de "${u.nome}" liberado.`, 'success');
}

// Expor funções globalmente
window.fazerLogin         = fazerLogin;
window.fazerLogout        = fazerLogout;
window.abrirGestaoUsuarios= abrirGestaoUsuarios;
window.abrirNovoUsuario   = abrirNovoUsuario;
window.abrirEditarUsuario = abrirEditarUsuario;
window.fecharModalUsuario = fecharModalUsuario;
window.salvarUsuario      = salvarUsuario;
window.deletarUsuario     = deletarUsuario;
window.alternarBloqueioUsuario = alternarBloqueioUsuario;
window.atualizarVisibilidadePermissoes = atualizarVisibilidadePermissoes;
window.mostrarCredenciaisFuncionario = mostrarCredenciaisFuncionario;
window.fecharModalCredenciaisFuncionario = fecharModalCredenciaisFuncionario;
window.copiarCredenciaisFuncionario = copiarCredenciaisFuncionario;


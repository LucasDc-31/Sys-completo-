/**
 * reports-armacoes.js
 * Relatório específico de armações
 * (Extraído de script.js, linhas 2556-2772 do arquivo original)
 */

// ============================================
// RELATÓRIO DE ARMAÇÕES (SEM DASHBOARD/GRÁFICOS)
// ============================================

async function gerarRelatorioArmacoes() {
    const dataInicio = document.getElementById('dataInicioArm').value;
    const dataFim = document.getElementById('dataFimArm').value;
    const modeloId = document.getElementById('filtroModeloArm').value;
    
    let armacoesFiltradas = armacoes.filter(a => {
        if (dataInicio && a.data < dataInicio) return false;
        if (dataFim && a.data > dataFim) return false;
        if (modeloId && a.modeloId != modeloId) return false;
        return true;
    });
    
    armacoesFiltradas.sort((a, b) => a.data.localeCompare(b.data));
    
    renderizarResumoArmacoes(armacoesFiltradas);
    renderizarTabelaArmacoes(armacoesFiltradas);
}

function renderizarResumoArmacoes(armacoesFiltradas) {
    const resumoContainer = document.getElementById('resumoArmacoes');
    if (!resumoContainer) return;
    
    const totalChegadas = armacoesFiltradas.length;
    const totalQuantidade = armacoesFiltradas.reduce((acc, a) => acc + a.quantidade, 0);
    
    const modelosCount = {};
    armacoesFiltradas.forEach(a => {
        const peca = pecas.find(p => p.id === a.modeloId);
        const nomeModelo = peca ? peca.nome : 'Modelo removido';
        modelosCount[nomeModelo] = (modelosCount[nomeModelo] || 0) + a.quantidade;
    });
    
    let modeloMaisRecebido = { nome: '-', quantidade: 0 };
    for (const [nome, qtd] of Object.entries(modelosCount)) {
        if (qtd > modeloMaisRecebido.quantidade) {
            modeloMaisRecebido = { nome, quantidade: qtd };
        }
    }
    
    const datasUnicas = new Set(armacoesFiltradas.map(a => a.data));
    const mediaPorDia = datasUnicas.size > 0 ? (totalQuantidade / datasUnicas.size).toFixed(1) : 0;
    
    resumoContainer.innerHTML = `
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 30px;">
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 20px; border-radius: 12px; color: white; text-align: center;">
                <div style="font-size: 28px; font-weight: bold;">${totalQuantidade}</div>
                <div style="font-size: 12px; opacity: 0.9;">Total de Armações</div>
            </div>
            <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); padding: 20px; border-radius: 12px; color: white; text-align: center;">
                <div style="font-size: 28px; font-weight: bold;">${totalChegadas}</div>
                <div style="font-size: 12px; opacity: 0.9;">Total de Chegadas</div>
            </div>
            <div style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); padding: 20px; border-radius: 12px; color: white; text-align: center;">
                <div style="font-size: 20px; font-weight: bold; word-break: break-word;">${esc(modeloMaisRecebido.nome)}</div>
                <div style="font-size: 12px; opacity: 0.9;">Modelo Mais Recebido</div>
                <div style="font-size: 14px; margin-top: 5px;">${modeloMaisRecebido.quantidade} unidades</div>
            </div>
            <div style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); padding: 20px; border-radius: 12px; color: white; text-align: center;">
                <div style="font-size: 28px; font-weight: bold;">${mediaPorDia}</div>
                <div style="font-size: 12px; opacity: 0.9;">Média por Dia</div>
            </div>
        </div>
    `;
}

function renderizarTabelaArmacoes(armacoesFiltradas) {
    const tbody = document.querySelector('#tabelaRelatorioArmacoes tbody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    if (armacoesFiltradas.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center" style="padding: 40px;">
                    📭 Nenhum registro de armação encontrado no período
                 </td>
             </tr>
        `;
        document.getElementById('totalArmacoesPeriodo').textContent = '0';
        return;
    }
    
    const diasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
    
    let acumuladoPorModelo = {};
    let totalGeral = 0;
    
    armacoesFiltradas.forEach(a => {
        const dataObj = new Date(a.data + 'T00:00:00');
        const diaSemana = diasSemana[dataObj.getDay()];
        const peca = pecas.find(p => p.id === a.modeloId);
        const modeloNome = peca ? peca.nome : 'Modelo removido';
        
        acumuladoPorModelo[a.modeloId] = (acumuladoPorModelo[a.modeloId] || 0) + a.quantidade;
        totalGeral += a.quantidade;
        
        const tr = document.createElement('tr');
        tr.innerHTML = `
             <td>${formatarData(a.data)}</td>
             <td>${diaSemana}</td>
             <td>${esc(modeloNome)}</td>
             <td>${a.quantidade}</td>
             <td>${acumuladoPorModelo[a.modeloId]}</td>
        `;
        tbody.appendChild(tr);
    });
    
    document.getElementById('totalArmacoesPeriodo').textContent = totalGeral;
}

function exportarRelatorioArmacoes() {
    const dataInicio = document.getElementById('dataInicioArm').value;
    const dataFim = document.getElementById('dataFimArm').value;
    const modeloId = document.getElementById('filtroModeloArm').value;
    
    let armacoesFiltradas = armacoes.filter(a => {
        if (dataInicio && a.data < dataInicio) return false;
        if (dataFim && a.data > dataFim) return false;
        if (modeloId && a.modeloId != modeloId) return false;
        return true;
    });
    
    if (armacoesFiltradas.length === 0) {
        toast('Não há registros para exportar.', 'warn');
        return;
    }
    
    armacoesFiltradas.sort((a, b) => a.data.localeCompare(b.data));
    
    const totalChegadas = armacoesFiltradas.length;
    const totalQuantidade = armacoesFiltradas.reduce((acc, a) => acc + a.quantidade, 0);
    
    const modelosCount = {};
    armacoesFiltradas.forEach(a => {
        const peca = pecas.find(p => p.id === a.modeloId);
        const nomeModelo = peca ? peca.nome : 'Modelo removido';
        modelosCount[nomeModelo] = (modelosCount[nomeModelo] || 0) + a.quantidade;
    });
    
    let modeloMaisRecebido = { nome: '-', quantidade: 0 };
    for (const [nome, qtd] of Object.entries(modelosCount)) {
        if (qtd > modeloMaisRecebido.quantidade) {
            modeloMaisRecebido = { nome, quantidade: qtd };
        }
    }
    
    const datasUnicas = new Set(armacoesFiltradas.map(a => a.data));
    const mediaPorDia = datasUnicas.size > 0 ? (totalQuantidade / datasUnicas.size).toFixed(2) : 0;
    
    const diasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
    
    let csv = '='.repeat(100) + '\n';
    csv += 'RELATÓRIO DE ARMAÇÕES - SYSCADEIRAS\n';
    csv += '='.repeat(100) + '\n\n';
    
    csv += `PERÍODO: ${dataInicio ? formatarData(dataInicio) : 'TODOS'} até ${dataFim ? formatarData(dataFim) : 'TODOS'}\n`;
    csv += `DATA DE GERAÇÃO: ${new Date().toLocaleString('pt-BR')}\n`;
    csv += `TOTAL DE REGISTROS: ${armacoesFiltradas.length}\n\n`;
    
    csv += 'FILTROS APLICADOS:\n';
    csv += `- Modelo: ${modeloId ? (pecas.find(p => p.id == modeloId)?.nome || 'Todos') : 'Todos'}\n\n`;
    
    csv += '-'.repeat(100) + '\n';
    csv += 'RESUMO DO PERÍODO\n';
    csv += '-'.repeat(100) + '\n\n';
    
    csv += `Total de Armações Recebidas: ${totalQuantidade}\n`;
    csv += `Total de Chegadas: ${totalChegadas}\n`;
    csv += `Modelo Mais Recebido: ${modeloMaisRecebido.nome} (${modeloMaisRecebido.quantidade} unidades)\n`;
    csv += `Média de Armações por Dia: ${mediaPorDia}\n\n`;
    
    csv += '-'.repeat(100) + '\n';
    csv += 'DETALHAMENTO POR DATA\n';
    csv += '-'.repeat(100) + '\n';
    
    csv += 'Data;Dia Semana;Modelo;Quantidade;Acumulado do Modelo\n';
    
    let acumuladoPorModelo = {};
    armacoesFiltradas.forEach(a => {
        const dataObj = new Date(a.data + 'T00:00:00');
        const diaSemana = diasSemana[dataObj.getDay()];
        const peca = pecas.find(p => p.id === a.modeloId);
        const modeloNome = peca ? peca.nome : 'Modelo removido';
        
        acumuladoPorModelo[a.modeloId] = (acumuladoPorModelo[a.modeloId] || 0) + a.quantidade;
        
        csv += `${formatarData(a.data)};${diaSemana};${modeloNome};${a.quantidade};${acumuladoPorModelo[a.modeloId]}\n`;
    });
    
    csv += '\n' + '='.repeat(100) + '\n';
    csv += 'FIM DO RELATÓRIO\n';
    csv += '='.repeat(100) + '\n';
    
    const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    
    let nomeArquivo = 'relatorio_armacoes';
    if (dataInicio) nomeArquivo += `_${dataInicio}`;
    if (dataFim) nomeArquivo += `_a_${dataFim}`;
    nomeArquivo += '.csv';
    
    link.setAttribute('download', nomeArquivo);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast('Relatório de armações exportado! ' + armacoesFiltradas.length + ' registros.', 'success');
}


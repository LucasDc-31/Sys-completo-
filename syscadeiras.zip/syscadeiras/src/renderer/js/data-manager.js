/**
 * data-manager.js
 * Gerenciador central de dados (CRUD em memória/IPC)
 * (Extraído de script.js, linhas 801-883 do arquivo original)
 */

// ============================================
// GERENCIADOR CENTRAL DE DADOS
// ============================================
const DataManager = {
    async refreshData() {
        try {
            console.log('🔄 Recarregando dados...');
            await this.loadDataFromDB();
            UIManager.refreshAllSelects();
            UIManager.refreshAllTables();
            console.log('✅ Dados atualizados');
        } catch (error) {
            console.error('❌ Erro ao recarregar dados:', error);
        }
    },

    async loadDataFromDB() {
        try {
            const pecasResult = await window.electronAPI.database.all('SELECT * FROM Pecas ORDER BY nome');
            pecas = pecasResult.success ? pecasResult.result : [];

            const coresResult = await window.electronAPI.database.all('SELECT * FROM Cores ORDER BY nome');
            cores = coresResult.success ? coresResult.result : [];

            const funcResult = await window.electronAPI.database.all('SELECT * FROM Funcionarios ORDER BY nome');
            funcionarios = funcResult.success ? funcResult.result : [];

            const prodResult = await window.electronAPI.database.all('SELECT * FROM Producoes ORDER BY data DESC');
            producoes = prodResult.success ? prodResult.result : [];

            const movResult = await window.electronAPI.database.all('SELECT * FROM Movimentacoes ORDER BY data DESC');
            movimentacoes = movResult.success ? movResult.result : [];

            const armacoesResult = await window.electronAPI.database.all('SELECT * FROM Armações ORDER BY data DESC');
            armacoes = armacoesResult.success ? armacoesResult.result : [];

            const estoqueResult = await window.electronAPI.database.all('SELECT * FROM EstoqueArmacoes');
            estoqueArmacoes = estoqueResult.success ? estoqueResult.result : [];

            const usuariosResult = await window.electronAPI.database.all('SELECT id, nome, email, role, ativo, permissoes, funcionarioId FROM Usuarios ORDER BY nome');
            usuarios = usuariosResult.success
                ? usuariosResult.result.map(u => {
                    // O SQLite guarda permissoes como TEXT (JSON serializado);
                    // aqui é onde a lista global "usuarios" ganha vida em
                    // memória — sem este parse, todo card de usuário (e o
                    // filtro de sub-permissões de relatório) quebraria
                    // silenciosamente toda vez que refreshData() rodasse.
                    let permissoes = [];
                    try { permissoes = typeof u.permissoes === 'string' ? JSON.parse(u.permissoes) : (u.permissoes || []); }
                    catch (_) { permissoes = []; }
                    return { ...u, permissoes };
                })
                : [];

            console.log('✅ Dados carregados:', {
                pecas: pecas.length, cores: cores.length,
                funcionarios: funcionarios.length, producoes: producoes.length,
                movimentacoes: movimentacoes.length, armacoes: armacoes.length,
                estoqueArmacoes: estoqueArmacoes.length, usuarios: usuarios.length
            });
        } catch (error) {
            console.error('❌ Erro ao carregar dados:', error);
            throw error;
        }
    },

    findById(array, id) {
        return array.find(item => item.id === parseInt(id));
    },

    async loadArmacoesFromDB() {
        try {
            const armacoesResult = await window.electronAPI.database.all('SELECT * FROM Armações ORDER BY data DESC');
            armacoes = armacoesResult.success ? armacoesResult.result : [];
            
            const estoqueResult = await window.electronAPI.database.all('SELECT * FROM EstoqueArmacoes');
            estoqueArmacoes = estoqueResult.success ? estoqueResult.result : [];
        } catch (error) {
            console.error('❌ Erro ao carregar armações:', error);
        }
    }
};


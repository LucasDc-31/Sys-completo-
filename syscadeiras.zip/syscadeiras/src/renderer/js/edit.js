/**
 * edit.js
 * Funções de edição de registros
 * (Extraído de script.js, linhas 1241-1353 do arquivo original)
 */

// ============================================
// FUNÇÕES DE EDIÇÃO
// ============================================

function editarPeca(id) {
    const peca = DataManager.findById(pecas, id);
    if (!peca) return;
    
    FormManager.fillForEdit('peca', {
        pecaId: peca.id,
        nomePeca: peca.nome,
        valorPeca: peca.valor
    });
}

function editarFuncionario(id) {
    const funcionario = DataManager.findById(funcionarios, id);
    if (!funcionario) return;
    
    FormManager.fillForEdit('funcionario', {
        funcionarioId: funcionario.id,
        nomeFuncionario: funcionario.nome,
        cargoFuncionario: funcionario.cargo
    });
}

function editarCor(id) {
    const cor = DataManager.findById(cores, id);
    if (!cor) return;
    
    FormManager.fillForEdit('cor', {
        corId: cor.id,
        nomeCor: cor.nome
    });
}

function editarProducao(id) {
    const producao = DataManager.findById(producoes, id);
    if (!producao) return;

    // Contas não-admin vinculadas a um funcionário só podem editar a própria
    // produção, lançada hoje — mesma regra aplicada na criação, validada de
    // verdade no processo principal (main.js); aqui é só para não deixar o
    // usuário preencher o formulário achando que vai conseguir salvar.
    if (usuarioRestritoAPropriaProducao()) {
        if (producao.funcionarioId !== currentUser.funcionarioId) {
            toast('🔒 Você só pode editar sua própria produção.', 'warn');
            return;
        }
        if (producao.data !== hojeISO()) {
            toast('🔒 Você só pode editar produção lançada hoje.', 'warn');
            return;
        }
    }

    document.getElementById('producaoId').value = producao.id;
    document.getElementById('dataProducao').value = producao.data;
    document.getElementById('funcionarioProducao').value = producao.funcionarioId;

    const primeiroItem = document.querySelector('.itemProducao[data-index="0"], .itemProducao:first-child');
    if (primeiroItem) {
        const pecaSelect = primeiroItem.querySelector('#pecaProducao, .peca-select');
        if (pecaSelect) pecaSelect.value = producao.pecaId;
        
        const corSelect = primeiroItem.querySelector('#corProducao, .cor-select');
        if (corSelect) corSelect.value = producao.corId;
        
        const quantidadeInput = primeiroItem.querySelector('.quantidade, #quantidade');
        if (quantidadeInput) quantidadeInput.value = producao.quantidade;
        
        const checkbox = primeiroItem.querySelector('.hora-extra-checkbox, #horaExtra');
        if (checkbox) checkbox.checked = producao.horaExtra || false;
    }

    FormManager.setEditingMode('producao', true);
}

function editarArmacao(id) {
    const armacao = DataManager.findById(armacoes, id);
    if (!armacao) return;
    
    FormManager.fillForEdit('armacao', {
        armacaoId: armacao.id,
        dataArmacao: armacao.data,
        modeloArmacao: armacao.modeloId,
        quantidadeArmacao: armacao.quantidade
    });
}

function cancelarEdicaoPeca() {
    FormManager.cancelEditing('peca');
}

function cancelarEdicaoFuncionario() {
    FormManager.cancelEditing('funcionario');
}

function cancelarEdicaoCor() {
    FormManager.cancelEditing('cor');
}

function cancelarEdicao() {
    FormManager.cancelEditing('producao');
}

function cancelarSaida() {
    FormManager.cancelEditing('saida');
}

function cancelarEdicaoArmacao() {
    FormManager.cancelEditing('armacao');
}


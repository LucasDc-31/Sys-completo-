/**
 * app-init.js
 * Inicialização da aplicação (bootstrap, listeners iniciais)
 * (Extraído de script.js, linhas 1703-1993 do arquivo original)
 */

// ============================================
// INICIALIZAÇÃO
// ============================================

document.addEventListener('DOMContentLoaded', async function() {
    // Frase motivacional da tela de login — mesma experiência do Mobile
    exibirFraseLogin();

    // Inicializa o banco antes de mostrar login
    // (necessário para verificarEstrutura criar admin padrão)
    try {
        await window.electronAPI.database.init();
    } catch (e) {
        console.error('Erro ao inicializar banco:', e);
    }
    // Mostra tela de login — o usuário precisa autenticar antes de ver o app
    // O login chama inicializarSistema() após autenticação bem-sucedida
});

// Contas não-admin vinculadas a um funcionário (login pessoal criado no
// cadastro) só podem lançar/editar produção:
//   1) com a data de hoje;
//   2) em nome de si mesmas.
// Trava os campos (readonly/disabled) e mostra avisos explicando o porquê.
// A validação que realmente protege os dados fica no processo principal
// (verificarRestricoesProducao em main.js); isto aqui é só para guiar o
// usuário e evitar que ele preencha um formulário que o sistema vai recusar.
function aplicarRestricaoDataProducao() {
    const campoData = document.getElementById('dataProducao');
    const aviso = document.getElementById('avisoDataProducaoTravada');
    const selectFunc = document.getElementById('funcionarioProducao');
    const avisoFunc = document.getElementById('avisoFuncionarioProducaoTravado');

    const restrito = usuarioRestritoAPropriaProducao();

    if (campoData) {
        campoData.readOnly = restrito;
        campoData.disabled = false; // mantém disabled=false para o valor ser enviado no submit
        if (restrito) {
            const hoje = hojeISO();
            campoData.value = hoje;
            campoData.min = hoje;
            campoData.max = hoje;
            campoData.style.opacity = '0.7';
            campoData.style.cursor = 'not-allowed';
            if (aviso) aviso.style.display = 'block';
        } else {
            campoData.removeAttribute('min');
            campoData.removeAttribute('max');
            campoData.style.opacity = '';
            campoData.style.cursor = '';
            if (aviso) aviso.style.display = 'none';
        }
    }

    if (selectFunc) {
        if (restrito) {
            // Só a própria opção fica disponível — nem dá pra escolher outro
            // funcionário, mesmo tentando editar o HTML pelo DevTools, porque
            // o processo principal recusa qualquer funcionarioId diferente.
            const meuFuncionario = funcionarios.find(f => f.id === currentUser.funcionarioId);
            selectFunc.innerHTML = '';
            const opt = document.createElement('option');
            opt.value = currentUser.funcionarioId;
            opt.textContent = meuFuncionario ? meuFuncionario.nome : currentUser.nome;
            selectFunc.appendChild(opt);
            selectFunc.value = currentUser.funcionarioId;
            selectFunc.disabled = true;
            selectFunc.style.opacity = '0.7';
            selectFunc.style.cursor = 'not-allowed';
            if (avisoFunc) avisoFunc.style.display = 'block';
        } else {
            selectFunc.disabled = false;
            selectFunc.style.opacity = '';
            selectFunc.style.cursor = '';
            if (avisoFunc) avisoFunc.style.display = 'none';
            // Repopula normalmente com todos os funcionários (caso tivesse
            // ficado restrito a 1 opção antes, ex: troca de conta sem reload).
            UIManager.refreshSelect('funcionarioProducao', funcionarios, 'Selecione um funcionário');
        }
    }
}

async function inicializarSistema() {
    try {
        console.log('🚀 Inicializando sistema SysCadeiras...');

        await transferirDadosLocalStorage();

        await DataManager.loadDataFromDB();

        FormManager.init();

        inicializarAplicacao();

        configurarPWA();
        iniciarSyncListeners();

        // Trava o campo de data e o funcionário na tela de Produção para
        // contas não-admin vinculadas a um funcionário (só hoje, só si mesmo)
        aplicarRestricaoDataProducao();
        // Esconde relatórios que não são de produção pessoal (Estoque/Armações)
        aplicarRestricaoTiposRelatorio();

        // Atualizar seção de usuários se estiver visível
        if (currentUser?.role === 'admin') {
            renderizarUsuarios();
        }

        console.log('✅ Sistema inicializado para:', currentUser?.nome);

    } catch (error) {
        console.error('❌ Erro crítico na inicialização:', error);
        toast('Erro ao inicializar o sistema. Recarregue a página.', 'error');
    }
}

async function transferirDadosLocalStorage() {
    const temPecas = localStorage.getItem('pecas');
    const temFuncionarios = localStorage.getItem('funcionarios');
    const temCores = localStorage.getItem('cores');
    const temProducoes = localStorage.getItem('producoes');
    const temMovimentacoes = localStorage.getItem('movimentacoes');
    
    if (temPecas || temFuncionarios || temCores || temProducoes || temMovimentacoes) {
        const modal = document.getElementById('modalMigracao');
        const progresso = document.getElementById('progressoMigracao');
        const status = document.getElementById('statusMigracao');
        const log = document.getElementById('logMigracao');
        
        modal.style.display = 'flex';
        log.innerHTML = '';
        
        function adicionarLog(msg) {
            log.innerHTML += `<div>${msg}</div>`;
            log.scrollTop = log.scrollHeight;
        }
        
        try {
            adicionarLog('📦 Iniciando transferência de dados...');
            
            if (temPecas) {
                const pecasLocal = JSON.parse(temPecas);
                adicionarLog(`📦 Transferindo ${pecasLocal.length} peças...`);
                
                for (const peca of pecasLocal) {
                    await window.electronAPI.database.run(
                        'INSERT OR IGNORE INTO Pecas (id, nome, valor) VALUES (?, ?, ?)',
                        [peca.id, peca.nome, peca.valor]
                    );
                }
            }
            
            progresso.style.width = '20%';
            status.textContent = 'Peças transferidas...';
            
            if (temCores) {
                const coresLocal = JSON.parse(temCores);
                adicionarLog(`🎨 Transferindo ${coresLocal.length} cores...`);
                
                for (const cor of coresLocal) {
                    await window.electronAPI.database.run(
                        'INSERT OR IGNORE INTO Cores (id, nome) VALUES (?, ?)',
                        [cor.id, cor.nome]
                    );
                }
            }
            
            progresso.style.width = '40%';
            status.textContent = 'Cores transferidas...';
            
            if (temFuncionarios) {
                const funcLocal = JSON.parse(temFuncionarios);
                adicionarLog(`👷 Transferindo ${funcLocal.length} funcionários...`);
                
                for (const func of funcLocal) {
                    await window.electronAPI.database.run(
                        'INSERT OR IGNORE INTO Funcionarios (id, nome, cargo) VALUES (?, ?, ?)',
                        [func.id, func.nome, func.cargo]
                    );
                }
            }
            
            progresso.style.width = '60%';
            status.textContent = 'Funcionários transferidos...';
            
            if (temProducoes) {
                const prodLocal = JSON.parse(temProducoes);
                adicionarLog(`🏭 Transferindo ${prodLocal.length} produções...`);
                
                for (const prod of prodLocal) {
                    await window.electronAPI.database.run(
                        'INSERT OR IGNORE INTO Producoes (id, data, funcionarioId, pecaId, corId, quantidade, horaExtra) VALUES (?, ?, ?, ?, ?, ?, ?)',
                        [prod.id, prod.data, prod.funcionarioId, prod.pecaId, prod.corId, prod.quantidade, prod.horaExtra ? 1 : 0]
                    );
                }
            }
            
            progresso.style.width = '80%';
            status.textContent = 'Produções transferidas...';
            
            if (temMovimentacoes) {
                const movLocal = JSON.parse(temMovimentacoes);
                adicionarLog(`📊 Transferindo ${movLocal.length} movimentações...`);
                
                for (const mov of movLocal) {
                    await window.electronAPI.database.run(
                        'INSERT OR IGNORE INTO Movimentacoes (id, data, tipo, pecaId, corId, quantidade, origem, producaoId, funcionarioId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                        [mov.id, mov.data, mov.tipo, mov.pecaId, mov.corId, mov.quantidade, mov.origem, mov.producaoId, mov.funcionarioId]
                    );
                }
            }
            
            progresso.style.width = '100%';
            status.textContent = '✅ Transferência concluída!';
            
            localStorage.clear();
            
            adicionarLog('✅ Todos os dados foram transferidos com sucesso!');
            adicionarLog('🗑️ localStorage limpo.');
            
            setTimeout(() => {
                modal.style.display = 'none';
            }, 2000);
            
        } catch (error) {
            adicionarLog(`❌ Erro na transferência: ${error.message}`);
            status.textContent = '❌ Erro na transferência';
            console.error('Erro na migração:', error);
        }
    }
}

function inicializarAplicacao() {
    producoes = producoes.map(p => ({ corId: p.corId !== undefined ? p.corId : null, ...p }));
    movimentacoes = movimentacoes.map(m => ({ corId: m.corId !== undefined ? m.corId : null, ...m }));
    
    UIManager.refreshAllSelects();
    UIManager.refreshAllTables();
    
    document.getElementById('dataProducao').value = hojeISO();
    document.getElementById('dataSaida').value = hojeISO();
    document.getElementById('dataArmacao').value = hojeISO();
    document.getElementById('mesFolha').value = hojeISO().substring(0, 7);
    
    configurarEventListeners();
    
    console.log('✅ Aplicação inicializada com sucesso!');
}

function configurarEventListeners() {
    // Evita listeners duplicados no botão de pesquisa
    if (window._eventListenersConfigurados) return;
    window._eventListenersConfigurados = true;

    const hoje = hojeISO();
    document.querySelectorAll('input[type="date"]').forEach(input => {
        if (!input.value) input.value = hoje;
    });

    const pe = document.getElementById('pesquisaEstoque');
    if (pe) {
        pe.addEventListener('keyup', function() {
            clearTimeout(timeoutPesquisa);
            timeoutPesquisa = setTimeout(pesquisarEstoque, 500);
        });
    }
}

function configurarPWA() {
    const btnInstall = document.getElementById('btnInstall');
    if (!btnInstall) return; // Desktop Electron não usa PWA install

    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        btnInstall.style.display = 'block';
    });

    btnInstall.addEventListener('click', async () => {
        if (deferredPrompt) {
            deferredPrompt.prompt();
            const { outcome } = await deferredPrompt.userChoice;
            if (outcome === 'accepted') {
                btnInstall.style.display = 'none';
            }
            deferredPrompt = null;
        }
    });
}


/**
 * reports.js
 * Funções de relatórios (geral)
 * (Extraído de script.js, linhas 2260-2555 do arquivo original)
 */

// ============================================
// FUNÇÕES DE RELATÓRIOS
// ============================================

// Mapa entre o "tipo" interno usado pelo relatório (o mesmo valor passado
// pra mudarTipoRelatorio) e o id de sub-permissão correspondente em
// TIPOS_RELATORIO_DISPONIVEIS. Só o relatório de Produção usa nomes
// diferentes ('geral' internamente vs 'producao' como permissão).
const TIPO_RELATORIO_PARA_PERMISSAO = { geral: 'producao', modelos: 'modelos', folha: 'folha', armacoes: 'armacoes', estoque: 'estoque' };

function mudarTipoRelatorio(tipo) {
    // Defesa em profundidade: mesmo se alguém chamar isto direto pelo
    // console, a conta não consegue abrir um tipo de relatório que o admin
    // não marcou pra ela — cai no primeiro tipo permitido.
    const idPermissao = TIPO_RELATORIO_PARA_PERMISSAO[tipo] || tipo;
    if (!podeVerTipoRelatorio(idPermissao)) {
        const permitidos = tiposRelatorioPermitidos();
        const primeiroTipoPermitido = Object.keys(TIPO_RELATORIO_PARA_PERMISSAO)
            .find(t => permitidos.includes(TIPO_RELATORIO_PARA_PERMISSAO[t]));
        if (!primeiroTipoPermitido) return; // sem nenhum tipo liberado — não troca pra lugar nenhum
        tipo = primeiroTipoPermitido;
    }

    tipoRelatorioAtual = tipo;
    
    document.querySelectorAll('.tipo-relatorio button').forEach(btn => {
        btn.classList.remove('active');
    });
    const btnId = `btnRelatorio${tipo.charAt(0).toUpperCase() + tipo.slice(1)}`;
    const btnElement = document.getElementById(btnId);
    if (btnElement) btnElement.classList.add('active');
    
    document.getElementById('filtrosRelatorioGeral').style.display = tipo === 'geral' ? 'block' : 'none';
    document.getElementById('filtrosRelatorioModelos').style.display = tipo === 'modelos' ? 'block' : 'none';
    document.getElementById('filtrosRelatorioEstoque').style.display = tipo === 'estoque' ? 'block' : 'none';
    document.getElementById('filtrosRelatorioFolha').style.display = tipo === 'folha' ? 'block' : 'none';
    document.getElementById('filtrosRelatorioArmacoes').style.display = tipo === 'armacoes' ? 'block' : 'none';
    
    document.getElementById('resultadoRelatorioGeral').style.display = tipo === 'geral' ? 'block' : 'none';
    document.getElementById('resultadoRelatorioModelos').style.display = tipo === 'modelos' ? 'block' : 'none';
    document.getElementById('resultadoRelatorioEstoque').style.display = tipo === 'estoque' ? 'block' : 'none';
    document.getElementById('resultadoRelatorioFolha').style.display = tipo === 'folha' ? 'block' : 'none';
    document.getElementById('resultadoRelatorioArmacoes').style.display = tipo === 'armacoes' ? 'block' : 'none';
    
    if (tipo === 'armacoes') {
        setTimeout(() => gerarRelatorioArmacoes(), 100);
    }
}

// Mostra no menu de relatórios só os tipos que o admin liberou para esta
// conta (checkboxes de sub-permissão dentro de "Relatórios" no cadastro do
// usuário). Se o tipo aberto no momento não é mais permitido, troca para o
// primeiro que for. Também trava o filtro "Funcionário" do relatório de
// Produção para quem só pode ver a própria produção (conta vinculada a um
// funcionário) — isso é sobre OS DADOS, independente de quais telas de
// relatório a conta enxerga.
function aplicarRestricaoTiposRelatorio() {
    const permitidos = tiposRelatorioPermitidos();
    const mapaBotoes = { geral: 'btnRelatorioGeral', modelos: 'btnRelatorioModelos', folha: 'btnRelatorioFolha', armacoes: 'btnRelatorioArmacoes', estoque: 'btnRelatorioEstoque' };

    Object.entries(mapaBotoes).forEach(([tipo, btnId]) => {
        const btn = document.getElementById(btnId);
        if (!btn) return;
        const idPermissao = TIPO_RELATORIO_PARA_PERMISSAO[tipo] || tipo;
        btn.style.display = permitidos.includes(idPermissao) ? '' : 'none';
    });

    const idPermissaoAtual = TIPO_RELATORIO_PARA_PERMISSAO[tipoRelatorioAtual] || tipoRelatorioAtual;
    if (!permitidos.includes(idPermissaoAtual)) {
        const primeiroTipoPermitido = Object.keys(TIPO_RELATORIO_PARA_PERMISSAO)
            .find(t => permitidos.includes(TIPO_RELATORIO_PARA_PERMISSAO[t]));
        if (primeiroTipoPermitido) mudarTipoRelatorio(primeiroTipoPermitido);
    }

    // No relatório de Produção, o filtro "Funcionário" não faz sentido para
    // quem só pode ver a si mesmo — trava nele e esconde a escolha.
    const restritoAPropriaProducao = usuarioRestritoAPropriaProducao();
    const filtroFunc = document.getElementById('filtroFuncionario');
    const linhaFiltroFunc = filtroFunc?.closest('.fg');
    if (filtroFunc) {
        if (restritoAPropriaProducao) {
            filtroFunc.innerHTML = '';
            const opt = document.createElement('option');
            opt.value = currentUser.funcionarioId;
            const meuFuncionario = funcionarios.find(f => f.id === currentUser.funcionarioId);
            opt.textContent = meuFuncionario ? meuFuncionario.nome : currentUser.nome;
            filtroFunc.appendChild(opt);
            filtroFunc.value = currentUser.funcionarioId;
            filtroFunc.disabled = true;
            if (linhaFiltroFunc) linhaFiltroFunc.style.display = 'none';
        } else {
            filtroFunc.disabled = false;
            if (linhaFiltroFunc) linhaFiltroFunc.style.display = '';
        }
    }
}

window.aplicarRestricaoTiposRelatorio = aplicarRestricaoTiposRelatorio;

function gerarRelatorio() {
    if (tipoRelatorioAtual === 'geral') {
        gerarRelatorioGeral();
    } else if (tipoRelatorioAtual === 'modelos') {
        gerarRelatorioModelos();
    } else if (tipoRelatorioAtual === 'estoque') {
        gerarRelatorioEstoque();
    } else if (tipoRelatorioAtual === 'armacoes') {
        gerarRelatorioArmacoes();
    }
}

function gerarRelatorioGeral() {
    const dataInicio = document.getElementById('dataInicio').value;
    const dataFim = document.getElementById('dataFim').value;
    const funcionarioId = document.getElementById('filtroFuncionario').value;
    const pecaId = document.getElementById('filtroPeca').value;
    const corId = document.getElementById('filtroCor').value;
    
    let producoesFiltradas = producoesVisiveisParaUsuario().filter(p => {
        if (dataInicio && p.data < dataInicio) return false;
        if (dataFim && p.data > dataFim) return false;
        if (funcionarioId && p.funcionarioId != funcionarioId) return false;
        if (pecaId && p.pecaId != pecaId) return false;
        if (corId && p.corId != corId) return false;
        return true;
    });
    
    const tbody = document.querySelector('#tabelaRelatorio tbody');
    tbody.innerHTML = '';
    
    if (producoesFiltradas.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="9" class="text-center" style="padding: 40px;">
                    📭 Nenhuma produção encontrada com os filtros selecionados
                   </td>
               </tr>
        `;
        document.getElementById('totalGeral').textContent = formatarMoeda(0);
        return;
    }
    
    let totalGeral = 0;
    producoesFiltradas.forEach(producao => {
        const funcionario = DataManager.findById(funcionarios, producao.funcionarioId);
        const peca = DataManager.findById(pecas, producao.pecaId);
        const cor = DataManager.findById(cores, producao.corId);
        
        let valorUnitario = peca ? peca.valor : 0;
        let valorTotal = valorUnitario * producao.quantidade;
        
        if (producao.horaExtra) {
            valorUnitario = valorUnitario * 1.5;
            valorTotal = valorUnitario * producao.quantidade;
        }
        
        totalGeral += valorTotal;
        
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>
                <input type="checkbox" class="checkbox-selecao" value="${producao.id}" 
                       onchange="toggleProducaoSelecionada(${producao.id}, this.checked)">
             </td>
            <td>${formatarData(producao.data)}</td>
            <td>${esc(funcionario ? funcionario.nome : 'N/A')}</td>
            <td>${esc(peca ? peca.nome : 'N/A')}</td>
            <td>${esc(cor ? cor.nome : 'N/A')}</td>
            <td>${producao.quantidade}</td>
            <td>${producao.horaExtra ? '<span class="badge-tipo badge-pedido">SIM</span>' : 'Não'}</td>
            <td class="valor">${formatarMoeda(valorUnitario)}</td>
            <td class="valor">${formatarMoeda(valorTotal)}</td>
            <td>${(() => { const u = producao.login_user; if (!u) return '<span style="color:var(--muted);font-size:12px;">—</span>'; const isMob = u==='Mobile'||u.startsWith('mob'); return '<span class="badge-login'+(isMob?' mobile':'')+'">'+( isMob?'📱':'🖥️')+' '+esc(u)+'</span>'; })()}</td>
        `;
        tbody.appendChild(tr);
    });
    
    document.getElementById('totalGeral').textContent = formatarMoeda(totalGeral);
    producoesSelecionadas.clear();
    document.getElementById('selecionarTodos').checked = false;
}

function gerarRelatorioModelos() {
    const dataInicio = document.getElementById('dataInicioPeca').value;
    const dataFim = document.getElementById('dataFimPeca').value;
    
    // Este relatório mostra o total agregado produzido pela fábrica (por
    // modelo/cor), não é um relatório pessoal — por isso usa o array
    // completo de produções, mesmo para contas restritas à própria produção.
    let producoesFiltradas = producoes.filter(p => {
        if (dataInicio && p.data < dataInicio) return false;
        if (dataFim && p.data > dataFim) return false;
        return true;
    });
    
    const agrupado = {};
    producoesFiltradas.forEach(producao => {
        const key = `${producao.pecaId}-${producao.corId}`;
        if (!agrupado[key]) {
            agrupado[key] = { pecaId: producao.pecaId, corId: producao.corId, quantidade: 0 };
        }
        agrupado[key].quantidade += producao.quantidade;
    });
    
    const tbody = document.querySelector('#tabelaRelatorioModelos tbody');
    tbody.innerHTML = '';
    
    if (Object.keys(agrupado).length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="text-center" style="padding: 40px;">
                    📭 Nenhuma produção encontrada no período
                 </td>
             </tr>
        `;
        document.getElementById('totalGeralModelos').textContent = formatarMoeda(0);
        return;
    }
    
    let totalGeral = 0;
    Object.values(agrupado).forEach(item => {
        const peca = DataManager.findById(pecas, item.pecaId);
        const cor = DataManager.findById(cores, item.corId);
        const valorTotal = peca ? peca.valor * item.quantidade : 0;
        totalGeral += valorTotal;
        
        const tr = document.createElement('tr');
        tr.innerHTML = `
             <td>${esc(peca ? peca.nome : 'N/A')}</td>
             <td>${esc(cor ? cor.nome : 'N/A')}</td>
             <td>${item.quantidade}</td>
            <td class="valor">${peca ? formatarMoeda(peca.valor) : 'N/A'}</td>
            <td class="valor">${formatarMoeda(valorTotal)}</td>
        `;
        tbody.appendChild(tr);
    });
    
    document.getElementById('totalGeralModelos').textContent = formatarMoeda(totalGeral);
}

function gerarRelatorioEstoque() {
    const dataInicio = document.getElementById('dataInicioEst').value;
    const dataFim = document.getElementById('dataFimEst').value;
    const tipoMov = document.getElementById('tipoMovEst').value;
    const pecaId = document.getElementById('pecaEst').value;
    const corId = document.getElementById('corEst').value;
    
    let movFiltradas = movimentacoes.filter(m => {
        if (dataInicio && m.data < dataInicio) return false;
        if (dataFim && m.data > dataFim) return false;
        if (tipoMov && m.tipo !== tipoMov) return false;
        if (pecaId && m.pecaId != pecaId) return false;
        if (corId && m.corId != corId) return false;
        return true;
    });
    
    const tbody = document.querySelector('#tabelaRelatorioEstoque tbody');
    tbody.innerHTML = '';
    
    if (movFiltradas.length === 0) {
        tbody.innerHTML = `
             <tr>
                <td colspan="6" class="text-center" style="padding: 40px;">
                    📭 Nenhuma movimentação encontrada com os filtros selecionados
                 </td>
             </tr>
        `;
        document.getElementById('saldoPeriodo').textContent = '0';
        return;
    }
    
    let saldoPeriodo = 0;
    movFiltradas.forEach(mov => {
        const peca = DataManager.findById(pecas, mov.pecaId);
        const cor = DataManager.findById(cores, mov.corId);
        saldoPeriodo += mov.tipo === 'entrada' ? mov.quantidade : -mov.quantidade;
        
        const tr = document.createElement('tr');
        tr.innerHTML = `
             <td>${formatarData(mov.data)}</td>
             <td>
                ${mov.tipo === 'entrada' 
                    ? '<span class="badge-tipo badge-entrada">Entrada</span>' 
                    : '<span class="badge-tipo badge-saida">Saída</span>'}
              </td>
             <td>${esc(peca ? peca.nome : 'N/A')}</td>
             <td>${esc(cor ? cor.nome : 'N/A')}</td>
             <td>${mov.quantidade}</td>
             <td>${esc(mov.origem || '')}</td>
        `;
        tbody.appendChild(tr);
    });
    
    document.getElementById('saldoPeriodo').textContent = saldoPeriodo;
}


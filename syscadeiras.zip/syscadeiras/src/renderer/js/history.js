/**
 * history.js
 * Histórico de ações (admin) e detalhamento
 * (Extraído de script.js, linhas 4856-5121 do arquivo original)
 */

// ============================================
// HISTÓRICO (admin only)
// ============================================
// Rótulos amigáveis para exibir no lugar do nome técnico da tabela/ação.
const HIST_TABELA_LABEL = {
    producoes: '🏭 Produção', funcionarios: '👷 Funcionários', pecas: '🪑 Modelos',
    cores: '🎨 Cores', movimentacoes: '📦 Estoque / Saídas', armacoes: '🔩 Armações',
    'armações': '🔩 Armações', estoquearmacoes: '🔩 Estoque de Armações', usuarios: '👥 Usuários',
};
const HIST_ACAO_LABEL = {
    CRIAR: { texto: 'Criação', cor: 'var(--green2)', icone: '➕' },
    EDITAR: { texto: 'Edição', cor: 'var(--amber, #f39c12)', icone: '✏️' },
    EXCLUIR: { texto: 'Exclusão', cor: 'var(--red2)', icone: '🗑️' },
};

function labelTabelaHistorico(tabela) {
    return HIST_TABELA_LABEL[String(tabela || '').toLowerCase()] || tabela;
}

function formatarDataHistoricoTitulo(dataISO) {
    // dataISO no formato YYYY-MM-DD (o mesmo salvo pelo processo principal)
    try {
        const [ano, mes, dia] = dataISO.split('-');
        const d = new Date(Number(ano), Number(mes) - 1, Number(dia));
        const hojeStr = hojeISO();
        const ontem = new Date(); ontem.setDate(ontem.getDate() - 1);
        const ontemStr = `${ontem.getFullYear()}-${String(ontem.getMonth()+1).padStart(2,'0')}-${String(ontem.getDate()).padStart(2,'0')}`;
        const label = d.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });
        if (dataISO === hojeStr) return `Hoje — ${label}`;
        if (dataISO === ontemStr) return `Ontem — ${label}`;
        return label.charAt(0).toUpperCase() + label.slice(1);
    } catch (_) {
        return dataISO;
    }
}

function limparFiltrosHistorico() {
    document.getElementById('histDataInicio').value = '';
    document.getElementById('histDataFim').value = '';
    document.getElementById('histTabela').value = '';
    document.getElementById('histAcao').value = '';
    document.getElementById('histTexto').value = '';
    carregarHistoricoTela();
}

// Carrega o histórico do processo principal (só retorna algo se a sessão
// logada for admin — o backend já barra o resto) e renderiza agrupado por
// dia, com cada linha mostrando o horário exato da ação.
// Guarda os registros já carregados para a tela de Histórico, para que o
// modal de detalhes ("Ver exatamente o que foi feito") não precise buscar
// de novo no banco — só lê pelo id o que já está em memória.
let _historicoCarregado = [];

async function carregarHistoricoTela() {
    if (currentUser?.role !== 'admin') {
        toast('Acesso restrito a administradores.', 'error');
        return;
    }

    const container = document.getElementById('historicoLista');
    const resumo = document.getElementById('historicoResumo');
    if (!container) return;
    container.innerHTML = '<p style="color:var(--muted);">Carregando...</p>';

    const filtros = {
        dataInicio: document.getElementById('histDataInicio')?.value || undefined,
        dataFim: document.getElementById('histDataFim')?.value || undefined,
        tabela: document.getElementById('histTabela')?.value || undefined,
        acao: document.getElementById('histAcao')?.value || undefined,
        texto: document.getElementById('histTexto')?.value?.trim() || undefined,
        limite: 500,
    };

    const res = await window.electronAPI.historico.pesquisar(filtros);
    if (!res.success) {
        container.innerHTML = `<p style="color:var(--red2);">${res.error || 'Não foi possível carregar o histórico.'}</p>`;
        if (resumo) resumo.textContent = '';
        return;
    }

    const registros = res.result || [];
    _historicoCarregado = registros;
    if (resumo) resumo.textContent = `${registros.length} registro(s) encontrado(s)${registros.length === 500 ? ' (mostrando os 500 mais recentes)' : ''}.`;

    if (registros.length === 0) {
        container.innerHTML = '<p style="color:var(--muted);padding:20px;">📭 Nenhuma ação encontrada para os filtros selecionados.</p>';
        return;
    }

    // Agrupa por dia (a consulta já vem ordenada por data/hora desc)
    const porDia = {};
    registros.forEach(r => {
        if (!porDia[r.data]) porDia[r.data] = [];
        porDia[r.data].push(r);
    });

    container.innerHTML = Object.keys(porDia).map(dataISO => {
        const linhas = porDia[dataISO].map(r => {
            const acaoInfo = HIST_ACAO_LABEL[r.acao] || { texto: r.acao, cor: 'var(--muted)', icone: '•' };
            const temDetalhe = !!(r.dadosAntes || r.dadosDepois);
            return `
                <div style="display:flex;align-items:flex-start;gap:12px;padding:10px 14px;border-bottom:1px solid var(--border);">
                    <div style="font-family:monospace;font-size:12px;color:var(--muted);min-width:56px;padding-top:2px;">${(r.hora || '').slice(0,5)}</div>
                    <div style="min-width:90px;padding-top:1px;">
                        <span style="font-size:11px;font-weight:700;color:${acaoInfo.cor};background:rgba(255,255,255,.05);padding:2px 8px;border-radius:20px;white-space:nowrap;">${acaoInfo.icone} ${acaoInfo.texto}</span>
                    </div>
                    <div style="flex:1;min-width:0;">
                        <div style="font-size:13px;color:var(--text);">${escapeHtml(r.descricao || '')}</div>
                        <div style="font-size:11px;color:var(--muted);margin-top:2px;">${labelTabelaHistorico(r.tabela)}${r.registroId != null ? ' · #' + r.registroId : ''} — por ${escapeHtml(r.usuarioNome || 'Sistema')}</div>
                    </div>
                    <div style="padding-top:1px;">
                        ${temDetalhe ? `<button class="btn btn-sec btn-sm" style="white-space:nowrap;" onclick="mostrarDetalheHistorico(${r.id})">🔍 Detalhes</button>` : ''}
                    </div>
                </div>`;
        }).join('');

        return `
            <div style="margin-bottom:18px;">
                <div style="font-size:13px;font-weight:700;color:var(--text);text-transform:capitalize;padding:8px 4px;">📅 ${formatarDataHistoricoTitulo(dataISO)}</div>
                <div style="background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden;">
                    ${linhas}
                </div>
            </div>`;
    }).join('');
}

// Escapa HTML básico para exibir texto de usuário com segurança na lista.
function escapeHtml(texto) {
    const div = document.createElement('div');
    div.textContent = String(texto ?? '');
    return div.innerHTML;
}

// ============================================
// DETALHES DO HISTÓRICO — "o que foi feito exatamente"
// ============================================
// Rótulos amigáveis para as colunas mais comuns nas tabelas de negócio,
// para não mostrar o nome técnico cru (ex: 'funcionarioId' -> 'Funcionário').
const HIST_CAMPO_LABEL = {
    id: 'ID', nome: 'Nome', cargo: 'Cargo', data: 'Data', quantidade: 'Quantidade',
    funcionarioId: 'Funcionário', pecaId: 'Modelo', corId: 'Cor', horaExtra: 'Hora extra',
    valor: 'Valor', tipo: 'Tipo', origem: 'Origem', destino: 'Destino', observacao: 'Observação',
    email: 'E-mail', role: 'Perfil', ativo: 'Ativo', permissoes: 'Permissões',
    login_user: 'Registrado por', created_at: 'Criado em', ultimaAtualizacao: 'Última atualização',
    modeloId: 'Modelo',
};

function labelCampoHistorico(campo) {
    return HIST_CAMPO_LABEL[campo] || campo;
}

// Tenta trocar um valor de id cru por algo legível (nome do funcionário,
// do modelo, da cor), usando os dados já carregados em memória. Se não
// achar correspondência, devolve o valor original sem inventar nada.
function formatarValorHistorico(campo, valor) {
    if (valor === null || valor === undefined || valor === '') return '—';
    if (campo === 'funcionarioId') {
        const f = funcionarios.find(x => x.id == valor);
        return f ? `${f.nome} (#${valor})` : String(valor);
    }
    if (campo === 'pecaId' || campo === 'modeloId') {
        const p = pecas.find(x => x.id == valor);
        return p ? `${p.nome} (#${valor})` : String(valor);
    }
    if (campo === 'corId') {
        const c = cores.find(x => x.id == valor);
        return c ? `${c.nome} (#${valor})` : String(valor);
    }
    if (campo === 'ativo') return valor == 1 ? 'Sim' : 'Não';
    if (campo === 'horaExtra') return valor == 1 ? 'Sim' : 'Não';
    if (campo === 'role') return valor === 'admin' ? 'Administrador' : 'Operador';
    if (campo === 'senha_hash') return '••••••• (oculto)';
    if (campo === 'permissoes') {
        try {
            const arr = typeof valor === 'string' ? JSON.parse(valor) : valor;
            if (Array.isArray(arr)) {
                if (arr.includes('*')) return 'Acesso total';
                return arr.length ? arr.join(', ') : 'Nenhum acesso';
            }
        } catch (_) {}
        return String(valor);
    }
    return String(valor);
}

// Abre um modal mostrando exatamente o que aquela ação do histórico fez:
//   - CRIAR: lista todos os campos do registro criado.
//   - EXCLUIR: lista todos os campos do registro que foi apagado.
//   - EDITAR: compara campo a campo o que era antes e o que ficou depois,
//     destacando em verde/vermelho só os campos que realmente mudaram.
function mostrarDetalheHistorico(id) {
    const r = _historicoCarregado.find(x => x.id === id);
    if (!r) return;

    let antes = null, depois = null;
    try { antes = r.dadosAntes ? JSON.parse(r.dadosAntes) : null; } catch (_) {}
    try { depois = r.dadosDepois ? JSON.parse(r.dadosDepois) : null; } catch (_) {}

    const acaoInfo = HIST_ACAO_LABEL[r.acao] || { texto: r.acao, cor: 'var(--muted)', icone: '•' };
    let corpoHtml = '';

    if (r.acao === 'EDITAR' && antes && depois) {
        // Une as chaves dos dois objetos (algum campo pode ter sido
        // adicionado/removido entre uma versão e outra do sistema).
        const todosCampos = Array.from(new Set([...Object.keys(antes), ...Object.keys(depois)]))
            .filter(c => !['id', 'created_at'].includes(c)); // ruído, não interessa mostrar
        const linhas = todosCampos.map(campo => {
            const valorAntes = antes[campo];
            const valorDepois = depois[campo];
            const mudou = JSON.stringify(valorAntes) !== JSON.stringify(valorDepois);
            if (!mudou) return ''; // só mostra o que realmente mudou
            return `
                <tr>
                    <td style="padding:8px 10px;color:var(--muted);font-size:12px;white-space:nowrap;">${escapeHtml(labelCampoHistorico(campo))}</td>
                    <td style="padding:8px 10px;color:var(--red2);font-size:12.5px;">${escapeHtml(formatarValorHistorico(campo, valorAntes))}</td>
                    <td style="padding:8px 4px;color:var(--muted);text-align:center;">→</td>
                    <td style="padding:8px 10px;color:var(--green2);font-size:12.5px;">${escapeHtml(formatarValorHistorico(campo, valorDepois))}</td>
                </tr>`;
        }).filter(Boolean).join('');

        corpoHtml = linhas
            ? `<table style="width:100%;border-collapse:collapse;"><thead><tr>
                    <th style="text-align:left;padding:6px 10px;font-size:11px;color:var(--muted);border-bottom:1px solid var(--border);">Campo</th>
                    <th style="text-align:left;padding:6px 10px;font-size:11px;color:var(--muted);border-bottom:1px solid var(--border);">Antes</th>
                    <th style="border-bottom:1px solid var(--border);"></th>
                    <th style="text-align:left;padding:6px 10px;font-size:11px;color:var(--muted);border-bottom:1px solid var(--border);">Depois</th>
               </tr></thead><tbody>${linhas}</tbody></table>`
            : '<p style="color:var(--muted);padding:10px;">Nenhuma alteração de campo identificada (a edição pode ter afetado apenas relações, não os valores diretos deste registro).</p>';
    } else {
        // CRIAR ou EXCLUIR: mostra o snapshot completo do registro (o que
        // foi criado, ou o que existia antes de ser apagado).
        const snapshot = depois || antes;
        if (snapshot) {
            const linhas = Object.keys(snapshot)
                .filter(c => !['id', 'created_at'].includes(c))
                .map(campo => `
                    <tr>
                        <td style="padding:8px 10px;color:var(--muted);font-size:12px;white-space:nowrap;">${escapeHtml(labelCampoHistorico(campo))}</td>
                        <td style="padding:8px 10px;color:var(--text);font-size:12.5px;">${escapeHtml(formatarValorHistorico(campo, snapshot[campo]))}</td>
                    </tr>`).join('');
            corpoHtml = `<table style="width:100%;border-collapse:collapse;"><tbody>${linhas}</tbody></table>`;
        } else {
            corpoHtml = '<p style="color:var(--muted);padding:10px;">Nenhum detalhe adicional disponível para esta ação.</p>';
        }
    }

    const modal = document.getElementById('modalDetalheHistorico');
    document.getElementById('detalheHistoricoTitulo').innerHTML =
        `<span style="color:${acaoInfo.cor};">${acaoInfo.icone} ${acaoInfo.texto}</span> em ${labelTabelaHistorico(r.tabela)}${r.registroId != null ? ' #' + r.registroId : ''}`;
    document.getElementById('detalheHistoricoMeta').textContent =
        `${formatarDataHistoricoTitulo(r.data)} às ${(r.hora || '').slice(0,8)} — por ${r.usuarioNome || 'Sistema'}`;
    document.getElementById('detalheHistoricoDescricao').textContent = r.descricao || '';
    document.getElementById('detalheHistoricoCorpo').innerHTML = corpoHtml;
    if (modal) modal.style.display = 'flex';
}

function fecharModalDetalheHistorico() {
    const modal = document.getElementById('modalDetalheHistorico');
    if (modal) modal.style.display = 'none';
}

window.mostrarDetalheHistorico = mostrarDetalheHistorico;
window.fecharModalDetalheHistorico = fecharModalDetalheHistorico;

window.carregarHistoricoTela = carregarHistoricoTela;
window.limparFiltrosHistorico = limparFiltrosHistorico;

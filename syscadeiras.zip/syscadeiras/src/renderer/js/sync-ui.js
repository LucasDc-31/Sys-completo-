/**
 * sync-ui.js
 * Sincronização com Supabase (lado da interface)
 * (Extraído de script.js, linhas 4316-4427 do arquivo original)
 */

// SINCRONIZAÇÃO COM SUPABASE — SysCadeiras v2.0
// ============================================

async function syncEspelhar(tabela, dados, conflito = 'id') {
    if (!window.electronAPI?.sync) return;
    try { await window.electronAPI.sync.espelhar(tabela, dados, conflito); }
    catch (e) { console.warn('syncEspelhar erro:', e); }
}

async function syncDeletar(tabela, id) {
    if (!window.electronAPI?.sync) return;
    try { await window.electronAPI.sync.deletar(tabela, id); }
    catch (e) { console.warn('syncDeletar erro:', e); }
}

function mostrarToastSync(msg, tipo = 'info') {
    const cores = { success: '#27ae60', warn: '#f39c12', error: '#e74c3c', info: '#3498db' };
    const icons = { success: '✅', warn: '⚠️', error: '❌', info: '📱' };
    const t = document.createElement('div');
    t.style.cssText = `position:fixed;bottom:24px;right:24px;z-index:99999;background:#2c3e50;color:#ecf0f1;
        border-left:4px solid ${cores[tipo]};padding:14px 20px;border-radius:8px;font-size:14px;font-weight:600;
        box-shadow:0 4px 20px rgba(0,0,0,.4);max-width:380px;display:flex;align-items:center;gap:10px;
        animation:toastSyncIn .3s ease;`;
    if (!document.getElementById('_syncStyle')) {
        const s = document.createElement('style');
        s.id = '_syncStyle';
        s.textContent = '@keyframes toastSyncIn{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}';
        document.head.appendChild(s);
    }
    t.innerHTML = `<span>${icons[tipo]}</span><span>${esc(msg)}</span>`;
    document.body.appendChild(t);
    setTimeout(() => { t.style.opacity = '0'; t.style.transition = 'opacity .4s'; setTimeout(() => t.remove(), 400); }, 4500);
}

function iniciarSyncListeners() {
    if (!window.electronAPI?.sync) {
        console.log('ℹ️ Sync Supabase não configurado — funcionando somente local.');
        return;
    }

    window.electronAPI.sync.onNovaProducao((prod) => {
        // Só exibe o toast e a notificação — o refresh vem pelo onRecarregar
        const func = funcionarios.find(f => f.id === (prod.funcionarioId || prod.funcionarioid));
        const peca = pecas.find(p => p.id === (prod.pecaId || prod.pecaid));
        mostrarToastSync(
            `📱 Nova produção via celular: ${prod.quantidade}× ${peca?.nome || 'item'} — ${func?.nome || 'operador'}`,
            'success'
        );
        if (window.electronAPI.showNotification)
            window.electronAPI.showNotification(
                '📱 Produção registrada',
                `${prod.quantidade}× ${peca?.nome || 'item'} via celular`
            );
    });

    window.electronAPI.sync.onNovaMovimentacao((mov) => {
        const peca = pecas.find(p => p.id === (mov.pecaId || mov.pecaid));
        const tipo = mov.tipo === 'saida' ? '📤 Saída' : '📥 Entrada';
        mostrarToastSync(
            `${tipo} via celular: ${mov.quantidade}× ${peca?.nome || 'item'}`,
            mov.tipo === 'saida' ? 'warn' : 'info'
        );
    });

    window.electronAPI.sync.onNovaArmacao((arm) => {
        const peca = pecas.find(p => p.id === (arm.modeloId || arm.modeloid));
        mostrarToastSync(
            `🔩 Armação via celular: ${arm.quantidade}× ${peca?.nome || 'modelo'}`,
            'info'
        );
    });

    window.electronAPI.sync.onCadastro(({ tabela, tipo, dado }) => {
        const acoes = { INSERT: 'cadastrado', UPDATE: 'atualizado', DELETE: 'excluído' };
        mostrarToastSync(`${tabela} ${acoes[tipo] || 'alterado'} via celular`, 'info');
    });

    window.electronAPI.sync.onStatus(({ status }) => {
        // legacy badge
        const badge = document.getElementById('syncStatusBadge');
        if (badge) {
            badge.textContent = status === 'SUBSCRIBED' ? '📡 Sincronizado' : '⚠️ Reconectando...';
            badge.style.color  = status === 'SUBSCRIBED' ? '#27ae60' : '#f39c12';
        }
        // dark topbar badge
        const sb  = document.getElementById('syncBadge');
        const stx = document.getElementById('syncTxt');
        if (sb && stx) {
            if (status === 'SUBSCRIBED') {
                sb.className = 'sbadge on'; stx.textContent = 'Online';
            } else {
                sb.className = 'sbadge off'; stx.textContent = 'Sync...';
            }
        }
    });

    // Ponto único de refresh — debounce de 300ms para aguardar SQLite gravar
    let _recarregarTimer = null;
    window.electronAPI.sync.onRecarregar(({ tabela }) => {
        console.log(`📥 Evento recarregar recebido: ${tabela}`);
        if (_recarregarTimer) clearTimeout(_recarregarTimer);
        _recarregarTimer = setTimeout(async () => {
            _recarregarTimer = null;
            await DataManager.refreshData();
            console.log(`✅ Tela atualizada após sync mobile (${tabela})`);
            verificarEstoqueBaixoArmacoes();
        }, 300);
    });

    console.log('✅ Sync listeners com mobile inicializados');
}


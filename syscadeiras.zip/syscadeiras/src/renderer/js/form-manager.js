/**
 * form-manager.js
 * Gerenciador central de formulários (abrir/fechar/validar)
 * (Extraído de script.js, linhas 206-800 do arquivo original)
 */

// ============================================
// GERENCIADOR CENTRAL DE FORMULÁRIOS
// ============================================
const FormManager = {
    // Configuração dos formulários
    forms: {
        producao: {
            id: 'formProducao',
            hiddenId: 'producaoId',
            btnSalvar: 'btnSalvarProducao',
            btnCancelar: 'btnCancelarEdicao',
            defaults: {
                dataProducao: () => hojeISO(),
                funcionarioProducao: '',
                horaExtra: false
            },
            onReset: function() {
                // Garante que a trava de data (não-admin = só hoje) continue
                // valendo após resetar o formulário (novo lançamento).
                aplicarRestricaoDataProducao();
                const container = document.getElementById('itensProducao');
                if (container) {
                    container.innerHTML = `
                        <div class="itemProducao" data-index="0">
                            <div class="ctit" style="margin-top:8px;"><div class="cico cg">🪑</div>Item 1</div>
                            <div class="form-grid">
                                <div class="fg">
                                    <div class="fl">Modelo</div>
                                    <select id="pecaProducao" class="fs peca-select" required>
                                        <option value="">Selecione um modelo</option>
                                        ${pecas.map(p => `<option value="${p.id}">${esc(p.nome)}</option>`).join('')}
                                    </select>
                                </div>
                                <div class="fg">
                                    <div class="fl">Cor</div>
                                    <select id="corProducao" class="fs cor-select" required>
                                        <option value="">Selecione uma cor</option>
                                        ${cores.map(c => `<option value="${c.id}">${esc(c.nome)}</option>`).join('')}
                                    </select>
                                </div>
                                <div class="fg">
                                    <div class="fl">📊 Quantidade</div>
                                    <input type="number" class="fi quantidade" id="quantidade" min="1" required placeholder="0">
                                </div>
                                <div class="fg">
                                    <div class="fl">⏰ Hora Extra (+50%)</div>
                                    <div class="tog" id="heTog0" onclick="this.classList.toggle('on');document.getElementById('horaExtra').checked=this.classList.contains('on')">
                                        <div class="tog-inf">
                                            <div class="tog-t">Hora Extra</div>
                                            <div class="tog-s">+50% no valor por peça</div>
                                        </div>
                                        <div class="sw"></div>
                                        <input type="checkbox" class="hora-extra-checkbox" id="horaExtra" style="display:none">
                                    </div>
                                </div>
                            </div>
                        </div>
                    `;
                }
            }
        },
        peca: {
            id: 'formPeca',
            hiddenId: 'pecaId',
            btnSalvar: 'btnSalvarPeca',
            btnCancelar: 'btnCancelarEdicaoPeca',
            defaults: {
                nomePeca: '',
                valorPeca: ''
            },
            onReset: function() {
                document.getElementById('nomePeca').value = '';
                document.getElementById('valorPeca').value = '';
            }
        },
        funcionario: {
            id: 'formFuncionario',
            hiddenId: 'funcionarioId',
            btnSalvar: 'btnSalvarFuncionario',
            btnCancelar: 'btnCancelarEdicaoFuncionario',
            defaults: {
                nomeFuncionario: '',
                cargoFuncionario: ''
            },
            onReset: function() {
                document.getElementById('nomeFuncionario').value = '';
                document.getElementById('cargoFuncionario').value = '';
                // Volta ao modo "novo funcionário": mostra a opção de criar
                // o login já como administrador e desmarca por segurança.
                const bloco = document.getElementById('blocoFuncionarioComoAdmin');
                if (bloco) bloco.style.display = '';
                const chkAdmin = document.getElementById('funcionarioComoAdmin');
                if (chkAdmin) chkAdmin.checked = false;
            },
            onEdit: function() {
                // Editar um funcionário existente não recria o login dele —
                // esconde a opção pra não confundir o usuário.
                const bloco = document.getElementById('blocoFuncionarioComoAdmin');
                if (bloco) bloco.style.display = 'none';
            }
        },
        cor: {
            id: 'formCor',
            hiddenId: 'corId',
            btnSalvar: 'btnSalvarCor',
            btnCancelar: 'btnCancelarEdicaoCor',
            defaults: {
                nomeCor: ''
            },
            onReset: function() {
                document.getElementById('nomeCor').value = '';
            }
        },
        saida: {
            id: 'formSaida',
            hiddenId: 'saidaId',
            btnSalvar: 'btnSalvarSaida',
            btnCancelar: 'btnCancelarSaida',
            defaults: {
                dataSaida: () => hojeISO(),
                pecaSaida: '',
                corSaida: '',
                qtdSaida: '',
                obsSaida: ''
            },
            onReset: function() {
                document.getElementById('dataSaida').value = hojeISO();
                document.getElementById('pecaSaida').value = '';
                document.getElementById('corSaida').value = '';
                document.getElementById('qtdSaida').value = '';
                document.getElementById('obsSaida').value = '';
            }
        },
        armacao: {
            id: 'formArmacao',
            hiddenId: 'armacaoId',
            btnSalvar: 'btnSalvarArmacao',
            btnCancelar: 'btnCancelarArmacao',
            defaults: {
                dataArmacao: () => hojeISO(),
                modeloArmacao: '',
                quantidadeArmacao: ''
            },
            onReset: function() {
                document.getElementById('dataArmacao').value = hojeISO();
                document.getElementById('modeloArmacao').value = '';
                document.getElementById('quantidadeArmacao').value = '';
            }
        }
    },

    // Estado de edição atual
    editingState: {
        formName: null,
        id: null
    },

    init() {
        // Guarda contra múltiplas inicializações — cada chamada extra adicionaria
        // um listener novo ao mesmo form, causando submits duplicados/triplicados.
        if (this._initialized) {
            console.log('⚠️ FormManager já inicializado — ignorando chamada extra');
            return;
        }
        this._initialized = true;

        for (const [name, config] of Object.entries(this.forms)) {
            const form = document.getElementById(config.id);
            if (form) {
                form.addEventListener('submit', (e) => this.handleSubmit(e, name));
            }
        }

        document.addEventListener('click', (e) => {
            const editBtn = e.target.closest('.btn-editar');
            if (editBtn) {
                e.preventDefault();
                const handler = editBtn.getAttribute('data-edit-handler');
                if (handler && typeof window[handler] === 'function') {
                    window[handler](parseInt(editBtn.getAttribute('data-id')));
                }
            }
        });

        console.log('✅ FormManager inicializado');
    },

    async handleSubmit(e, formName) {
        e.preventDefault();
        
        const config = this.forms[formName];
        if (!config) return;

        try {
            if (formName === 'producao') await this.salvarProducao();
            else if (formName === 'peca') await this.salvarPeca();
            else if (formName === 'funcionario') await this.salvarFuncionario();
            else if (formName === 'cor') await this.salvarCor();
            else if (formName === 'saida') await this.salvarSaida();
            else if (formName === 'armacao') await this.salvarArmacao();
            
            this.resetForm(formName);
            
        } catch (error) {
            console.error(`❌ Erro ao salvar ${formName}:`, error);
            toast('Erro ao salvar: ' + error.message, 'error');
        }
    },

    fillForEdit(formName, data) {
        const config = this.forms[formName];
        if (!config) return;

        if (config.hiddenId && data.id) {
            document.getElementById(config.hiddenId).value = data.id;
        }

        for (const [field, value] of Object.entries(data)) {
            const element = document.getElementById(field);
            if (element) {
                if (element.type === 'checkbox') {
                    element.checked = !!value;
                } else {
                    element.value = value ?? '';
                }
            }
        }

        this.setEditingMode(formName, true);
        
        if (config.onEdit) {
            config.onEdit(data);
        }
    },

    resetForm(formName) {
        const config = this.forms[formName];
        if (!config) return;

        if (config.hiddenId) {
            document.getElementById(config.hiddenId).value = '';
        }

        for (const [field, defaultValue] of Object.entries(config.defaults)) {
            const element = document.getElementById(field);
            if (element) {
                const value = typeof defaultValue === 'function' ? defaultValue() : defaultValue;
                if (element.type === 'checkbox') {
                    element.checked = value;
                } else {
                    element.value = value;
                }
            }
        }

        if (config.onReset) {
            config.onReset();
        }

        this.setEditingMode(formName, false);
    },

    setEditingMode(formName, isEditing) {
        const config = this.forms[formName];
        if (!config) return;

        const btnSalvar = document.getElementById(config.btnSalvar);
        if (btnSalvar) {
            btnSalvar.textContent = isEditing ? '✏️ Atualizar' : '💾 Salvar';
        }

        const btnCancelar = document.getElementById(config.btnCancelar);
        if (btnCancelar) {
            btnCancelar.style.display = isEditing ? 'inline-block' : 'none';
        }

        if (isEditing) {
            this.editingState.formName = formName;
            this.editingState.id = document.getElementById(config.hiddenId)?.value;
        } else {
            this.editingState.formName = null;
            this.editingState.id = null;
        }
    },

    cancelEditing(formName) {
        this.resetForm(formName);
    },

    async verificarEstoqueArmacoesParaProducao(itens) {
        const resultados = [];
        let estoqueInsuficiente = false;
        
        for (const item of itens) {
            const estoqueArm = estoqueArmacoes.find(e => e.modeloId === item.pecaId);
            const quantidadeEstoque = estoqueArm ? estoqueArm.quantidade : 0;
            const peca = pecas.find(p => p.id === item.pecaId);
            
            resultados.push({
                modelo: peca ? peca.nome : 'Modelo não encontrado',
                modeloId: item.pecaId,
                quantidadeProducao: item.quantidade,
                quantidadeEstoque,
                diferenca: quantidadeEstoque - item.quantidade,
                suficiente: quantidadeEstoque >= item.quantidade
            });
            
            if (quantidadeEstoque < item.quantidade) {
                estoqueInsuficiente = true;
            }
        }
        
        return { resultados, estoqueInsuficiente };
    },

    async atualizarEstoqueArmacaoProducao(itens, operacao = 'diminuir') {
        for (const item of itens) {
            const estoqueAtual = estoqueArmacoes.find(e => e.modeloId === item.pecaId);
            const quantidadeAtual = estoqueAtual ? estoqueAtual.quantidade : 0;
            let novaQuantidade;
            
            if (operacao === 'diminuir') {
                novaQuantidade = quantidadeAtual - item.quantidade;
            } else {
                novaQuantidade = quantidadeAtual + item.quantidade;
            }
            
            await window.electronAPI.database.run(
                'INSERT OR REPLACE INTO EstoqueArmacoes (modeloId, quantidade, ultimaAtualizacao) VALUES (?, ?, CURRENT_TIMESTAMP)',
                [item.pecaId, novaQuantidade]
            );
        }
    },

    async recalcularEstoqueArmacao(modeloId) {
        const result = await window.electronAPI.database.all(
            'SELECT SUM(quantidade) as total FROM Armações WHERE modeloId = ?',
            [modeloId]
        );
        
        const total = result.success ? (result.result[0]?.total || 0) : 0;
        
        await window.electronAPI.database.run(
            'INSERT OR REPLACE INTO EstoqueArmacoes (modeloId, quantidade, ultimaAtualizacao) VALUES (?, ?, CURRENT_TIMESTAMP)',
            [modeloId, total]
        );
        
        await DataManager.loadArmacoesFromDB();
    },

    async salvarPeca() {
        const id = document.getElementById('pecaId').value;
        const nome = document.getElementById('nomePeca').value.trim();
        const valor = parseFloat(document.getElementById('valorPeca').value);

        if (!nome || isNaN(valor) || valor <= 0) {
            throw new Error('Preencha todos os campos corretamente');
        }

        let _pecaRes;
        if (id) {
            await window.electronAPI.database.run('UPDATE Pecas SET nome=?, valor=? WHERE id=?', [nome, valor, id]);
            _pecaRes = { result: { id: parseInt(id) } };
        } else {
            _pecaRes = await window.electronAPI.database.run('INSERT INTO Pecas (nome, valor) VALUES (?, ?)', [nome, valor]);
        }
        await DataManager.refreshData();
        await syncEspelhar('Pecas', { id: parseInt(id) || _pecaRes?.result?.id, nome, valor, device_origin: 'desktop' });
    },

    async salvarFuncionario() {
        const id = document.getElementById('funcionarioId').value;
        const nome = document.getElementById('nomeFuncionario').value.trim();
        const cargo = document.getElementById('cargoFuncionario').value.trim();

        if (!nome || !cargo) throw new Error('Preencha todos os campos');

        if (id) {
            // Edição: mantém o fluxo simples de sempre, sem mexer no login vinculado.
            await window.electronAPI.database.run('UPDATE Funcionarios SET nome=?, cargo=? WHERE id=?', [nome, cargo, id]);
            await DataManager.refreshData();
            await syncEspelhar('Funcionarios', { id: parseInt(id), nome, cargo, device_origin: 'desktop' });
            return;
        }

        // Criação: o Desktop já cria automaticamente o login pessoal deste
        // funcionário (processo principal — ver funcionario-criar-com-login em
        // main.js), então aqui só chamamos o canal dedicado e mostramos as
        // credenciais geradas para o admin repassar ao funcionário.
        const comoAdmin = !!document.getElementById('funcionarioComoAdmin')?.checked;
        const res = await window.electronAPI.funcionarios.criarComLogin({ nome, cargo, comoAdmin });
        if (!res.success) throw new Error(res.error || 'Não foi possível cadastrar o funcionário.');

        await DataManager.refreshData();
        await syncEspelhar('Funcionarios', { id: res.funcionario.id, nome, cargo, device_origin: 'desktop' });

        if (res.credenciais) {
            mostrarCredenciaisFuncionario(nome, res.credenciais);
        }
    },


    async salvarCor() {
        const id = document.getElementById('corId').value;
        const nome = document.getElementById('nomeCor').value.trim();

        if (!nome) throw new Error('Informe o nome da cor');

        let _corRes;
        if (id) {
            await window.electronAPI.database.run('UPDATE Cores SET nome=? WHERE id=?', [nome, id]);
            _corRes = { result: { id: parseInt(id) } };
        } else {
            _corRes = await window.electronAPI.database.run('INSERT INTO Cores (nome) VALUES (?)', [nome]);
        }
        await DataManager.refreshData();
        await syncEspelhar('Cores', { id: parseInt(id) || _corRes?.result?.id, nome, device_origin: 'desktop' });
    },

    async salvarSaida() {
        const id = document.getElementById('saidaId').value;
        const data = document.getElementById('dataSaida').value;
        const pecaId = parseInt(document.getElementById('pecaSaida').value);
        const corId = parseInt(document.getElementById('corSaida').value);
        const quantidade = parseInt(document.getElementById('qtdSaida').value);
        const obs = document.getElementById('obsSaida').value.trim();

        if (!pecaId || !corId || !quantidade) {
            throw new Error('Preencha todos os campos obrigatórios');
        }

        const saldo = calcularSaldo(pecaId, corId);
        if (saldo < quantidade) {
            const faltam = quantidade - saldo;
            if (!confirm(`⚠️ Saldo insuficiente!\nSaldo: ${saldo}\nFaltam: ${faltam}\nRegistrar mesmo assim?`)) {
                return;
            }
        }

        let _saidaRes;
        if (id) {
            await window.electronAPI.database.run('UPDATE Movimentacoes SET data=?, pecaId=?, corId=?, quantidade=?, origem=?, login_user=? WHERE id=?', [data, pecaId, corId, quantidade, obs, currentUser?.nome || 'Desktop', id]);
            _saidaRes = { result: { id: parseInt(id) } };
        } else {
            _saidaRes = await window.electronAPI.database.run('INSERT INTO Movimentacoes (data, tipo, pecaId, corId, quantidade, origem, login_user) VALUES (?, ?, ?, ?, ?, ?, ?)', [data, 'saida', pecaId, corId, quantidade, obs, currentUser?.nome || 'Desktop']);
        }
        await DataManager.refreshData();
        await syncEspelhar('Movimentacoes', { id: parseInt(id) || _saidaRes?.result?.id, data, tipo: 'saida', pecaid: pecaId, corid: corId, quantidade, origem: obs, device_origin: 'desktop' });

        const novoSaldo = calcularSaldo(pecaId, corId);
        if (novoSaldo < 0) {
            toast('Atenção: estoque ficou negativo!', 'warn');
        }
    },

    async salvarProducao() {
        const id = document.getElementById('producaoId').value;
        const data = document.getElementById('dataProducao').value;
        const funcionarioId = parseInt(document.getElementById('funcionarioProducao').value);

        if (!funcionarioId) throw new Error('Selecione um funcionário');

        const itens = this.coletarItensProducao();
        if (itens.length === 0) throw new Error('Adicione pelo menos um item');

        // Verificar estoque de armações
        const verificacao = await this.verificarEstoqueArmacoesParaProducao(itens);
        
        // Exibir relatório de verificação
        let mensagem = '📊 VERIFICAÇÃO DE ESTOQUE DE ARMAÇÕES:\n\n';
        verificacao.resultados.forEach(r => {
            const status = r.suficiente ? '✅ OK' : '⚠️ INSUFICIENTE';
            mensagem += `${r.modelo}:\n`;
            mensagem += `   Produção: ${r.quantidadeProducao} | Estoque: ${r.quantidadeEstoque}\n`;
            mensagem += `   Status: ${status} (${r.diferenca >= 0 ? `Sobra ${r.diferenca}` : `Falta ${Math.abs(r.diferenca)}`})\n\n`;
        });
        
        if (verificacao.estoqueInsuficiente) {
            mensagem += '⚠️ ATENÇÃO: Haverá consumo de armações com estoque insuficiente!\n';
            mensagem += 'O estoque ficará negativo para os modelos indicados.\n\n';
            mensagem += 'Deseja continuar mesmo assim?';
            
            if (!confirm(mensagem)) {
                return;
            }
        } else {
            mensagem += '✅ Todos os modelos possuem estoque suficiente!\n\nDeseja continuar?';
            if (!confirm(mensagem)) {
                return;
            }
        }

        // Registrar produção e atualizar estoque de armações.
        // O par (Producoes + Movimentacoes) de cada item é executado como
        // uma transação atômica: se a movimentação falhar, a produção
        // também é revertida — antes, cada INSERT/UPDATE ia solto por IPC,
        // então uma falha no meio podia gravar a produção sem a
        // movimentação de estoque correspondente (ou vice-versa).
        for (const item of itens) {
            let producaoId;
            let movResultado;

            if (id) {
                const resultados = await window.electronAPI.database.runTransacao([
                    { sql: 'DELETE FROM Movimentacoes WHERE producaoId=?', params: [id] },
                    { sql: 'UPDATE Producoes SET data=?, funcionarioId=?, pecaId=?, corId=?, quantidade=?, horaExtra=?, login_user=? WHERE id=?',
                      params: [data, funcionarioId, item.pecaId, item.corId, item.quantidade, item.horaExtra ? 1 : 0, currentUser?.nome || 'Desktop', id] },
                    { sql: 'INSERT INTO Movimentacoes (data, tipo, pecaId, corId, quantidade, origem, producaoId, funcionarioId, login_user) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                      params: [data, 'entrada', item.pecaId, item.corId, item.quantidade, 'Produção', id, funcionarioId, currentUser?.nome || 'Desktop'] },
                ]);
                if (!resultados.success) throw new Error(resultados.error || 'Falha ao salvar produção');
                producaoId = id;
                movResultado = resultados.result[2];
            } else {
                // O INSERT em Movimentacoes referencia o id recém-criado em
                // Producoes através do marcador '$lastId', resolvido dentro
                // da própria transação (ver database.js) — evita depender
                // do lastID entre chamadas IPC separadas, o que não seria
                // mais atômico. Mantém um "?" por coluna (mesmo padrão do
                // resto do app), para não confundir o parser de permissões
                // do processo principal, que espera essa correspondência.
                const resultados = await window.electronAPI.database.runTransacao([
                    { sql: 'INSERT INTO Producoes (data, funcionarioId, pecaId, corId, quantidade, horaExtra, login_user) VALUES (?, ?, ?, ?, ?, ?, ?)',
                      params: [data, funcionarioId, item.pecaId, item.corId, item.quantidade, item.horaExtra ? 1 : 0, currentUser?.nome || 'Desktop'] },
                    { sql: 'INSERT INTO Movimentacoes (data, tipo, pecaId, corId, quantidade, origem, producaoId, funcionarioId, login_user) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                      params: [data, 'entrada', item.pecaId, item.corId, item.quantidade, 'Produção', '$lastId', funcionarioId, currentUser?.nome || 'Desktop'] },
                ]);
                if (!resultados.success) throw new Error(resultados.error || 'Falha ao salvar produção');
                producaoId = resultados.result[0].id;
                movResultado = resultados.result[1];
            }

            await syncEspelhar('Producoes', { id: parseInt(producaoId), data, funcionarioid: funcionarioId, pecaid: item.pecaId, corid: item.corId, quantidade: item.quantidade, horaextra: item.horaExtra ? 1 : 0, device_origin: 'desktop' });
            await syncEspelhar('Movimentacoes', { id: movResultado?.id, data, tipo: 'entrada', pecaid: item.pecaId, corid: item.corId, quantidade: item.quantidade, origem: 'Produção', producaoid: parseInt(producaoId), funcionarioid: funcionarioId, device_origin: 'desktop' });
        }

        // Atualizar estoque de armações (diminuir) — apenas em novos registros
        if (!id) {
            await this.atualizarEstoqueArmacaoProducao(itens, 'diminuir');
            for (const item of itens) {
                const _ea = estoqueArmacoes.find(e => e.modeloId === item.pecaId);
                if (_ea) await syncEspelhar('EstoqueArmacoes', { modeloid: item.pecaId, quantidade: _ea.quantidade }, 'modeloid');
            }
        }

        await DataManager.refreshData();
        
        toast('Produção registrada com sucesso!', 'success');
    },

    async salvarArmacao() {
        const id = document.getElementById('armacaoId').value;
        const data = document.getElementById('dataArmacao').value;
        const modeloId = parseInt(document.getElementById('modeloArmacao').value);
        const quantidade = parseInt(document.getElementById('quantidadeArmacao').value);
        const operador = currentUser?.nome || 'Desktop';

        if (!modeloId || !quantidade) {
            throw new Error('Preencha todos os campos obrigatórios');
        }

        if (id) {
            await window.electronAPI.database.run(
                'UPDATE Armações SET data=?, modeloId=?, quantidade=?, login_user=? WHERE id=?',
                [data, modeloId, quantidade, operador, id]
            );
            await this.recalcularEstoqueArmacao(modeloId);
        } else {
            await window.electronAPI.database.run(
                'INSERT INTO Armações (data, modeloId, quantidade, login_user) VALUES (?, ?, ?, ?)',
                [data, modeloId, quantidade, operador]
            );
            await this.recalcularEstoqueArmacao(modeloId);
        }

        await DataManager.refreshData();
        const _eaSync = estoqueArmacoes.find(e => e.modeloId === modeloId);
        await syncEspelhar('Armacoes', { data, modeloid: modeloId, quantidade, login_user: operador, device_origin: 'desktop' });
        if (_eaSync) await syncEspelhar('EstoqueArmacoes', { modeloid: modeloId, quantidade: _eaSync.quantidade }, 'modeloid');
        toast('Chegada de armação registrada com sucesso!', 'success');
    },

    coletarItensProducao() {
        const itens = [];
        const itensElements = document.querySelectorAll('.itemProducao');

        itensElements.forEach((item, index) => {
            let pecaId, corId, quantidade, horaExtra;

            if (index === 0) {
                pecaId = parseInt(item.querySelector('#pecaProducao, .peca-select')?.value);
                corId = parseInt(item.querySelector('#corProducao, .cor-select')?.value);
                quantidade = parseInt(item.querySelector('.quantidade, #quantidade')?.value);
                horaExtra = item.querySelector('.hora-extra-checkbox, #horaExtra')?.checked || false;
            } else {
                pecaId = parseInt(item.querySelector('.peca-item')?.value);
                corId = parseInt(item.querySelector('.cor-item')?.value);
                quantidade = parseInt(item.querySelector('.quantidade-item')?.value);
                horaExtra = item.querySelector('.hora-extra-item')?.checked || false;
            }

            if (pecaId && corId && quantidade) {
                itens.push({ pecaId, corId, quantidade, horaExtra });
            }
        });

        return itens;
    }
};


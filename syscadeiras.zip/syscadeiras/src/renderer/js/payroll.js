/**
 * payroll.js
 * Folha de pagamento
 * (Extraído de script.js, linhas 3114-3437 do arquivo original)
 */

// ============================================
// FUNÇÕES DE FOLHA DE PAGAMENTO
// ============================================

function gerarListaFolhaPagamento() {
    const mesAno = document.getElementById('mesFolha').value;
    if (!mesAno) {
        toast('Selecione o mês/ano.', 'warn');
        return;
    }
    
    const [ano, mes] = mesAno.split('-');
    const dataInicio = `${ano}-${mes}-01`;
    const ultimoDia = new Date(ano, mes, 0).getDate();
    const dataFim = `${ano}-${mes}-${ultimoDia}`;
    
    const producoesMes = producoesVisiveisParaUsuario().filter(p => {
        return p.data >= dataInicio && p.data <= dataFim;
    });
    
    if (producoesMes.length === 0) {
        toast('Não há produções registradas para ' + mes + '/' + ano + '.', 'warn');
        return;
    }
    
    const producoesPorFuncionario = {};
    producoesMes.forEach(producao => {
        const funcionarioId = producao.funcionarioId;
        if (!producoesPorFuncionario[funcionarioId]) {
            producoesPorFuncionario[funcionarioId] = {
                producoes: [],
                totalItens: 0,
                totalValor: 0,
                diasTrabalhados: new Set()
            };
        }
        producoesPorFuncionario[funcionarioId].producoes.push(producao);
        producoesPorFuncionario[funcionarioId].diasTrabalhados.add(producao.data);
    });
    
    Object.keys(producoesPorFuncionario).forEach(funcionarioId => {
        const prods = producoesPorFuncionario[funcionarioId].producoes;
        prods.forEach(producao => {
            const peca = pecas.find(p => p.id === producao.pecaId);
            let valorPeca = peca ? peca.valor : 0;
            if (producao.horaExtra) {
                valorPeca = valorPeca * 1.5;
            }
            const valorTotal = valorPeca * producao.quantidade;
            producoesPorFuncionario[funcionarioId].totalItens += producao.quantidade;
            producoesPorFuncionario[funcionarioId].totalValor += valorTotal;
        });
    });
    
    const funcionariosIds = Object.keys(producoesPorFuncionario).sort((a, b) => {
        const funcA = funcionarios.find(f => f.id == a);
        const funcB = funcionarios.find(f => f.id == b);
        return (funcA?.nome || '').localeCompare(funcB?.nome || '');
    });
    
    let html = `
        <table style="width: 100%; border-collapse: collapse; margin-top: 20px; box-shadow: 0 2px 8px rgba(0,0,0,.1); border-radius: 8px; overflow: hidden;">
            <thead>
                <tr style="background: #2c3e50; color: #fff;">
                    <th style="padding: 14px 12px; text-align: left; font-weight: 600;">Funcionário</th>
                    <th style="padding: 14px 12px; text-align: left; font-weight: 600;">Cargo</th>
                    <th style="padding: 14px 12px; text-align: center; font-weight: 600;">Dias</th>
                    <th style="padding: 14px 12px; text-align: right; font-weight: 600;">Qtd. Itens</th>
                    <th style="padding: 14px 12px; text-align: right; font-weight: 600;">Valor Total</th>
                    <th style="padding: 14px 12px; text-align: center; font-weight: 600;">Ação</th>
                  </tr>
            </thead>
            <tbody>
    `;
    
    let totalGeralItens = 0;
    let totalGeralValor = 0;
    
    funcionariosIds.forEach(funcionarioId => {
        const funcionario = funcionarios.find(f => f.id == funcionarioId);
        if (!funcionario) return;
        
        const dados = producoesPorFuncionario[funcionarioId];
        totalGeralItens += dados.totalItens;
        totalGeralValor += dados.totalValor;
        
        html += `
            <tr style="border-bottom: 1px solid #eee; transition: background .2s;">
                <td style="padding: 14px 12px;">${esc(funcionario.nome)}</td>
                <td style="padding: 14px 12px;">${esc(funcionario.cargo)}</td>
                <td style="padding: 14px 12px; text-align: center;">${dados.diasTrabalhados.size}</td>
                <td style="padding: 14px 12px; text-align: right; font-weight: 600;">${dados.totalItens}</td>
                <td style="padding: 14px 12px; text-align: right; font-weight: 600; font-family: monospace;">R$ ${dados.totalValor.toFixed(2)}</td>
                <td style="padding: 14px 12px; text-align: center;">
                    <button onclick="exportarProducaoFuncionarioDetalhado('${funcionarioId}', '${mes}', '${ano}', '${funcionario.nome.replace(/'/g, "\\'")}')" style="background: #1abc9c; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; font-weight: 500;">📤 Exportar CSV</button>
                </td>
              </tr>
        `;
    });
    
    html += `
            </tbody>
            <tfoot>
                <tr style="background: #f8f9fa; font-weight: 600;">
                    <td colspan="3" style="padding: 14px 12px; text-align: right;">TOTAL GERAL:</td>
                    <td style="padding: 14px 12px; text-align: right; font-weight: 600;">${totalGeralItens}</td>
                    <td style="padding: 14px 12px; text-align: right; font-weight: 600; font-family: monospace;">R$ ${totalGeralValor.toFixed(2)}</td>
                    <td style="padding: 14px 12px;"></td>
                </tr>
            </tfoot>
        </table>
    `;
    
    html += `
        <div class="text-center mt-20" style="display: flex; gap: 10px; justify-content: center;">
            <button class="btn-primary" onclick="exportarTodosFuncionarios()">
                📤 Exportar Todos os Funcionários (CSV Individual)
            </button>
        </div>
    `;
    
    document.getElementById('tabelaFolhaPagamento').innerHTML = html;
    
    window.folhaPagamentoData = {
        mes,
        ano,
        producoesPorFuncionario,
        funcionarios
    };
}

function exportarProducaoFuncionarioDetalhado(funcionarioId, mes, ano, nomeFuncionario) {
    const producoesMes = producoesVisiveisParaUsuario().filter(p => {
        const dataInicio = `${ano}-${mes}-01`;
        const ultimoDia = new Date(ano, mes, 0).getDate();
        const dataFim = `${ano}-${mes}-${ultimoDia}`;
        return p.data >= dataInicio && p.data <= dataFim && p.funcionarioId == funcionarioId;
    });
    
    if (producoesMes.length === 0) {
        toast('Nenhuma produção encontrada.', 'warn');
        return;
    }
    
    producoesMes.sort((a, b) => a.data.localeCompare(b.data));
    
    let totalItens = 0;
    let totalValor = 0;
    let totalHorasExtras = 0;
    let totalItensHoraExtra = 0;
    
    producoesMes.forEach(producao => {
        const peca = pecas.find(p => p.id === producao.pecaId);
        const valorUnitarioBase = peca ? peca.valor : 0;
        const valorComHoraExtra = producao.horaExtra ? valorUnitarioBase * 1.5 : valorUnitarioBase;
        const valorTotal = valorComHoraExtra * producao.quantidade;
        
        totalItens += producao.quantidade;
        totalValor += valorTotal;
        
        if (producao.horaExtra) {
            totalHorasExtras++;
            totalItensHoraExtra += producao.quantidade;
        }
    });
    
    let csv = '='.repeat(100) + '\n';
    csv += 'RELATÓRIO DE PRODUÇÃO - FUNCIONÁRIO\n';
    csv += '='.repeat(100) + '\n\n';
    
    csv += `FUNCIONÁRIO: ${nomeFuncionario}\n`;
    csv += `PERÍODO: ${mes}/${ano}\n`;
    csv += `DATA DE GERAÇÃO: ${new Date().toLocaleString('pt-BR')}\n`;
    csv += `TOTAL DE REGISTROS: ${producoesMes.length}\n\n`;
    
    csv += '-'.repeat(100) + '\n';
    csv += 'DETALHAMENTO DIÁRIO DA PRODUÇÃO\n';
    csv += '-'.repeat(100) + '\n';
    
    csv += 'Data;Dia Semana;Modelo;Cor;Quantidade;Hora Extra;Valor Unit.(R$);Valor Total(R$)\n';
    
    const producoesPorData = {};
    producoesMes.forEach(p => {
        if (!producoesPorData[p.data]) producoesPorData[p.data] = [];
        producoesPorData[p.data].push(p);
    });
    
    const diasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
    
    Object.keys(producoesPorData).sort().forEach(data => {
        const producoesDoDia = producoesPorData[data];
        const dataObj = new Date(data + 'T00:00:00');
        const diaSemana = diasSemana[dataObj.getDay()];
        
        producoesDoDia.forEach(producao => {
            const peca = pecas.find(p => p.id === producao.pecaId);
            const cor = cores.find(c => c.id === producao.corId);
            
            const valorUnitarioBase = peca ? peca.valor : 0;
            const valorUnitario = producao.horaExtra ? valorUnitarioBase * 1.5 : valorUnitarioBase;
            const valorTotal = valorUnitario * producao.quantidade;
            
            const linha = [
                formatarData(producao.data),
                diaSemana,
                peca ? peca.nome : 'N/A',
                cor ? cor.nome : 'Sem cor',
                producao.quantidade,
                producao.horaExtra ? 'SIM' : 'NÃO',
                valorUnitario.toFixed(2).replace('.', ','),
                valorTotal.toFixed(2).replace('.', ',')
            ];
            
            csv += linha.join(';') + '\n';
        });
        
        const totalDia = producoesDoDia.reduce((acc, prod) => {
            const peca = pecas.find(p => p.id === prod.pecaId);
            const valorBase = peca ? peca.valor : 0;
            const valorUnit = prod.horaExtra ? valorBase * 1.5 : valorBase;
            return acc + (valorUnit * prod.quantidade);
        }, 0);
        
        csv += ';;;;;;;SUBTOTAL DO DIA:;R$ ' + totalDia.toFixed(2).replace('.', ',') + '\n';
        csv += ';\n';
    });
    
    csv += '\n' + '='.repeat(100) + '\n';
    csv += 'RESUMO DO PERÍODO\n';
    csv += '='.repeat(100) + '\n\n';
    
    csv += `Total de Itens Produzidos: ${totalItens}\n`;
    csv += `Total de Dias com Produção: ${Object.keys(producoesPorData).length}\n`;
    csv += `Total de Dias com Hora Extra: ${totalHorasExtras}\n`;
    csv += `Total de Itens em Hora Extra: ${totalItensHoraExtra}\n`;
    csv += `Média Diária de Produção: ${(totalItens / Object.keys(producoesPorData).length).toFixed(2)}\n`;
    csv += `Valor Total Produzido: R$ ${totalValor.toFixed(2).replace('.', ',')}\n\n`;
    
    csv += '-'.repeat(100) + '\n';
    csv += 'PRODUÇÃO POR MODELO\n';
    csv += '-'.repeat(100) + '\n';
    csv += 'Modelo;Cor;Quantidade;Valor Unit.(R$);Valor Total(R$)\n';
    
    const producaoPorModelo = {};
    producoesMes.forEach(producao => {
        const peca = pecas.find(p => p.id === producao.pecaId);
        const cor = cores.find(c => c.id === producao.corId);
        const key = `${producao.pecaId}-${producao.corId}`;
        
        if (!producaoPorModelo[key]) {
            producaoPorModelo[key] = {
                modelo: peca ? peca.nome : 'N/A',
                cor: cor ? cor.nome : 'Sem cor',
                quantidade: 0,
                valorUnitario: peca ? peca.valor : 0
            };
        }
        
        producaoPorModelo[key].quantidade += producao.quantidade;
    });
    
    Object.values(producaoPorModelo).forEach(item => {
        const valorTotal = item.valorUnitario * item.quantidade;
        csv += `${item.modelo};${item.cor};${item.quantidade};${item.valorUnitario.toFixed(2).replace('.', ',')};${valorTotal.toFixed(2).replace('.', ',')}\n`;
    });
    
    csv += '\n' + '='.repeat(100) + '\n';
    csv += 'FIM DO RELATÓRIO\n';
    csv += '='.repeat(100) + '\n';
    
    const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    
    const nomeArquivo = `producao_${nomeFuncionario.replace(/[^\w\s]/gi, '').replace(/\s+/g, '_')}_${mes}_${ano}.csv`;
    link.setAttribute('download', nomeArquivo);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast('Relatório de ' + nomeFuncionario + ' exportado!', 'success');
}

function exportarTodosFuncionarios() {
    const mesAno = document.getElementById('mesFolha').value;
    if (!mesAno) {
        toast('Selecione o mês/ano.', 'warn');
        return;
    }
    
    const [ano, mes] = mesAno.split('-');
    
    const dataInicio = `${ano}-${mes}-01`;
    const ultimoDia = new Date(ano, mes, 0).getDate();
    const dataFim = `${ano}-${mes}-${ultimoDia}`;
    
    const funcionariosComProducao = new Set();
    producoesVisiveisParaUsuario().forEach(p => {
        if (p.data >= dataInicio && p.data <= dataFim) {
            funcionariosComProducao.add(p.funcionarioId);
        }
    });
    
    if (funcionariosComProducao.size === 0) {
        toast('Nenhum funcionário com produção no período.', 'warn');
        return;
    }
    
    let contador = 0;
    Array.from(funcionariosComProducao).forEach(funcionarioId => {
        const funcionario = funcionarios.find(f => f.id == funcionarioId);
        if (funcionario) {
            exportarProducaoFuncionarioDetalhado(funcionarioId, mes, ano, funcionario.nome);
            contador++;
        }
    });
    
    setTimeout(() => {
        toast(contador + ' relatórios exportados!', 'success');
    }, 500);
}


/**
 * export.js
 * Seleção de produções e exportação (PDF/Excel/etc.)
 * (Extraído de script.js, linhas 2773-3113 do arquivo original)
 */

// ============================================
// FUNÇÕES DE SELEÇÃO DE PRODUÇÕES
// ============================================

function toggleProducaoSelecionada(id, checked) {
    if (checked) {
        producoesSelecionadas.add(id);
    } else {
        producoesSelecionadas.delete(id);
    }
    const totalCheckboxes = document.querySelectorAll('.checkbox-selecao').length;
    document.getElementById('selecionarTodos').checked = 
        producoesSelecionadas.size === totalCheckboxes && totalCheckboxes > 0;
}

function selecionarTodasProducoes(checked) {
    producoesSelecionadas.clear();
    document.querySelectorAll('.checkbox-selecao').forEach(cb => {
        cb.checked = checked;
        if (checked) {
            producoesSelecionadas.add(parseInt(cb.value));
        }
    });
}

async function apagarProducaoSelecionada() {
    if (producoesSelecionadas.size === 0) {
        toast('Selecione pelo menos uma produção.', 'warn');
        return;
    }
    
    const totalSelecionadas = producoesSelecionadas.size;
    if (!confirm(`⚠️ Tem certeza que deseja apagar ${totalSelecionadas} registro(s) de produção?`)) return;
    
    try {
        for (const id of producoesSelecionadas) {
            const producao = DataManager.findById(producoes, id);
            if (producao) {
                // Devolve armações ao estoque antes de apagar
                const itens = [{ pecaId: producao.pecaId, quantidade: producao.quantidade }];
                await FormManager.atualizarEstoqueArmacaoProducao(itens, 'adicionar');
                // Espelha estoque atualizado no Supabase
                const _ea = estoqueArmacoes.find(e => e.modeloId === producao.pecaId);
                if (_ea) await syncEspelhar('EstoqueArmacoes', { modeloid: producao.pecaId, quantidade: _ea.quantidade }, 'modeloid');
            }
            
            await window.electronAPI.database.run('DELETE FROM Producoes WHERE id=?', [id]);
            await syncDeletar('Producoes', id); // FIX: faltava sync com Supabase

            const movs = movimentacoes.filter(m => m.producaoId === id);
            for (const mov of movs) {
                await window.electronAPI.database.run('DELETE FROM Movimentacoes WHERE id=?', [mov.id]);
                await syncDeletar('Movimentacoes', mov.id); // FIX: faltava sync
            }
        }
        
        producoesSelecionadas.clear();
        await DataManager.refreshData();
        
        toast(totalSelecionadas + ' produção(ões) excluída(s).', 'success');
        
    } catch (error) {
        console.error('❌ Erro ao apagar produções:', error);
        toast('Erro ao apagar: ' + error.message, 'error');
    }
}

// ============================================
// FUNÇÕES DE EXPORTAÇÃO
// ============================================

function exportarDados() {
    const dataInicio = document.getElementById('dataInicio').value;
    const dataFim = document.getElementById('dataFim').value;
    const funcionarioId = document.getElementById('filtroFuncionario').value;
    const pecaId = document.getElementById('filtroPeca').value;
    const corId = document.getElementById('filtroCor').value;
    
    let producoesFiltradas = producoesVisiveisParaUsuario().filter(p => {
        if (dataInicio && p.data < dataInicio) return false;
        if (dataFim && p.data > dataFim) return false;
        if (funcionarioId && p.funcionarioId != funcionarioId) return false;
        if (pecaId && p.pecaId != pecaId) return false;
        if (corId && p.corId != corId) return false;
        return true;
    });
    
    if (producoesFiltradas.length === 0) {
        toast('Não há produções para exportar.', 'warn');
        return;
    }
    
    producoesFiltradas.sort((a, b) => a.data.localeCompare(b.data));
    
    let totalGeral = 0;
    let totalItens = 0;
    
    let csv = '='.repeat(100) + '\n';
    csv += 'RELATÓRIO GERAL DE PRODUÇÃO - SYSCADEIRAS\n';
    csv += '='.repeat(100) + '\n\n';
    
    csv += `PERÍODO: ${dataInicio ? formatarData(dataInicio) : 'TODOS'} até ${dataFim ? formatarData(dataFim) : 'TODOS'}\n`;
    csv += `DATA DE GERAÇÃO: ${new Date().toLocaleString('pt-BR')}\n`;
    csv += `TOTAL DE REGISTROS: ${producoesFiltradas.length}\n\n`;
    
    csv += 'FILTROS APLICADOS:\n';
    csv += `- Funcionário: ${funcionarioId ? (funcionarios.find(f => f.id == funcionarioId)?.nome || 'Todos') : 'Todos'}\n`;
    csv += `- Modelo: ${pecaId ? (pecas.find(p => p.id == pecaId)?.nome || 'Todos') : 'Todos'}\n`;
    csv += `- Cor: ${corId ? (cores.find(c => c.id == corId)?.nome || 'Todas') : 'Todas'}\n\n`;
    
    csv += '-'.repeat(100) + '\n';
    csv += 'DETALHAMENTO DA PRODUÇÃO\n';
    csv += '-'.repeat(100) + '\n';
    
    csv += 'Data;Dia Semana;Funcionário;Modelo;Cor;Quantidade;Hora Extra;Valor Unit.(R$);Valor Total(R$)\n';
    
    const diasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
    
    producoesFiltradas.forEach(producao => {
        const funcionario = funcionarios.find(f => f.id === producao.funcionarioId);
        const peca = pecas.find(p => p.id === producao.pecaId);
        const cor = cores.find(c => c.id === producao.corId);
        
        const dataObj = new Date(producao.data + 'T00:00:00');
        const diaSemana = diasSemana[dataObj.getDay()];
        
        const valorUnitarioBase = peca ? peca.valor : 0;
        const valorUnitario = producao.horaExtra ? valorUnitarioBase * 1.5 : valorUnitarioBase;
        const valorTotal = valorUnitario * producao.quantidade;
        
        totalGeral += valorTotal;
        totalItens += producao.quantidade;
        
        const linha = [
            formatarData(producao.data),
            diaSemana,
            funcionario ? funcionario.nome : 'N/A',
            peca ? peca.nome : 'N/A',
            cor ? cor.nome : 'Sem cor',
            producao.quantidade,
            producao.horaExtra ? 'SIM' : 'NÃO',
            valorUnitario.toFixed(2).replace('.', ','),
            valorTotal.toFixed(2).replace('.', ',')
        ];
        
        csv += linha.join(';') + '\n';
    });
    
    csv += '\n' + '='.repeat(100) + '\n';
    csv += 'RESUMO GERAL\n';
    csv += '='.repeat(100) + '\n\n';
    
    csv += `Total de Itens Produzidos: ${totalItens}\n`;
    csv += `Valor Total Produzido: R$ ${totalGeral.toFixed(2).replace('.', ',')}\n`;
    csv += `Média por Registro: R$ ${(totalGeral / producoesFiltradas.length).toFixed(2).replace('.', ',')}\n\n`;
    
    csv += '-'.repeat(100) + '\n';
    csv += 'RESUMO POR FUNCIONÁRIO\n';
    csv += '-'.repeat(100) + '\n';
    csv += 'Funcionário;Quantidade de Registros;Total Itens;Valor Total(R$)\n';
    
    const resumoFuncionarios = {};
    producoesFiltradas.forEach(p => {
        if (!resumoFuncionarios[p.funcionarioId]) {
            resumoFuncionarios[p.funcionarioId] = {
                nome: funcionarios.find(f => f.id === p.funcionarioId)?.nome || 'N/A',
                registros: 0,
                itens: 0,
                valor: 0
            };
        }
        
        const peca = pecas.find(pc => pc.id === p.pecaId);
        const valorBase = peca ? peca.valor : 0;
        const valorUnit = p.horaExtra ? valorBase * 1.5 : valorBase;
        
        resumoFuncionarios[p.funcionarioId].registros++;
        resumoFuncionarios[p.funcionarioId].itens += p.quantidade;
        resumoFuncionarios[p.funcionarioId].valor += valorUnit * p.quantidade;
    });
    
    Object.values(resumoFuncionarios).forEach(f => {
        csv += `${f.nome};${f.registros};${f.itens};${f.valor.toFixed(2).replace('.', ',')}\n`;
    });
    
    csv += '\n' + '='.repeat(100) + '\n';
    csv += 'FIM DO RELATÓRIO\n';
    csv += '='.repeat(100) + '\n';
    
    const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    
    let nomeArquivo = 'relatorio_producao';
    if (dataInicio) nomeArquivo += `_${dataInicio}`;
    if (dataFim) nomeArquivo += `_a_${dataFim}`;
    nomeArquivo += '.csv';
    
    link.setAttribute('download', nomeArquivo);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast('Relatório exportado! ' + producoesFiltradas.length + ' registros.', 'success');
}

function exportarEstoqueCSV() {
    const dataInicio = document.getElementById('dataInicioEst').value;
    const dataFim = document.getElementById('dataFimEst').value;
    const tipoMov = document.getElementById('tipoMovEst').value;
    const pecaId = document.getElementById('pecaEst').value;
    const corId = document.getElementById('corEst').value;
    
    let movFiltradas = movimentacoes.filter(m => {
        if (dataInicio && m.data < dataInicio) return false;
        if (dataFim && m.data > dataFim) return false;
        if (tipoMov && m.tipo !== tipoMov) return false;
        if (pecaId && m.pecaId != pecaId) return false;
        if (corId && m.corId != corId) return false;
        return true;
    });
    
    if (movFiltradas.length === 0) {
        toast('Não há movimentações para exportar.', 'warn');
        return;
    }
    
    movFiltradas.sort((a, b) => a.data.localeCompare(b.data));
    
    const saldos = {};
    let totalEntradas = 0;
    let totalSaidas = 0;
    
    movFiltradas.forEach(mov => {
        const key = `${mov.pecaId}-${mov.corId}`;
        if (!saldos[key]) {
            saldos[key] = {
                pecaId: mov.pecaId,
                corId: mov.corId,
                entradas: 0,
                saidas: 0,
                saldo: 0
            };
        }
        
        if (mov.tipo === 'entrada') {
            saldos[key].entradas += mov.quantidade;
            totalEntradas += mov.quantidade;
        } else {
            saldos[key].saidas += mov.quantidade;
            totalSaidas += mov.quantidade;
        }
        
        saldos[key].saldo += mov.tipo === 'entrada' ? mov.quantidade : -mov.quantidade;
    });
    
    let csv = '='.repeat(100) + '\n';
    csv += 'RELATÓRIO DE MOVIMENTAÇÕES DE ESTOQUE - SYSCADEIRAS\n';
    csv += '='.repeat(100) + '\n\n';
    
    csv += `PERÍODO: ${dataInicio ? formatarData(dataInicio) : 'TODOS'} até ${dataFim ? formatarData(dataFim) : 'TODOS'}\n`;
    csv += `DATA DE GERAÇÃO: ${new Date().toLocaleString('pt-BR')}\n`;
    csv += `TOTAL DE MOVIMENTAÇÕES: ${movFiltradas.length}\n\n`;
    
    csv += 'FILTROS APLICADOS:\n';
    csv += `- Tipo: ${tipoMov === 'entrada' ? 'Entradas' : tipoMov === 'saida' ? 'Saídas' : 'Todos'}\n`;
    csv += `- Modelo: ${pecaId ? (pecas.find(p => p.id == pecaId)?.nome || 'Todos') : 'Todos'}\n`;
    csv += `- Cor: ${corId ? (cores.find(c => c.id == corId)?.nome || 'Todas') : 'Todas'}\n\n`;
    
    csv += '-'.repeat(100) + '\n';
    csv += 'MOVIMENTAÇÕES DETALHADAS\n';
    csv += '-'.repeat(100) + '\n';
    
    csv += 'Data;Dia Semana;Tipo;Modelo;Cor;Quantidade;Origem/Observação\n';
    
    const diasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
    
    movFiltradas.forEach(mov => {
        const dataObj = new Date(mov.data + 'T00:00:00');
        const diaSemana = diasSemana[dataObj.getDay()];
        const peca = pecas.find(p => p.id === mov.pecaId);
        const cor = cores.find(c => c.id === mov.corId);
        
        const linha = [
            formatarData(mov.data),
            diaSemana,
            mov.tipo === 'entrada' ? 'ENTRADA' : 'SAÍDA',
            peca ? peca.nome : 'N/A',
            cor ? cor.nome : 'Sem cor',
            mov.quantidade,
            mov.origem || '-'
        ];
        
        csv += linha.join(';') + '\n';
    });
    
    csv += '\n' + '='.repeat(100) + '\n';
    csv += 'RESUMO DO ESTOQUE\n';
    csv += '='.repeat(100) + '\n\n';
    
    csv += `Total de Entradas no Período: ${totalEntradas}\n`;
    csv += `Total de Saídas no Período: ${totalSaidas}\n`;
    csv += `Saldo Líquido do Período: ${totalEntradas - totalSaidas}\n\n`;
    
    csv += '-'.repeat(100) + '\n';
    csv += 'SALDO ATUAL POR MODELO/COR\n';
    csv += '-'.repeat(100) + '\n';
    csv += 'Modelo;Cor;Entradas;Saídas;Saldo Atual\n';
    
    Object.values(saldos).forEach(item => {
        const peca = pecas.find(p => p.id === item.pecaId);
        const cor = cores.find(c => c.id === item.corId);
        
        csv += `${peca ? peca.nome : 'N/A'};${cor ? cor.nome : 'Sem cor'};${item.entradas};${item.saidas};${item.saldo}\n`;
    });
    
    csv += '\n' + '='.repeat(100) + '\n';
    csv += 'FIM DO RELATÓRIO\n';
    csv += '='.repeat(100) + '\n';
    
    const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    
    let nomeArquivo = 'relatorio_estoque';
    if (dataInicio) nomeArquivo += `_${dataInicio}`;
    if (dataFim) nomeArquivo += `_a_${dataFim}`;
    nomeArquivo += '.csv';
    
    link.setAttribute('download', nomeArquivo);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast('Estoque exportado! ' + movFiltradas.length + ' registros.', 'success');
}


/**
 * helpers.js
 * Funções auxiliares/utilitárias gerais
 * (Extraído de script.js, linhas 1994-2127 do arquivo original)
 */

// ============================================
// FUNÇÕES AUXILIARES
// ============================================

function hojeISO() { 
    return new Date().toISOString().split('T')[0]; 
}

function formatarData(dataISO) { 
    if (!dataISO) return '';
    const data = new Date(dataISO + 'T00:00:00');
    return data.toLocaleDateString('pt-BR');
}

function formatarMoeda(valor) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(valor || 0);
}

function calcularSaldo(pecaId, corId) {
    let saldo = 0;
    movimentacoes.forEach(mov => {
        if (mov.pecaId === pecaId && mov.corId === corId) {
            saldo += mov.tipo === 'entrada' ? mov.quantidade : -mov.quantidade;
        }
    });
    return saldo;
}

function adicionarItemProducao() {
    const container = document.getElementById('itensProducao');
    const novoItem = document.createElement('div');
    novoItem.className = 'itemProducao';
    const index = container.children.length;
    novoItem.setAttribute('data-index', index);

    novoItem.innerHTML = `
        <div class="ctit" style="margin-top:8px;display:flex;align-items:center;justify-content:space-between;">
            <div style="display:flex;align-items:center;gap:8px;"><div class="cico cg">🪑</div>Item ${index + 1}</div>
            <button type="button" class="btn-excluir btn-sm" onclick="this.closest('.itemProducao').remove()">🗑️ Remover</button>
        </div>
        <div class="form-grid">
            <div class="fg">
                <div class="fl">Modelo</div>
                <select class="fs peca-item" required>
                    <option value="">Selecione um modelo</option>
                    ${pecas.map(p => `<option value="${p.id}">${esc(p.nome)}</option>`).join('')}
                </select>
            </div>
            <div class="fg">
                <div class="fl">Cor</div>
                <select class="fs cor-item" required>
                    <option value="">Selecione uma cor</option>
                    ${cores.map(c => `<option value="${c.id}">${esc(c.nome)}</option>`).join('')}
                </select>
            </div>
            <div class="fg">
                <div class="fl">📊 Quantidade</div>
                <input type="number" class="fi quantidade-item" min="1" required placeholder="0">
            </div>
            <div class="fg">
                <div class="fl">⏰ Hora Extra (+50%)</div>
                <div class="tog" onclick="this.classList.toggle('on');this.querySelector('.hora-extra-item').checked=this.classList.contains('on')">
                    <div class="tog-inf">
                        <div class="tog-t">Hora Extra</div>
                        <div class="tog-s">+50% no valor por peça</div>
                    </div>
                    <div class="sw"></div>
                    <input type="checkbox" class="hora-extra-item" style="display:none">
                </div>
            </div>
        </div>
        <hr style="border:none;border-top:1px solid var(--border);margin:14px 0;">
    `;
    container.appendChild(novoItem);
}

function showSection(id, btn) {
    // Bloqueia navegação para seções fora da permissão da conta logada.
    // "usuarios" continua controlado separadamente (apenas admin).
    if (id !== 'usuarios' && !temAcesso(id)) {
        toast('Sua conta não tem permissão para acessar esta seção.', 'error');
        return;
    }

    // Suporta tanto .section (legado) quanto .page (novo dark layout)
    document.querySelectorAll('.section, .page').forEach(s => {
        s.classList.remove('active');
        s.style.display = 'none';
    });

    document.querySelectorAll('.menu button, .sidebar .nb').forEach(b => {
        b.classList.remove('active');
    });

    const sec = document.getElementById(id);
    if (sec) {
        sec.classList.add('active');
        sec.style.display = 'block';
    }

    if (btn) {
        btn.classList.add('active');
    }

    // Sincroniza botão da sidebar pelo id do nav correspondente
    const navBtn = document.getElementById('nav-' + id) || document.getElementById('btn-' + id);
    if (navBtn && !btn) navBtn.classList.add('active');
    
    if (id === 'estoque') {
        UIManager.refreshSaldosTable();
    } else if (id === 'producao') {
        UIManager.refreshProducaoTable();
    } else if (id === 'armacoes') {
        UIManager.refreshArmacoesTables();
    }
}

async function atualizarSistema() {
    const btn = document.getElementById('btnAtualizar');
    if (btn) btn.classList.add('spin');
    try {
        await DataManager.loadDataFromDB();
        inicializarAplicacao();
        toast('Sistema atualizado!', 'success');
    } catch(e) {
        toast('Erro ao atualizar: ' + e.message, 'error');
    } finally {
        setTimeout(() => { if (btn) btn.classList.remove('spin'); }, 700);
    }
}


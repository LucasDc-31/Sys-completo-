/**
 * ui-manager.js
 * Gerenciador central da interface (telas, listas, tabelas)
 * (Extraído de script.js, linhas 884-1240 do arquivo original)
 */

// ============================================
// GERENCIADOR CENTRAL DA INTERFACE
// ============================================
const UIManager = {
    refreshAllSelects() {
        console.log('🔄 Atualizando todos os selects...');

        this.refreshSelect('funcionarioProducao', funcionarios, 'Selecione um funcionário');
        
        document.querySelectorAll('.itemProducao').forEach((item, index) => {
            if (index === 0) {
                const selectPeca = item.querySelector('#pecaProducao, .peca-select');
                if (selectPeca) this.refreshSelectElement(selectPeca, pecas, 'Selecione um modelo');
                
                const selectCor = item.querySelector('#corProducao, .cor-select');
                if (selectCor) this.refreshSelectElement(selectCor, cores, 'Selecione uma cor');
            } else {
                const selectPeca = item.querySelector('.peca-item');
                if (selectPeca) this.refreshSelectElement(selectPeca, pecas, 'Selecione um modelo');
                
                const selectCor = item.querySelector('.cor-item');
                if (selectCor) this.refreshSelectElement(selectCor, cores, 'Selecione uma cor');
            }
        });

        this.refreshSelect('pecaSaida', pecas, 'Selecione um modelo');
        this.refreshSelect('corSaida', cores, 'Selecione uma cor');
        this.refreshSelect('modeloArmacao', pecas, 'Selecione um modelo');

        this.refreshSelect('filtroFuncionario', funcionarios, 'Todos', true);
        this.refreshSelect('filtroPeca', pecas, 'Todos', true);
        this.refreshSelect('filtroCor', cores, 'Todos', true);
        this.refreshSelect('pecaEst', pecas, 'Todos', true);
        this.refreshSelect('corEst', cores, 'Todos', true);
        this.refreshSelect('filtroModeloArm', pecas, 'Todos', true);

        this.refreshSelect('filtroPecaEstoque', pecas, 'Todas as peças', true);
        this.refreshSelect('filtroCorEstoque', cores, 'Todas as cores', true);

        // Reforça a trava de "produção só para o próprio funcionário" — este
        // método também é chamado pelo sync em tempo real (outro dispositivo
        // cadastrando algo), então sem isso o select voltaria a ficar aberto.
        if (typeof aplicarRestricaoDataProducao === 'function') {
            aplicarRestricaoDataProducao();
        }
    },

    refreshSelect(selectId, data, placeholder, includeAll = false) {
        const select = document.getElementById(selectId);
        if (!select) return;

        const currentValue = select.value;
        this.refreshSelectElement(select, data, placeholder, includeAll);

        if (currentValue && Array.from(select.options).some(opt => opt.value == currentValue)) {
            select.value = currentValue;
        }
    },

    refreshSelectElement(select, data, placeholder, includeAll = false) {
        if (!select) return;

        const currentValue = select.value;
        select.innerHTML = '';

        const optionPlaceholder = document.createElement('option');
        optionPlaceholder.value = '';
        optionPlaceholder.textContent = placeholder;
        select.appendChild(optionPlaceholder);

        data.forEach(item => {
            const option = document.createElement('option');
            option.value = item.id;
            option.textContent = item.nome;
            select.appendChild(option);
        });

        if (currentValue && Array.from(select.options).some(opt => opt.value == currentValue)) {
            select.value = currentValue;
        }
    },

    refreshAllTables() {
        this.refreshProducaoTable();
        this.refreshPecasTable();
        this.refreshFuncionariosTable();
        this.refreshCoresTable();
        this.refreshSaldosTable();
        this.refreshArmacoesTables();
        // Sem isto, a lista de Usuários só se atualizava na próxima vez que o
        // admin clicasse na aba — por isso um funcionário recém-cadastrado
        // (que já nasce com login pessoal, ver funcionario-criar-com-login)
        // demorava a aparecer ali, mesmo com os dados já corretos no banco.
        if (currentUser?.role === 'admin' && typeof renderizarUsuarios === 'function') {
            renderizarUsuarios();
        }
    },

    refreshProducaoTable() {
        const tbody = document.querySelector('#tabelaProducao tbody');
        if (!tbody) return;

        tbody.innerHTML = '';
        const hoje = hojeISO();
        const producaoHoje = producoesVisiveisParaUsuario().filter(p => p.data === hoje);

        if (producaoHoje.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" class="text-center" style="padding: 40px;">📭 Nenhuma produção registrada hoje</td></tr>';
            return;
        }

        producaoHoje.forEach(producao => {
            const funcionario = DataManager.findById(funcionarios, producao.funcionarioId);
            const peca = DataManager.findById(pecas, producao.pecaId);
            const cor = DataManager.findById(cores, producao.corId);

            let valorUnitario = peca ? peca.valor : 0;
            let valorTotal = valorUnitario * producao.quantidade;

            if (producao.horaExtra) {
                valorUnitario = valorUnitario * 1.5;
                valorTotal = valorUnitario * producao.quantidade;
            }

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${formatarData(producao.data)}</td>
                <td>${esc(funcionario ? funcionario.nome : 'N/A')}</td>
                <td>${esc(peca ? peca.nome : 'N/A')}</td>
                <td>${esc(cor ? cor.nome : 'N/A')}</td>
                <td>${producao.quantidade}</td>
                <td>${producao.horaExtra ? '<span class="badge-tipo badge-pedido">SIM</span>' : 'Não'}</td>
                <td class="valor">${formatarMoeda(valorUnitario)}</td>
                <td class="valor">${formatarMoeda(valorTotal)}</td>
                <td>${(() => { const u = producao.login_user; if (!u) return '<span style="color:var(--muted);font-size:12px;">—</span>'; const isMob = u==='Mobile'||u.startsWith('mob'); return '<span class="badge-login'+(isMob?' mobile':'')+'">'+( isMob?'📱':'🖥️')+' '+esc(u)+'</span>'; })()}</td>
                <td class="actions">
                    <button class="btn-editar" data-edit-handler="editarProducao" data-id="${producao.id}">✏️</button>
                    <button class="btn-excluir" onclick="excluirProducao(${producao.id})">🗑️</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    },

    refreshPecasTable() {
        const tbody = document.querySelector('#tabelaPecas tbody');
        if (!tbody) return;

        tbody.innerHTML = '';

        if (pecas.length === 0) {
            tbody.innerHTML = '<tr><td colspan="3" class="text-center" style="padding: 40px;">📭 Nenhuma peça cadastrada</td></tr>';
            return;
        }

        pecas.forEach(peca => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${esc(peca.nome)}</td>
                <td class="valor">${formatarMoeda(peca.valor)}</td>
                <td class="actions">
                    <button class="btn-editar" data-edit-handler="editarPeca" data-id="${peca.id}">✏️</button>
                    <button class="btn-excluir" onclick="excluirPeca(${peca.id})">🗑️</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    },

    refreshFuncionariosTable() {
        const tbody = document.querySelector('#tabelaFuncionarios tbody');
        if (!tbody) return;

        tbody.innerHTML = '';

        if (funcionarios.length === 0) {
            tbody.innerHTML = '<tr><td colspan="3" class="text-center" style="padding: 40px;">📭 Nenhum funcionário cadastrado</td></tr>';
            return;
        }

        funcionarios.forEach(funcionario => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${esc(funcionario.nome)}</td>
                <td>${esc(funcionario.cargo)}</td>
                <td class="actions">
                    <button class="btn-editar" data-edit-handler="editarFuncionario" data-id="${funcionario.id}">✏️</button>
                    <button class="btn-excluir" onclick="excluirFuncionario(${funcionario.id})">🗑️</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    },

    refreshCoresTable() {
        const tbody = document.querySelector('#tabelaCores tbody');
        if (!tbody) return;

        tbody.innerHTML = '';

        if (cores.length === 0) {
            tbody.innerHTML = '<tr><td colspan="2" class="text-center" style="padding: 40px;">📭 Nenhuma cor cadastrada</td></tr>';
            return;
        }

        cores.forEach(cor => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${esc(cor.nome)}</td>
                <td class="actions">
                    <button class="btn-editar" data-edit-handler="editarCor" data-id="${cor.id}">✏️</button>
                    <button class="btn-excluir" onclick="excluirCor(${cor.id})">🗑️</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    },

    refreshSaldosTable() {
        const tbody = document.querySelector('#tabelaSaldos tbody');
        if (!tbody) return;

        const saldosArray = this.calcularSaldos();

        saldosArray.sort((a, b) => {
            const pecaA = DataManager.findById(pecas, a.pecaId);
            const pecaB = DataManager.findById(pecas, b.pecaId);
            const corA = DataManager.findById(cores, a.corId);
            const corB = DataManager.findById(cores, b.corId);

            if (!pecaA || !pecaB) return 0;
            if (pecaA.nome < pecaB.nome) return -1;
            if (pecaA.nome > pecaB.nome) return 1;

            const nomeCorA = corA ? corA.nome : '';
            const nomeCorB = corB ? corB.nome : '';
            return nomeCorA.localeCompare(nomeCorB);
        });

        tbody.innerHTML = '';

        if (saldosArray.length === 0) {
            tbody.innerHTML = '<tr><td colspan="3" class="text-center" style="padding: 40px;">📭 Nenhum saldo calculado</td></tr>';
            return;
        }

        saldosArray.forEach(s => {
            const peca = DataManager.findById(pecas, s.pecaId);
            const cor = DataManager.findById(cores, s.corId);
            if (!peca) return;

            let classeSaldo = 'saldo-ok';
            if (s.saldo < 0) classeSaldo = 'saldo-negativo';
            else if (s.saldo < 5) classeSaldo = 'saldo-critico';
            else if (s.saldo < 10) classeSaldo = 'saldo-alerta';

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${esc(peca.nome)}</td>
                <td>${esc(cor ? cor.nome : 'Sem cor')}</td>
                <td class="${classeSaldo}">${s.saldo}</td>
            `;
            tbody.appendChild(tr);
        });
    },

    calcularSaldos() {
        const saldos = {};

        movimentacoes.forEach(mov => {
            const key = `${mov.pecaId}-${mov.corId}`;
            if (!saldos[key]) {
                saldos[key] = { pecaId: mov.pecaId, corId: mov.corId, saldo: 0 };
            }
            saldos[key].saldo += mov.tipo === 'entrada' ? mov.quantidade : -mov.quantidade;
        });

        return Object.values(saldos);
    },

    refreshArmacoesTables() {
        this.refreshArmacoesEstoque();
        this.refreshHistoricoArmacoes();
    },

    refreshArmacoesEstoque() {
        const tbody = document.querySelector('#tabelaArmacoes tbody');
        if (!tbody) return;

        tbody.innerHTML = '';

        const estoqueMap = {};
        estoqueArmacoes.forEach(e => {
            estoqueMap[e.modeloId] = e.quantidade;
        });

        const pecasComEstoque = pecas.filter(p => estoqueMap[p.id] !== undefined);
        
        if (pecasComEstoque.length === 0) {
            tbody.innerHTML = '<tr><td colspan="3" class="text-center" style="padding: 40px;">📭 Nenhuma armação registrada</td></tr>';
            return;
        }

        pecasComEstoque.forEach(peca => {
            const quantidade = estoqueMap[peca.id] || 0;
            
            let classeSaldo = 'saldo-ok';
            if (quantidade < 0) classeSaldo = 'saldo-negativo';
            else if (quantidade < 5) classeSaldo = 'saldo-critico';
            else if (quantidade < 10) classeSaldo = 'saldo-alerta';
            
            const ultimaChegada = armacoes
                .filter(a => a.modeloId === peca.id)
                .sort((a, b) => b.data.localeCompare(a.data))[0];
            
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${esc(peca.nome)}</td>
                <td class="${classeSaldo}">${quantidade}</td>
                <td>${ultimaChegada ? formatarData(ultimaChegada.data) : '-'}</td>
            `;
            tbody.appendChild(tr);
        });
    },

    refreshHistoricoArmacoes() {
        const tbody = document.querySelector('#tabelaHistoricoArmacoes tbody');
        if (!tbody) return;

        tbody.innerHTML = '';

        if (armacoes.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center" style="padding: 40px;">📭 Nenhum registro de chegada</td></tr>';
            return;
        }

        [...armacoes].sort((a,b) => b.data.localeCompare(a.data)).forEach(armacao => {
            const peca = DataManager.findById(pecas, armacao.modeloId);
            const operador = armacao.login_user || '—';
            const isMobile = operador && (operador === 'Mobile' || operador.startsWith('mob'));

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${formatarData(armacao.data)}</td>
                <td>${esc(peca ? peca.nome : 'Modelo removido')}</td>
                <td>${armacao.quantidade}</td>
                <td><span class="badge-login ${isMobile ? 'mobile' : ''}">${isMobile ? '📱' : '🖥️'} ${esc(operador)}</span></td>
                <td class="actions">
                    <button class="btn-editar" onclick="editarArmacao(${armacao.id})">✏️</button>
                    <button class="btn-excluir" onclick="excluirArmacao(${armacao.id})">🗑️</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    }
};


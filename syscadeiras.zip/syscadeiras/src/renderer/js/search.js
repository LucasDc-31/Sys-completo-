/**
 * search.js
 * Funções de pesquisa/filtro
 * (Extraído de script.js, linhas 2128-2259 do arquivo original)
 */

// ============================================
// FUNÇÕES DE PESQUISA
// ============================================

async function pesquisarEstoque() {
    const termo = document.getElementById('pesquisaEstoque').value;
    const loadingIndicator = document.getElementById('loadingIndicator');
    const resultadoInfo = document.getElementById('resultadoPesquisa');
    
    loadingIndicator.style.display = 'inline-block';
    resultadoInfo.style.display = 'flex';
    
    try {
        const filtros = {
            texto: termo || undefined
        };
        
        const result = await window.electronAPI.database.invoke(
            'pesquisar-movimentacoes',
            filtros
        );
        
        document.getElementById('infoResultado').innerHTML = 
            `📊 Encontrados ${result.success ? result.result.length : 0} resultados`;
        
    } catch (error) {
        console.error('Erro na pesquisa:', error);
        document.getElementById('infoResultado').innerHTML = '❌ Erro na pesquisa';
    } finally {
        loadingIndicator.style.display = 'none';
    }
}

async function aplicarFiltrosEstoque() {
    const pecaId = document.getElementById('filtroPecaEstoque').value;
    const corId = document.getElementById('filtroCorEstoque').value;
    const dataInicio = document.getElementById('filtroDataInicio').value;
    const dataFim = document.getElementById('filtroDataFim').value;
    
    const loadingIndicator = document.getElementById('loadingIndicator');
    const resultadoInfo = document.getElementById('resultadoPesquisa');
    
    loadingIndicator.style.display = 'inline-block';
    resultadoInfo.style.display = 'flex';
    
    try {
        let saldosFiltrados = await calcularSaldosComFiltros(pecaId, corId, dataInicio, dataFim);
        
        document.getElementById('infoResultado').innerHTML = 
            `📊 Encontradas ${saldosFiltrados.length} variações de estoque`;
        
        const tbody = document.querySelector('#tabelaSaldos tbody');
        tbody.innerHTML = '';
        
        saldosFiltrados.sort((a, b) => {
            const pecaA = DataManager.findById(pecas, a.pecaId);
            const pecaB = DataManager.findById(pecas, b.pecaId);
            const corA = DataManager.findById(cores, a.corId);
            const corB = DataManager.findById(cores, b.corId);

            if (!pecaA || !pecaB) return 0;
            if (pecaA.nome < pecaB.nome) return -1;
            if (pecaA.nome > pecaB.nome) return 1;

            const nomeCorA = corA ? corA.nome : '';
            const nomeCorB = corB ? corB.nome : '';
            return nomeCorA.localeCompare(nomeCorB);
        });

        saldosFiltrados.forEach(s => {
            const peca = DataManager.findById(pecas, s.pecaId);
            const cor = DataManager.findById(cores, s.corId);
            if (!peca) return;

            let classeSaldo = 'saldo-ok';
            if (s.saldo < 0) classeSaldo = 'saldo-negativo';
            else if (s.saldo < 5) classeSaldo = 'saldo-critico';
            else if (s.saldo < 10) classeSaldo = 'saldo-alerta';

            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${esc(peca.nome)}</td>
                <td>${esc(cor ? cor.nome : 'Sem cor')}</td>
                <td class="${classeSaldo}">${s.saldo}</td>
            `;
            tbody.appendChild(tr);
        });
        
    } catch (error) {
        console.error('Erro ao aplicar filtros:', error);
        document.getElementById('infoResultado').innerHTML = '❌ Erro ao aplicar filtros';
    } finally {
        loadingIndicator.style.display = 'none';
    }
}

async function calcularSaldosComFiltros(pecaId, corId, dataInicio, dataFim) {
    let movFiltradas = movimentacoes;
    
    if (dataInicio) {
        movFiltradas = movFiltradas.filter(m => m.data >= dataInicio);
    }
    if (dataFim) {
        movFiltradas = movFiltradas.filter(m => m.data <= dataFim);
    }
    
    const saldos = {};
    movFiltradas.forEach(mov => {
        if (pecaId && mov.pecaId != pecaId) return;
        if (corId && mov.corId != corId) return;
        
        const key = `${mov.pecaId}-${mov.corId}`;
        if (!saldos[key]) {
            saldos[key] = { pecaId: mov.pecaId, corId: mov.corId, saldo: 0 };
        }
        saldos[key].saldo += mov.tipo === 'entrada' ? mov.quantidade : -mov.quantidade;
    });
    
    return Object.values(saldos);
}

function limparFiltrosEstoque() {
    document.getElementById('pesquisaEstoque').value = '';
    document.getElementById('filtroPecaEstoque').value = '';
    document.getElementById('filtroCorEstoque').value = '';
    document.getElementById('filtroDataInicio').value = '';
    document.getElementById('filtroDataFim').value = '';
    
    document.getElementById('resultadoPesquisa').style.display = 'none';
    UIManager.refreshSaldosTable();
}


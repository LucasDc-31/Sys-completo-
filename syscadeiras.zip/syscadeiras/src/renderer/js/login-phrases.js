/**
 * login-phrases.js
 * Frase do dia exibida na tela de login
 * (Extraído de script.js, linhas 147-205 do arquivo original)
 */

// ============================================
// FRASE DO DIA — tela de login (idêntico ao Mobile)
// ============================================
// Mesmo conjunto de frases do app Mobile, para manter a experiência
// consistente entre os dois. Uma frase aleatória é sorteada a cada vez
// que a tela de login é exibida.
const FRASES_LOGIN = [
    "A persistência vence o talento. — Elon Musk.",
    "“Sonhe grande, comece pequeno, aja agora.” — Jeff Bezos",
    '“Seu tempo é limitado, não o desperdice.” — Steve Jobs',
    '“O risco vem de não saber o que você está fazendo.” — Warren Buffett',
    "“Fracassar é parte do processo.” — Elon Musk",
    '“Feito é melhor que perfeito.” — Mark Zuckerberg',
    '“Invista em você mesmo.” — Warren Buffett',
    '“Ideias valem pouco sem execução.” — Larry Page',
    '“A inovação distingue líderes.” — Steve Jobs',
    '“Não tenha medo de ousar.” — Richard Branson',
    '“Aprenda com os erros rapidamente.” — Bill Gates',
    '“O sucesso vem da disciplina.” — Carlos Slim',
    '“Grandes coisas levam tempo.” — Jeff Bezos',
    '“Seja resiliente sempre.” — Elon Musk',
    '“Trabalhe com propósito.” — Jack Ma',
    '“Aqui é pressão todo dia, sem moleza! se foda, falou.” - Agrotaigo',
    '“Nunca pare de aprender.” — Bill Gates',
    '“Coragem cria oportunidades.” — Richard Branson',
    '“Simplifique o complicado.” — Steve Jobs',
    '"Aquietai-vos e sabei que eu sou Deus", - Salmo 46:10',
    '“Foque no longo prazo.” — Warren Buffett',
    '"Não temas, porque eu sou contigo; não te assombres, porque eu sou o teu Deus", - Isaías 41:10',
    '“Execute rápido, ajuste depois.” — Mark Zuckerberg',
    '“O fracasso ensina mais que o sucesso.” — Jack Ma',
    '“Construa algo que importe.” — Larry Page',
    'Bendito o homem que confia no Senhor e cuja esperança é o Senhor", - Jeremias 17:7',
    '“Seja apaixonado pelo que faz.” — Elon Musk',
    '“Pense diferente.” — Steve Jobs',
    '“Comece antes de estar pronto.” — Jeff Bezos',
    '“Ação gera resultado.” — Carlos Slim',
    '“Disciplina supera motivação.” — Warren Buffett',
    '“Seja útil para o mundo.” — Bill Gates',
    '“Grandes sonhos exigem coragem.” — Richard Branson',
    '“Quem levanta cedo já sai na frente.”',
    '"Dor é temporária. Desistir dura para sempre", - Lance Armstrong',
    '"Faça hoje o que os outros não fazem para ter amanhã o que os outros não têm", - Rai',
    '"Porque para Deus nada é impossível", - Lucas 1:37',
];

function exibirFraseLogin() {
    const el = document.getElementById('fraseDoDia');
    if (!el) return;
    const i = Math.floor(Math.random() * FRASES_LOGIN.length);
    el.textContent = FRASES_LOGIN[i];
}

// Variáveis globais para os gráficos
let entradaSaidaChart = null;
let topItensChart = null;
let movimentacoesPorDiaChart = null;
let producaoFuncionariosChart = null;


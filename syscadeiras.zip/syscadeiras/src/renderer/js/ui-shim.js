/**
 * ui-shim.js
 * Camada de compatibilidade entre o novo layout (topbar/sidebar) e as
 * funções globais definidas em src/renderer/js/*.js (ex-script.js).
 * (Extraído do <script> inline de index.html, linhas 907-986 do arquivo original)
 */

// ── Escape de HTML para uso em innerHTML ──
// Usado para sanitizar dados de usuário (nomes de peça, cor, funcionário,
// observações etc.) antes de inserir em innerHTML, evitando XSS armazenado.
// Definido aqui por ser o primeiro script carregado, ficando disponível
// globalmente (window.esc) para todos os demais arquivos.
function esc(valor) {
  if (valor === null || valor === undefined) return '';
  return String(valor)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}
window.esc = esc;

// ── Shim para compatibilidade: showSection agora controla sidebar + pages ──
function showSection(nome, btn) {
  // pages
  document.querySelectorAll('.main-content .page').forEach(p => p.classList.remove('active'));
  const pg = document.getElementById(nome);
  if (pg) pg.classList.add('active');
  // sidebar buttons
  document.querySelectorAll('.sidebar .nb').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  // section shim (script.js ainda usa .section)
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  if (pg) pg.classList.add('section', 'active');
  // Seção Histórico (admin only): carrega os dados sempre que a aba abre
  if (nome === 'historico' && window.carregarHistoricoTela) {
    window.carregarHistoricoTela();
  }
}

// Login shim — encaminha para fazerLogin do script.js
// script.js já define fazerLogin(); apenas garantimos que o overlay some
// e mostramos topbar + layout.
const _origFazerLogin_idx = null; // defined in script.js

// Patch leve: após login com sucesso mostrar topbar e layout
const _patchLogin = () => {
  const orig = window.fazerLogin;
  if (!orig) { setTimeout(_patchLogin, 100); return; }
  window.fazerLogin = async function() {
    await orig();
    // script.js já esconde loginOverlay via currentUser; mas garantimos layout
    if (window.currentUser) {
      document.getElementById('appTopbar').style.display = 'flex';
      document.getElementById('appLayout').style.display  = 'flex';
      // sync badge
      const b = document.getElementById('syncBadge');
      const t = document.getElementById('syncTxt');
      if(b && t) { b.className='sbadge on'; t.textContent='Online'; }
    }
  };
};
setTimeout(_patchLogin, 200);

// Patch logout
const _patchLogout = () => {
  const orig = window.fazerLogout;
  if (!orig) { setTimeout(_patchLogout, 100); return; }
  window.fazerLogout = function() {
    document.getElementById('appTopbar').style.display = 'none';
    document.getElementById('appLayout').style.display  = 'none';
    orig();
  };
};
setTimeout(_patchLogout, 200);

// Mostramos layout se já houver sessão ativa (script.js verifica currentUser)
window.addEventListener('DOMContentLoaded', () => {
  // hideLoginOverlay é chamado por script.js quando login é bem-sucedido
  // Observamos o loginOverlay: quando fica hidden, mostramos o layout
  const obs = new MutationObserver(() => {
    const lo = document.getElementById('loginOverlay');
    if (lo && lo.classList.contains('hidden')) {
      document.getElementById('appTopbar').style.display = 'flex';
      document.getElementById('appLayout').style.display  = 'flex';
    }
  });
  obs.observe(document.getElementById('loginOverlay'), { attributes: true, attributeFilter: ['class'] });

  // Modais shim: script.js usa display flex via classList
  ['modalMigracao','modalSalvar','modalEstatisticas'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    const origShow = el.style.display;
    Object.defineProperty(el.style, '_display', {
      get() { return this.__display; },
      set(v) { this.__display = v; }
    });
  });
});
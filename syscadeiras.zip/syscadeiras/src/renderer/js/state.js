/**
 * state.js
 * Estado global do app e sistema de permissões por conta
 * (Extraído de script.js, linhas 1-146 do arquivo original)
 */

// ============================================
// SCRIPT.JS COMPLETO COM MÓDULO DE ARMAÇÕES (SEM DASHBOARD NO RELATÓRIO)
// ============================================

// ── UI helpers: toast, showLoad, hideLoad ──
function toast(msg, tipo='info') {
    const icons = {success:'✅', error:'❌', warn:'⚠️', info:'ℹ️'};
    const wrap = document.getElementById('toastWrap');
    if (!wrap) { console.log('[toast]', msg); return; }
    const el = document.createElement('div');
    el.className = `toast ${tipo}`;
    el.innerHTML = `<span>${icons[tipo]||'ℹ️'}</span><span>${esc(msg)}</span>`;
    wrap.appendChild(el);
    setTimeout(() => el.remove(), 4000);
}
function showLoad(txt='Carregando...') {
    const ov = document.getElementById('lOv');
    const t  = document.getElementById('lTxt');
    if (ov) ov.classList.remove('hidden');
    if (t)  t.textContent = txt;
}
function hideLoad() {
    const ov = document.getElementById('lOv');
    if (ov) ov.classList.add('hidden');
}

// ESTADO GLOBAL
let producoes = [];
let pecas = [];
let funcionarios = [];
let cores = [];
let movimentacoes = [];
let armacoes = [];
let estoqueArmacoes = [];
let usuarios = [];

// Usuário logado no desktop
let currentUser = null;

// Seções que podem ser liberadas/bloqueadas por conta. "usuarios" não entra aqui
// de propósito: gestão de usuários continua restrita apenas a administradores.
const PERMISSOES_DISPONIVEIS = [
    { id: 'producao',     label: '🏭 Produção' },
    { id: 'modelos',      label: '🪑 Modelos' },
    { id: 'funcionarios', label: '👷 Funcionários' },
    { id: 'cores',        label: '🎨 Cores' },
    { id: 'estoque',      label: '📦 Estoque' },
    { id: 'armacoes',     label: '🔩 Armações' },
    { id: 'saidas',       label: '📤 Saídas' },
    { id: 'relatorios',   label: '📊 Relatórios' },
    { id: 'backup',       label: '💾 Backup' },
];

// Sub-permissões de "Relatórios": só aparecem/valem quando a permissão
// 'relatorios' está marcada. Controlam quais TIPOS de relatório a conta
// pode abrir (a tela de Relatórios em si já é liberada pela permissão
// 'relatorios' — isto aqui refina o que dentro dela fica visível).
// Guardadas com o prefixo "relatorio:" dentro do mesmo array de permissões
// para não colidir com os ids de seções acima (ex: 'estoque' já é usado
// para liberar a TELA de Estoque, que é uma coisa diferente do relatório).
const TIPOS_RELATORIO_DISPONIVEIS = [
    { id: 'producao', label: '📈 Produção' },
    { id: 'modelos',  label: '🪑 Modelo/Cor' },
    { id: 'folha',    label: '💰 Folha de Pagamento' },
    { id: 'armacoes', label: '🔩 Armações' },
    { id: 'estoque',  label: '📦 Estoque' },
];
const PREFIXO_PERMISSAO_RELATORIO = 'relatorio:';

// Quais tipos de relatório a conta logada pode ver. Admin (ou permissoes:['*'])
// sempre vê todos. Para contas comuns: se a permissão 'relatorios' não foi dada,
// nenhum; se foi dada mas nenhum sub-tipo foi marcado (contas criadas antes
// desta funcionalidade, ou o admin não marcou nada), libera só "Produção" —
// o mínimo necessário pra tela não ficar vazia — mantendo compatível com
// cadastros já existentes sem quebrar o acesso deles.
function tiposRelatorioPermitidos() {
    if (!currentUser) return [];
    if (currentUser.role === 'admin') return TIPOS_RELATORIO_DISPONIVEIS.map(t => t.id);
    const permissoes = currentUser.permissoes || [];
    if (permissoes.includes('*')) return TIPOS_RELATORIO_DISPONIVEIS.map(t => t.id);
    if (!permissoes.includes('relatorios')) return [];

    const marcados = permissoes
        .filter(p => p.startsWith(PREFIXO_PERMISSAO_RELATORIO))
        .map(p => p.slice(PREFIXO_PERMISSAO_RELATORIO.length));
    return marcados.length > 0 ? marcados : ['producao'];
}

function podeVerTipoRelatorio(tipo) {
    return tiposRelatorioPermitidos().includes(tipo);
}

// Retorna true se o usuário logado pode acessar a seção informada.
// Admin (ou conta com permissoes:['*']) sempre tem acesso total.
function temAcesso(secaoId) {
    if (!currentUser) return false;
    if (currentUser.role === 'admin') return true;
    const permissoes = currentUser.permissoes || [];
    if (permissoes.includes('*')) return true;
    return permissoes.includes(secaoId);
}

// Mostra/oculta os botões do menu lateral conforme as permissões da conta logada.
function aplicarPermissoesNaSidebar() {
    PERMISSOES_DISPONIVEIS.forEach(p => {
        const btn = document.getElementById('nav-' + p.id);
        if (!btn) return;
        const liberado = temAcesso(p.id);
        btn.style.display = liberado ? '' : 'none';
        btn.classList.toggle('hidden', !liberado);
    });
}

// Abre a primeira seção liberada para o usuário logado (fallback quando ele
// não tem acesso à seção padrão "producao").
function abrirPrimeiraSecaoPermitida() {
    if (temAcesso('producao')) { showSection('producao', document.getElementById('nav-producao')); return; }
    const primeira = PERMISSOES_DISPONIVEIS.find(p => temAcesso(p.id));
    if (primeira) {
        showSection(primeira.id, document.getElementById('nav-' + primeira.id));
    } else {
        toast('Sua conta não tem acesso a nenhuma seção. Contate o administrador.', 'error');
    }
}

// Retorna true se o usuário logado só pode ver a própria produção nos
// relatórios — ou seja, não é admin E possui um funcionarioId vinculado
// (conta pessoal criada automaticamente no cadastro do funcionário).
function usuarioRestritoAPropriaProducao() {
    return !!currentUser && currentUser.role !== 'admin' && currentUser.funcionarioId != null;
}

// Fonte única para qualquer tela/relatório que liste produções: aplica a
// regra "cada funcionário só vê a própria produção" de forma centralizada,
// para que nenhuma tela precise reimplementar esse filtro por conta própria.
// Administradores (e contas sem funcionarioId vinculado) continuam vendo tudo.
function producoesVisiveisParaUsuario() {
    if (!usuarioRestritoAPropriaProducao()) return producoes;
    return producoes.filter(p => p.funcionarioId === currentUser.funcionarioId);
}

let tipoRelatorioAtual = 'geral';
let deferredPrompt;
let producoesSelecionadas = new Set();
let timeoutPesquisa = null;


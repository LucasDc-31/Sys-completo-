/**
 * backup-ui.js
 * Funções de backup (lado da interface)
 * (Extraído de script.js, linhas 3438-3548 do arquivo original)
 */

// ============================================
// FUNÇÕES DE BACKUP
// ============================================

async function criarBackup() {
    try {
        const pastaResult = await window.electronAPI.backup.selecionarPasta();
        if (!pastaResult.success) {
            if (!pastaResult.canceled) toast('Erro ao selecionar pasta: ' + pastaResult.error, 'error');
            return;
        }
        showLoad('Criando backup...');
        const resultado = await window.electronAPI.backup.criar(pastaResult.path);
        hideLoad();
        if (resultado.success) {
            toast(`Backup criado: ${resultado.nome}`, 'success');
        } else {
            toast('Erro ao criar backup: ' + resultado.error, 'error');
        }
    } catch (error) {
        hideLoad();
        toast('Erro inesperado: ' + error.message, 'error');
    }
}

async function restaurarBackup() {
    try {
        if (!confirm('⚠️ ATENÇÃO: Restaurar substituirá TODOS os dados atuais!\n\nO sistema reiniciará automaticamente. Deseja continuar?')) return;

        const arquivoResult = await window.electronAPI.backup.selecionarArquivo([
            { name: 'Arquivos de Backup', extensions: ['db'] }
        ]);
        if (!arquivoResult.success) {
            if (!arquivoResult.canceled) toast('Erro ao selecionar arquivo: ' + arquivoResult.error, 'error');
            return;
        }
        showLoad('Restaurando backup...');
        const resultado = await window.electronAPI.backup.restaurar(arquivoResult.path);
        hideLoad();
        if (resultado.success) {
            toast('Backup restaurado! Reiniciando...', 'success');
        } else {
            toast('Erro ao restaurar backup: ' + resultado.error, 'error');
        }
    } catch (error) {
        hideLoad();
        toast('Erro inesperado: ' + error.message, 'error');
    }
}

async function exportarJSON() {
    try {
        const pastaResult = await window.electronAPI.backup.selecionarPasta();
        if (!pastaResult.success) {
            if (!pastaResult.canceled) toast('Erro ao selecionar pasta: ' + pastaResult.error, 'error');
            return;
        }
        showLoad('Exportando JSON...');
        const resultado = await window.electronAPI.backup.exportarJSON(pastaResult.path);
        hideLoad();
        if (resultado.success) {
            toast(`JSON exportado: ${resultado.nome} (${resultado.totalRegistros} registros)`, 'success');
        } else {
            toast('Erro ao exportar JSON: ' + resultado.error, 'error');
        }
    } catch (error) {
        hideLoad();
        toast('Erro inesperado: ' + error.message, 'error');
    }
}

async function importarJSON() {
    try {
        const arquivoResult = await window.electronAPI.backup.selecionarArquivo([
            { name: 'Arquivos JSON', extensions: ['json'] }
        ]);
        if (!arquivoResult.success) {
            if (!arquivoResult.canceled) toast('Erro ao selecionar arquivo: ' + arquivoResult.error, 'error');
            return;
        }

        const verificacao = await window.electronAPI.backup.importarJSON(arquivoResult.path, false);
        if (!verificacao.precisaConfirmacao) {
            if (!verificacao.success) toast('Erro ao importar JSON: ' + verificacao.error, 'error');
            return;
        }

        const metadata = verificacao.metadata;
        const confirmar = confirm(
            `📄 Aplicação: ${metadata.aplicacao}\n` +
            `📅 Data: ${new Date(metadata.dataExportacao).toLocaleString()}\n` +
            `📊 Registros: ${metadata.totalRegistros}\n\n` +
            `⚠️ Deseja substituir os dados atuais por estes registros?`
        );
        if (!confirmar) return;

        showLoad('Importando dados...');
        const resultado = await window.electronAPI.backup.importarJSON(arquivoResult.path, true);
        hideLoad();
        if (resultado.success) {
            toast(`Importado com sucesso! ${resultado.totalRegistros} registros.`, 'success');
            await DataManager.refreshData();
        } else {
            toast('Erro ao importar JSON: ' + resultado.error, 'error');
        }
    } catch (error) {
        hideLoad();
        toast('Erro inesperado: ' + error.message, 'error');
    }
}


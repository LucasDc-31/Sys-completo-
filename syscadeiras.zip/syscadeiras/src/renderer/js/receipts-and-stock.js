/**
 * receipts-and-stock.js
 * Comprovantes, alerta de estoque baixo e exportação de funções globais
 * (Extraído de script.js, linhas 4230-4315 do arquivo original)
 */

// ============================================
// FUNÇÕES DE COMPROVANTES
// ============================================

function mostrarComprovanteSaida(dados) {
    const comprovante = document.getElementById('comprovanteSaida');
    document.getElementById('compData').textContent = dados.data;
    document.getElementById('compPeca').textContent = dados.peca;
    document.getElementById('compCor').textContent = dados.cor;
    document.getElementById('compQuantidade').textContent = dados.quantidade;
    document.getElementById('compObs').textContent = dados.obs || '-';
    comprovante.classList.remove('oculto');
}

function mostrarComprovanteProducao(itensFaltantes) {
    const comprovante = document.getElementById('comprovanteProducao');
    const detalhesContainer = document.getElementById('detalhesProducao');
    
    detalhesContainer.innerHTML = '';
    
    if (itensFaltantes.length === 0) {
        detalhesContainer.innerHTML = '<p style="text-align: center;">✅ Todos os itens possuem estoque suficiente!</p>';
    } else {
        itensFaltantes.forEach(item => {
            const div = document.createElement('div');
            div.className = 'comprovante-item-producao';
            div.style.cssText = 'padding: 12px; border-bottom: 1px solid #eee; margin-bottom: 10px;';
            div.innerHTML = `
                <div><strong>🪑 Modelo:</strong> <span class="modelo">${esc(item.modelo)}</span></div>
                <div><strong>🎨 Cor:</strong> <span class="cor">${esc(item.cor)}</span></div>
                <div><strong>📊 Quantidade Necessária:</strong> <span class="quantidade">${item.quantidade}</span></div>
                <div><strong>⚠️ Estoque Atual:</strong> <span class="estoque">${item.estoqueAtual}</span></div>
                <div><strong>❗ Faltam:</strong> <span class="falta" style="color: #e74c3c; font-weight: bold;">${item.falta}</span></div>
            `;
            detalhesContainer.appendChild(div);
        });
    }
    
    comprovante.classList.remove('oculto');
}

// ============================================
// FUNÇÃO PARA VERIFICAR ESTOQUE BAIXO DE ARMAÇÕES
// ============================================

async function verificarEstoqueBaixoArmacoes() {
    const modelosBaixos = estoqueArmacoes.filter(e => e.quantidade >= 0 && e.quantidade < 10);
    
    if (modelosBaixos.length > 0) {
        let mensagem = '⚠️ ALERTA DE ESTOQUE BAIXO DE ARMAÇÕES:\n\n';
        
        modelosBaixos.forEach(item => {
            const peca = pecas.find(p => p.id === item.modeloId);
            const nomeModelo = peca ? peca.nome : 'Modelo removido';
            let status = '';
            if (item.quantidade <= 0) status = '⚠️ CRÍTICO - SEM ESTOQUE!';
            else if (item.quantidade < 5) status = '⚠️ BAIXO - REPOR URGENTE!';
            else status = '📢 ATENÇÃO - ESTOQUE REDUZIDO';
            
            mensagem += `• ${nomeModelo}: ${item.quantidade} unidade(s) - ${status}\n`;
        });
        
        mensagem += '\nRecomenda-se registrar novas chegadas de armações para evitar falta na produção.';
        
        console.warn('Estoque baixo de armações:', modelosBaixos);
        
        if (modelosBaixos.some(item => item.quantidade < 5)) {
            setTimeout(() => {
                if (confirm(mensagem + '\n\nDeseja ir para o módulo de Armações agora?')) {
                    showSection('armacoes', document.getElementById('nav-armacoes') || document.querySelector('.menu button[onclick*="armacoes"]'));
                }
            }, 500);
        }
    }
}

// ============================================
// EXPORTAÇÃO DE FUNÇÕES GLOBAIS
// ============================================

window.salvarComprovante = salvarComprovante;
window.mostrarComprovanteSaida = mostrarComprovanteSaida;
window.mostrarComprovanteProducao = mostrarComprovanteProducao;
window.verificarEstoqueBaixoArmacoes = verificarEstoqueBaixoArmacoes;

// ============================================

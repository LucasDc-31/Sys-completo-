// ============================================
// logger.js — SysCadeiras
// ============================================
// Monitoramento/diagnóstico mínimo, sem dependências novas: grava
// console.log/warn/error também em arquivo, em userData/logs/app.log,
// com rotação simples (quando o arquivo passa de ~5MB, vira app.log.1).
// Isso permite investigar problemas relatados por um usuário remoto sem
// precisar reproduzir o cenário — basta pedir o arquivo de log (ver
// diagnóstico do sistema, menu "Ajuda" e IPC 'diagnostico-info').
// ============================================

const fs = require('fs');
const path = require('path');
const { app } = require('electron');

const TAMANHO_MAXIMO = 5 * 1024 * 1024; // 5MB
let logPath = null;
let inicializado = false;

function pastaLogs() {
    return path.join(app.getPath('userData'), 'logs');
}

function caminhoLog() {
    if (!logPath) logPath = path.join(pastaLogs(), 'app.log');
    return logPath;
}

function rotacionarSeNecessario() {
    try {
        const p = caminhoLog();
        if (fs.existsSync(p) && fs.statSync(p).size > TAMANHO_MAXIMO) {
            const antigo = p + '.1';
            if (fs.existsSync(antigo)) fs.unlinkSync(antigo);
            fs.renameSync(p, antigo);
        }
    } catch (_) { /* não crítico */ }
}

function escrever(nivel, args) {
    try {
        fs.mkdirSync(pastaLogs(), { recursive: true });
        rotacionarSeNecessario();
        const linha = `[${new Date().toISOString()}] [${nivel}] ${args.map(a => {
            if (a instanceof Error) return a.stack || a.message;
            if (typeof a === 'object') { try { return JSON.stringify(a); } catch (_) { return String(a); } }
            return String(a);
        }).join(' ')}\n`;
        fs.appendFileSync(caminhoLog(), linha, 'utf8');
    } catch (_) { /* nunca deixa o log travar o app */ }
}

// Sobrescreve console.log/warn/error para também gravar em arquivo, sem
// remover a saída no terminal (útil em --dev). Chamar uma única vez, cedo
// na inicialização do app (ver main.js).
function iniciar() {
    if (inicializado) return;
    inicializado = true;

    const originalLog = console.log.bind(console);
    const originalWarn = console.warn.bind(console);
    const originalError = console.error.bind(console);

    console.log = (...args) => { originalLog(...args); escrever('INFO', args); };
    console.warn = (...args) => { originalWarn(...args); escrever('WARN', args); };
    console.error = (...args) => { originalError(...args); escrever('ERROR', args); };

    console.log('📋 Logger iniciado — arquivo:', caminhoLog());
}

function obterCaminhoPasta() {
    return pastaLogs();
}

// Últimas `linhas` do log, para exibir no painel de diagnóstico sem abrir
// o arquivo inteiro (que pode ter alguns MB).
function lerUltimasLinhas(linhas = 200) {
    try {
        const p = caminhoLog();
        if (!fs.existsSync(p)) return [];
        const conteudo = fs.readFileSync(p, 'utf8').split('\n').filter(Boolean);
        return conteudo.slice(-linhas);
    } catch (e) {
        return [`(falha ao ler log: ${e.message})`];
    }
}

module.exports = { iniciar, obterCaminhoPasta, lerUltimasLinhas };

// ============================================
// supabaseSync.js — SysCadeiras v2.2 CORRIGIDO
// ============================================
// CORREÇÕES DESTA RODADA (multiempresa / multimáquina / IDs locais):
//
//   1) MULTIMÁQUINA: o guard de eco comparava `device_origin === 'desktop'`.
//      Com 2+ desktops (ex: duas lojas da mesma empresa), isso descartava
//      as mudanças de QUALQUER desktop, não só do próprio — ou seja, dois
//      desktops nunca se sincronizavam entre si. Agora o guard compara
//      `deviceId` (identificador único por instalação, ver config.js) do
//      evento recebido contra o `deviceId` desta máquina.
//
//   2) MULTIEMPRESA: todas as leituras/escritas/realtime agora são
//      filtradas por `empresaId` (config.js). Instalações com colunas
//      antigas (antes desta migração) continuam funcionando: se a coluna
//      ainda não existir no Supabase, o código detecta o erro e cai para o
//      comportamento antigo (sem filtro), avisando no log para rodar
//      `supabase/migration.sql`.
//
//   3) IDS LOCAIS → UUID: o `id` de cada tabela é um AUTOINCREMENT local —
//      duas máquinas diferentes podem ter, cada uma, um registro de id=1
//      para peças completamente diferentes. Usar `id` como chave de
//      upsert no Supabase (como era feito antes) faz uma máquina
//      sobrescrever o registro da outra. Agora cada linha sincronizada tem
//      um `uuid` estável (gerado localmente por trigger, ver database.js)
//      e o upsert usa `uuid` como chave de conflito. Tabelas que dependem
//      de outra (Producoes → Funcionarios/Pecas/Cores, Movimentacoes →
//      Producoes, etc.) também trocam o `*Id` local pelo `*Uuid` do
//      registro pai ao espelhar, e resolvem de volta para o id LOCAL desta
//      máquina ao receber (ver resolverFKsRecebidas).
//
//   4) CONTROLE DE CONFLITO: ao receber uma linha de outra máquina, só
//      sobrescreve o dado local se `updatedAt` da linha recebida for mais
//      recente (ou igual) ao `updatedAt` local. Caso contrário, a
//      atualização recebida é apenas registrada na tabela `Conflitos` para
//      revisão manual — nenhum dado é perdido silenciosamente.
// ============================================

const { createClient } = require('@supabase/supabase-js');
const ws = require('ws');
const config = require('./config');

const SUPABASE_URL = process.env.SUPABASE_URL || 'https://wbsxoffpugmajmzxofid.supabase.co';
const SUPABASE_KEY = process.env.SUPABASE_KEY || 'sb_publishable_2qHQZTclYZFbskhwoumTvA__enYh_vx';

let supabase   = null;
let mainWindow = null;
let channel    = null;
let localDb    = null;
let reconectando = false;

let avisoMigracaoPendenteMostrado = false;
function pareceErroDeColunaAusente(mensagem) {
    const m = String(mensagem || '').toLowerCase();
    return m.includes('column') && (m.includes('does not exist') || m.includes('not found') || m.includes('unknown'));
}
function avisarMigracaoPendente(origem) {
    if (avisoMigracaoPendenteMostrado) return;
    avisoMigracaoPendenteMostrado = true;
    console.warn(
        `⚠️ Supabase ainda não tem as colunas de multiempresa/uuid (detectado em "${origem}").\n` +
        `   Rode o script supabase/migration.sql no projeto Supabase para habilitar\n` +
        `   isolamento por empresa e sincronização correta entre máquinas.\n` +
        `   Até lá, a sincronização segue funcionando no modo antigo (compatível).`
    );
}

function init(win) {
    if (win) mainWindow = win;
    if (!SUPABASE_URL || !SUPABASE_KEY) {
        console.warn('⚠️ supabaseSync: SUPABASE_URL / SUPABASE_KEY não configurados.');
        return false;
    }
    if (!supabase) {
        supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
            realtime: { transport: ws }
        });
        console.log(`✅ Supabase inicializado (empresaId=${config.getEmpresaId()}, deviceId=${config.getDeviceId()})`);
    }
    return true;
}

function setMainWindow(win) {
    mainWindow = win;
}

function setDb(db) {
    localDb = db;
}

function send(canal, dados) {
    if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send(canal, dados);
    }
}

function tabelaLocalDe(tabelaSupabase) {
    return tabelaSupabase === 'Armacoes' ? 'Armações' : tabelaSupabase;
}
function tabelaSupabaseDe(tabelaLocal) {
    return tabelaLocal === 'Armações' ? 'Armacoes' : tabelaLocal;
}

const MAPA_COLUNAS = {
    pecaid:            'pecaId',
    corid:             'corId',
    funcionarioid:     'funcionarioId',
    producaoid:        'producaoId',
    modeloid:          'modeloId',
    horaextra:         'horaExtra',
    ultimaatualizacao: 'ultimaAtualizacao',
    empresaid:         'empresaId',
    deviceid:          'deviceId',
    updatedat:         'updatedAt',
    pecauuid:          'pecaUuid',
    coruuid:           'corUuid',
    funcionariouuid:   'funcionarioUuid',
    producaouuid:      'producaoUuid',
    modelouuid:        'modeloUuid',
};

function remapearColunas(row) {
    const resultado = {};
    for (const [chave, valor] of Object.entries(row)) {
        const chaveCorreta = MAPA_COLUNAS[chave] || chave;
        resultado[chaveCorreta] = valor;
    }
    return resultado;
}

const FKS_POR_TABELA = {
    Producoes: [
        { campoId: 'funcionarioid', campoUuid: 'funcionariouuid', colunaLocalId: 'funcionarioId', colunaLocalUuid: 'funcionarioUuid', tabelaRef: 'Funcionarios' },
        { campoId: 'pecaid',        campoUuid: 'pecauuid',        colunaLocalId: 'pecaId',        colunaLocalUuid: 'pecaUuid',        tabelaRef: 'Pecas' },
        { campoId: 'corid',         campoUuid: 'coruuid',         colunaLocalId: 'corId',          colunaLocalUuid: 'corUuid',         tabelaRef: 'Cores' },
    ],
    Movimentacoes: [
        { campoId: 'pecaid',         campoUuid: 'pecauuid',         colunaLocalId: 'pecaId',         colunaLocalUuid: 'pecaUuid',         tabelaRef: 'Pecas' },
        { campoId: 'corid',          campoUuid: 'coruuid',          colunaLocalId: 'corId',          colunaLocalUuid: 'corUuid',          tabelaRef: 'Cores' },
        { campoId: 'funcionarioid',  campoUuid: 'funcionariouuid',  colunaLocalId: 'funcionarioId',  colunaLocalUuid: 'funcionarioUuid',  tabelaRef: 'Funcionarios' },
        { campoId: 'producaoid',     campoUuid: 'producaouuid',     colunaLocalId: 'producaoId',     colunaLocalUuid: 'producaoUuid',     tabelaRef: 'Producoes' },
    ],
    Armacoes: [
        { campoId: 'modeloid', campoUuid: 'modelouuid', colunaLocalId: 'modeloId', colunaLocalUuid: 'modeloUuid', tabelaRef: 'Pecas' },
    ],
    EstoqueArmacoes: [
        { campoId: 'modeloid', campoUuid: 'modelouuid', colunaLocalId: 'modeloId', colunaLocalUuid: 'modeloUuid', tabelaRef: 'Pecas' },
    ],
};

async function buscarUuidLocalPorId(tabelaLocal, id) {
    if (!localDb || id == null) return null;
    try {
        const row = await localDb.get(`SELECT uuid FROM "${tabelaLocal}" WHERE id = ?`, [id]);
        return row?.uuid || null;
    } catch (e) { return null; }
}

async function buscarIdLocalPorUuid(tabelaLocal, uuid) {
    if (!localDb || !uuid) return null;
    try {
        const row = await localDb.get(`SELECT id FROM "${tabelaLocal}" WHERE uuid = ?`, [uuid]);
        return row?.id ?? null;
    } catch (e) { return null; }
}

async function registrarConflito({ tabela, registroUuid, dadoLocal, dadoRecebido, motivo }) {
    if (!localDb) return;
    try {
        await localDb.run(
            `INSERT INTO Conflitos (tabela, registroUuid, empresaId, dadoLocal, dadoRecebido, motivo) VALUES (?,?,?,?,?,?)`,
            [tabela, registroUuid || null, config.getEmpresaId(),
             dadoLocal ? JSON.stringify(dadoLocal) : null,
             dadoRecebido ? JSON.stringify(dadoRecebido) : null,
             motivo || null]
        );
    } catch (e) {
        console.error('⚠️ Falha ao registrar conflito:', e.message);
    }
}

async function resolverFKsRecebidas(tabelaSQLite, rowMapeado) {
    const tabelaSupabase = tabelaSupabaseDe(tabelaSQLite);
    const fks = FKS_POR_TABELA[tabelaSupabase] || [];
    for (const fk of fks) {
        const uuidRecebido = rowMapeado[fk.colunaLocalUuid];
        if (!uuidRecebido) continue;
        const idLocal = await buscarIdLocalPorUuid(fk.tabelaRef, uuidRecebido);
        if (idLocal == null) {
            return { ok: false, motivo: `Registro relacionado (${fk.tabelaRef}, uuid=${uuidRecebido}) ainda não sincronizado nesta máquina.` };
        }
        rowMapeado[fk.colunaLocalId] = idLocal;
    }
    return { ok: true };
}

async function salvarNoSQLite(tabelaSQLite, row) {
    if (!localDb) {
        console.warn('⚠️ salvarNoSQLite: localDb não definido ainda.');
        return;
    }
    try {
        const rowMapeado = remapearColunas(row);

        if (rowMapeado.empresaId && rowMapeado.empresaId !== config.getEmpresaId()) {
            return;
        }

        const resolucao = await resolverFKsRecebidas(tabelaSQLite, rowMapeado);
        if (!resolucao.ok) {
            console.warn(`⚠️ ${tabelaSQLite}: ${resolucao.motivo} — linha adiada (uuid=${rowMapeado.uuid || '?'}).`);
            await registrarConflito({
                tabela: tabelaSQLite, registroUuid: rowMapeado.uuid,
                dadoRecebido: rowMapeado, motivo: resolucao.motivo,
            });
            return;
        }

        if (rowMapeado.uuid) {
            const existente = await localDb.get(`SELECT * FROM "${tabelaSQLite}" WHERE uuid = ?`, [rowMapeado.uuid]);
            if (existente && existente.updatedAt && rowMapeado.updatedAt) {
                if (new Date(existente.updatedAt).getTime() > new Date(rowMapeado.updatedAt).getTime()) {
                    await registrarConflito({
                        tabela: tabelaSQLite, registroUuid: rowMapeado.uuid,
                        dadoLocal: existente, dadoRecebido: rowMapeado,
                        motivo: 'Versão local mais recente que a recebida — atualização remota ignorada (revisar manualmente).',
                    });
                    console.warn(`⚠️ Conflito em ${tabelaSQLite} (uuid=${rowMapeado.uuid}): mantendo versão local mais recente.`);
                    return;
                }
            }
            if (existente) rowMapeado.id = existente.id;
            else delete rowMapeado.id;
        }

        const cols = Object.keys(rowMapeado).filter(
            c => c !== 'created_at' && c !== 'device_origin'
        );
        const ph = cols.map(() => '?').join(',');
        await localDb.run(
            `INSERT OR REPLACE INTO "${tabelaSQLite}" (${cols.join(',')}) VALUES (${ph})`,
            cols.map(c => rowMapeado[c])
        );
        console.log(`✅ SQLite atualizado: ${tabelaSQLite} uuid=${rowMapeado.uuid || '(legado id=' + rowMapeado.id + ')'}`);
    } catch (e) {
        console.error(`❌ Erro SQLite (${tabelaSQLite}):`, e.message);
    }
}

async function deletarDoSQLite(tabelaSQLite, identificador) {
    if (!localDb) return;
    try {
        const porUuid = typeof identificador === 'string' && identificador.includes('-');
        const { changes } = porUuid
            ? await localDb.run(`DELETE FROM "${tabelaSQLite}" WHERE uuid = ?`, [identificador])
            : await localDb.run(`DELETE FROM "${tabelaSQLite}" WHERE id = ?`, [identificador]);
        if (changes > 0) console.log(`✅ Deletado do SQLite: ${tabelaSQLite} (${porUuid ? 'uuid' : 'id'}=${identificador})`);
    } catch (e) {
        console.error(`❌ Erro ao deletar do SQLite (${tabelaSQLite}):`, e.message);
    }
}

async function deletarMovimentacoesDaProducao(producaoIdOuUuid) {
    if (!localDb || !producaoIdOuUuid) return;
    try {
        const porUuid = typeof producaoIdOuUuid === 'string' && producaoIdOuUuid.includes('-');
        const producaoIdLocal = porUuid
            ? await buscarIdLocalPorUuid('Producoes', producaoIdOuUuid)
            : producaoIdOuUuid;
        if (producaoIdLocal == null) return;
        const { changes } = await localDb.run(
            `DELETE FROM Movimentacoes WHERE producaoId = ?`, [producaoIdLocal]
        );
        if (changes > 0)
            console.log(`✅ ${changes} movimentação(ões) vinculada(s) removida(s) da produção id=${producaoIdLocal}`);
    } catch (e) {
        console.error(`❌ Erro ao deletar movimentações da produção ${producaoIdOuUuid}:`, e.message);
    }
}

function ehEcoLocal(payload) {
    const dado = payload.new || payload.old;
    const deviceIdEvento = dado?.deviceid;
    if (!deviceIdEvento) return false;
    return deviceIdEvento === config.getDeviceId();
}

function ehDeOutraEmpresa(payload) {
    const dado = payload.new || payload.old;
    const empresaIdEvento = dado?.empresaid;
    if (!empresaIdEvento) return false;
    return empresaIdEvento !== config.getEmpresaId();
}

function iniciarRealtime() {
    if (!supabase) return;

    channel = supabase.channel('desktop-sync')

        .on('postgres_changes',
            { event: '*', schema: 'public', table: 'Producoes' },
            async (p) => {
                if (ehEcoLocal(p) || ehDeOutraEmpresa(p)) return;

                console.log(`📱 Produção (${p.eventType}):`, p.new || p.old);

                if (p.eventType === 'DELETE') {
                    const chave = p.old?.uuid || p.old?.id;
                    await deletarDoSQLite('Producoes', chave);
                    await deletarMovimentacoesDaProducao(p.old?.uuid || p.old?.id);
                } else {
                    await salvarNoSQLite('Producoes', p.new);
                }

                send('sync:nova-producao', p.new || p.old);
                send('sync:recarregar', { tabela: 'producoes' });
            }
        )

        .on('postgres_changes',
            { event: '*', schema: 'public', table: 'Movimentacoes' },
            async (p) => {
                if (ehEcoLocal(p) || ehDeOutraEmpresa(p)) return;

                console.log(`📱 Movimentação (${p.eventType}):`, p.new || p.old);

                if (p.eventType === 'DELETE') {
                    await deletarDoSQLite('Movimentacoes', p.old?.uuid || p.old?.id);
                } else {
                    await salvarNoSQLite('Movimentacoes', p.new);
                }

                send('sync:nova-movimentacao', p.new || p.old);
                send('sync:recarregar', { tabela: 'movimentacoes' });
            }
        )

        .on('postgres_changes',
            { event: '*', schema: 'public', table: 'Armacoes' },
            async (p) => {
                if (ehEcoLocal(p) || ehDeOutraEmpresa(p)) return;

                console.log(`📱 Armação (${p.eventType}):`, p.new || p.old);

                if (p.eventType === 'DELETE') {
                    await deletarDoSQLite('Armações', p.old?.uuid || p.old?.id);
                } else {
                    await salvarNoSQLite('Armações', p.new);
                }

                send('sync:nova-armacao', p.new || p.old);
                send('sync:recarregar', { tabela: 'armacoes' });
            }
        )

        .on('postgres_changes',
            { event: '*', schema: 'public', table: 'EstoqueArmacoes' },
            async (p) => {
                if (ehDeOutraEmpresa(p)) return;
                if (p.eventType !== 'DELETE' && p.new) {
                    await salvarNoSQLite('EstoqueArmacoes', p.new);
                }
                send('sync:recarregar', { tabela: 'estoqueArmacoes' });
            }
        )

        .on('postgres_changes',
            { event: '*', schema: 'public', table: 'Pecas' },
            async (p) => {
                if (ehEcoLocal(p) || ehDeOutraEmpresa(p)) return;

                if (p.eventType === 'DELETE') {
                    await deletarDoSQLite('Pecas', p.old?.uuid || p.old?.id);
                } else {
                    await salvarNoSQLite('Pecas', p.new);
                }
                send('sync:cadastro', { tabela: 'Pecas', tipo: p.eventType, dado: p.new || p.old });
                send('sync:recarregar', { tabela: 'pecas' });
            }
        )

        .on('postgres_changes',
            { event: '*', schema: 'public', table: 'Cores' },
            async (p) => {
                if (ehEcoLocal(p) || ehDeOutraEmpresa(p)) return;

                if (p.eventType === 'DELETE') {
                    await deletarDoSQLite('Cores', p.old?.uuid || p.old?.id);
                } else {
                    await salvarNoSQLite('Cores', p.new);
                }
                send('sync:cadastro', { tabela: 'Cores', tipo: p.eventType, dado: p.new || p.old });
                send('sync:recarregar', { tabela: 'cores' });
            }
        )

        .on('postgres_changes',
            { event: '*', schema: 'public', table: 'Funcionarios' },
            async (p) => {
                if (ehEcoLocal(p) || ehDeOutraEmpresa(p)) return;

                if (p.eventType === 'DELETE') {
                    await deletarDoSQLite('Funcionarios', p.old?.uuid || p.old?.id);
                } else {
                    await salvarNoSQLite('Funcionarios', p.new);
                }
                send('sync:cadastro', { tabela: 'Funcionarios', tipo: p.eventType, dado: p.new || p.old });
                send('sync:recarregar', { tabela: 'funcionarios' });
            }
        )

        .subscribe((status, err) => {
            console.log('📡 Realtime status:', status);
            if (err) console.error('❌ Realtime erro de subscrição:', err);

            send('sync:status', { status });

            if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
                console.warn('⚠️ Canal Realtime com problema. Tentando reconectar em 5s...');
                if (!reconectando) {
                    reconectando = true;
                    setTimeout(() => {
                        reconectando = false;
                        pararRealtime();
                        iniciarRealtime();
                    }, 5000);
                }
            }
        });

    console.log(`✅ Realtime iniciado (empresaId=${config.getEmpresaId()}, deviceId=${config.getDeviceId()})`);
}

function pararRealtime() {
    if (channel && supabase) {
        supabase.removeChannel(channel);
        channel = null;
    }
}

async function montarPayloadEnriquecido(tabela, dados) {
    const tabelaLocal = tabelaLocalDe(tabela);
    const payload = { ...dados };

    if (dados.id != null) {
        const meuUuid = await buscarUuidLocalPorId(tabelaLocal, dados.id);
        if (meuUuid) payload.uuid = meuUuid;
    }

    const fks = FKS_POR_TABELA[tabela] || [];
    for (const fk of fks) {
        const valorId = dados[fk.campoId];
        if (valorId != null) {
            const uuidRef = await buscarUuidLocalPorId(fk.tabelaRef, valorId);
            if (uuidRef) payload[fk.campoUuid] = uuidRef;
        }
    }

    payload.empresaid = config.getEmpresaId();
    payload.deviceid = config.getDeviceId();
    payload.updatedat = new Date().toISOString();

    return payload;
}

async function espelhar(tabela, dados, conflito = 'id') {
    if (!supabase) return;

    const payloadEnriquecido = await montarPayloadEnriquecido(tabela, dados);
    let conflitoFinal = conflito;
    if (tabela === 'EstoqueArmacoes' && payloadEnriquecido.modelouuid) {
        conflitoFinal = 'modelouuid';
    } else if (payloadEnriquecido.uuid && conflito === 'id') {
        conflitoFinal = 'uuid';
    }

    try {
        const { error } = await supabase.from(tabela).upsert(payloadEnriquecido, { onConflict: conflitoFinal });
        if (error) {
            if (pareceErroDeColunaAusente(error.message)) {
                avisarMigracaoPendente(`espelhar ${tabela}`);
                const { error: erroLegado } = await supabase.from(tabela).upsert(dados, { onConflict: conflito });
                if (erroLegado) console.error(`❌ Sync espelhar ${tabela} (fallback legado):`, erroLegado.message);
                return;
            }
            console.error(`❌ Sync espelhar ${tabela}:`, error.message);
        } else {
            console.log(`✅ ${tabela} espelhado no Supabase (conflito=${conflitoFinal})`);
        }
    } catch (e) {
        console.error('❌ espelhar erro:', e);
    }
}

async function deletar(tabela, identificador) {
    if (!supabase) return;
    try {
        const porUuid = typeof identificador === 'string' && identificador.includes('-');
        const { error } = await supabase.from(tabela).delete().eq(porUuid ? 'uuid' : 'id', identificador);
        if (error) {
            if (porUuid && pareceErroDeColunaAusente(error.message)) {
                avisarMigracaoPendente(`deletar ${tabela}`);
                return;
            }
            console.error(`❌ Sync deletar ${tabela}:`, error.message);
        }
    } catch (e) {
        console.error('❌ deletar erro:', e);
    }
}

async function sincronizarInicial(db) {
    if (!supabase) return;
    localDb = db;
    console.log('🔄 Sincronização inicial Supabase → SQLite...');

    const tabelas = [
        { sb: 'Pecas',           sqlite: 'Pecas'           },
        { sb: 'Cores',           sqlite: 'Cores'           },
        { sb: 'Funcionarios',    sqlite: 'Funcionarios'    },
        { sb: 'Producoes',       sqlite: 'Producoes'       },
        { sb: 'Movimentacoes',   sqlite: 'Movimentacoes'   },
        { sb: 'Armacoes',        sqlite: 'Armações'        },
        { sb: 'EstoqueArmacoes', sqlite: 'EstoqueArmacoes' },
    ];

    const pendentes = [];

    for (const t of tabelas) {
        try {
            let filtradoPorEmpresa = true;
            let { data, error } = await supabase.from(t.sb).select('*').eq('empresaid', config.getEmpresaId());
            if (error && pareceErroDeColunaAusente(error.message)) {
                avisarMigracaoPendente(`sincronizarInicial ${t.sb}`);
                filtradoPorEmpresa = false;
                ({ data, error } = await supabase.from(t.sb).select('*'));
            }
            if (error) { console.warn(`  ⚠️ ${t.sb} erro:`, error.message); continue; }
            if (!data?.length) { console.log(`  ℹ️ ${t.sb}: vazio`); continue; }

            for (const row of data) {
                const rowMapeado = remapearColunas(row);
                if (filtradoPorEmpresa === false && rowMapeado.empresaId && rowMapeado.empresaId !== config.getEmpresaId()) {
                    continue;
                }

                const resolucao = await resolverFKsRecebidas(t.sqlite, rowMapeado);
                if (!resolucao.ok) { pendentes.push({ tabela: t.sqlite, rowMapeado }); continue; }

                const existente = rowMapeado.uuid
                    ? await db.get(`SELECT id FROM "${t.sqlite}" WHERE uuid = ?`, [rowMapeado.uuid])
                    : null;
                if (existente) rowMapeado.id = existente.id; else if (rowMapeado.uuid) delete rowMapeado.id;

                const cols = Object.keys(rowMapeado).filter(
                    c => c !== 'created_at' && c !== 'device_origin'
                );
                const ph = cols.map(() => '?').join(',');
                await db.run(
                    `INSERT OR REPLACE INTO "${t.sqlite}" (${cols.join(',')}) VALUES (${ph})`,
                    cols.map(c => rowMapeado[c])
                ).catch(e => console.warn(`    ⚠️ linha ignorada (${t.sqlite}):`, e.message));
            }
            console.log(`  ✅ ${t.sb}: ${data.length} registros sincronizados`);
        } catch (e) {
            console.warn(`  ⚠️ ${t.sb}:`, e.message);
        }
    }

    for (const pendente of pendentes) {
        const resolucao = await resolverFKsRecebidas(pendente.tabela, pendente.rowMapeado);
        if (!resolucao.ok) {
            console.warn(`  ⚠️ ${pendente.tabela}: dependência não resolvida mesmo após segunda passada — registrando conflito.`);
            await registrarConflito({ tabela: pendente.tabela, registroUuid: pendente.rowMapeado.uuid, dadoRecebido: pendente.rowMapeado, motivo: resolucao.motivo });
            continue;
        }
        const cols = Object.keys(pendente.rowMapeado).filter(c => c !== 'created_at' && c !== 'device_origin' && c !== 'id');
        const ph = cols.map(() => '?').join(',');
        await db.run(
            `INSERT OR REPLACE INTO "${pendente.tabela}" (${cols.join(',')}) VALUES (${ph})`,
            cols.map(c => pendente.rowMapeado[c])
        ).catch(e => console.warn(`    ⚠️ linha pendente ignorada (${pendente.tabela}):`, e.message));
    }

    console.log('✅ Sincronização inicial concluída');
}

module.exports = {
    init,
    setDb,
    setMainWindow,
    iniciarRealtime,
    pararRealtime,
    sincronizarInicial,
    espelhar,
    deletar,
    getClient: () => supabase,
    _internal: { remapearColunas, tabelaLocalDe, tabelaSupabaseDe },
};

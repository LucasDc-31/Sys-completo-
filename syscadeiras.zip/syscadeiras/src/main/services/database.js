// CORREÇÃO: sqlite3 (async, callback-based, binário pré-compilado por versão
// exata do Node/Electron — motivo de boa parte da dor de "instalar de novo
// depois de trocar de versão do Electron") trocado por better-sqlite3
// (síncrono, binários N-API estáveis entre versões de Node/Electron a partir
// da v13). A API pública desta classe (init/run/get/all/runInTransaction,
// todas retornando Promise) foi mantida idêntica de propósito — nenhum outro
// arquivo do projeto (main.js, migrate.js etc.) precisou mudar uma linha.
const BetterSqlite3 = require('better-sqlite3');
const path = require('path');
const crypto = require('crypto');
const { app } = require('electron');
const { hashPassword } = require('./auth');
const config = require('./config');

// Tabelas que participam da sincronização multiempresa/multimáquina e por
// isso precisam de: uuid (chave estável entre máquinas), empresaId (escopo
// por empresa) e updatedAt (usado na resolução de conflitos — ver sync.js).
// Populadas via trigger (ver _criarColunasESincronizacao), então nenhuma
// tela ou INSERT/UPDATE existente no resto do código precisa mudar.
const TABELAS_SINCRONIZADAS = [
    'Pecas', 'Cores', 'Funcionarios', 'Producoes', 'Movimentacoes',
    'Armações', 'EstoqueArmacoes',
    // Usuarios não é sincronizado de volta (o Desktop nunca lê contas do
    // Supabase — ver sync.js), mas ganha uuid/empresaId também para que o
    // espelhamento (Desktop → Supabase, usado pelo login do Mobile) use uma
    // chave estável entre máquinas em vez do id local (ver
    // espelharUsuarioNoSupabase em main.js).
    'Usuarios',
];

class Database {
    constructor() {
        this.db = null;
        this.dbPath = null;
    }

    async init() {
        try {
            const userDataPath = app.getPath('userData');
            this.dbPath = path.join(userDataPath, 'syscadeiras.db');

            const fs = require('fs');
            if (!fs.existsSync(userDataPath)) {
                fs.mkdirSync(userDataPath, { recursive: true });
            }

            console.log('Conectando ao banco em:', this.dbPath);

            this.db = new BetterSqlite3(this.dbPath);
            console.log('✅ Conectado ao SQLite');

            // CORREÇÃO 1: WAL permite leituras simultâneas durante
            // o sync Supabase sem gerar erros SQLITE_BUSY.
            // CORREÇÃO 2: foreign_keys = ON — o SQLite ignora as
            // constraints FOREIGN KEY por padrão; sem este PRAGMA
            // exclusões inconsistentes passam silenciosamente.
            this.db.pragma('journal_mode = WAL');
            this.db.pragma('foreign_keys = ON');

            // Funções SQL usadas pelos triggers de uuid/empresaId (ver
            // _criarColunasESincronizacao). Registradas na conexão antes de
            // qualquer INSERT/UPDATE rodar.
            this.db.function('uuid_gen', () => crypto.randomUUID());
            this.db.function('app_empresa_id', () => config.getEmpresaId());

            await this.createTables();
            await this.verificarEstrutura();
            await this._criarColunasESincronizacao();
        } catch (error) {
            console.error('Erro no init do Database:', error);
            throw error;
        }
    }

    createTables() {
        const queries = [
            `CREATE TABLE IF NOT EXISTS Pecas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                valor REAL NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(nome)
            )`,

            `CREATE TABLE IF NOT EXISTS Cores (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(nome)
            )`,

            `CREATE TABLE IF NOT EXISTS Funcionarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                cargo TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(nome)
            )`,

            // Usuários do sistema — login local, sem depender de conta no Supabase.
            // "permissoes" guarda um JSON com os ids das seções liberadas para a conta
            // (ex: '["saidas"]' ou '["estoque","producao"]'). Admin sempre tem acesso total.
            // "funcionarioId" vincula a conta a um registro de Funcionarios: quando
            // preenchido, a conta é "pessoal" de um funcionário (criada automaticamente
            // no cadastro dele) e só enxerga a própria produção nos relatórios — nunca
            // a de outros funcionários — a menos que role='admin'.
            `CREATE TABLE IF NOT EXISTS Usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT NOT NULL,
                senha_hash TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'operador',
                ativo INTEGER NOT NULL DEFAULT 1,
                permissoes TEXT NOT NULL DEFAULT '[]',
                funcionarioId INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(email),
                FOREIGN KEY(funcionarioId) REFERENCES Funcionarios(id)
            )`,

            `CREATE TABLE IF NOT EXISTS Producoes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                data TEXT NOT NULL,
                funcionarioId INTEGER,
                pecaId INTEGER,
                corId INTEGER,
                quantidade INTEGER NOT NULL,
                horaExtra BOOLEAN DEFAULT 0,
                login_user TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(funcionarioId) REFERENCES Funcionarios(id),
                FOREIGN KEY(pecaId) REFERENCES Pecas(id),
                FOREIGN KEY(corId) REFERENCES Cores(id)
            )`,

            `CREATE TABLE IF NOT EXISTS Movimentacoes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                data TEXT NOT NULL,
                tipo TEXT NOT NULL,
                pecaId INTEGER,
                corId INTEGER,
                quantidade INTEGER NOT NULL,
                origem TEXT,
                producaoId INTEGER,
                funcionarioId INTEGER,
                login_user TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(pecaId) REFERENCES Pecas(id),
                FOREIGN KEY(corId) REFERENCES Cores(id),
                FOREIGN KEY(funcionarioId) REFERENCES Funcionarios(id)
            )`,

            `CREATE TABLE IF NOT EXISTS Comprovantes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tipo TEXT NOT NULL,
                numero TEXT NOT NULL,
                dados TEXT NOT NULL,
                data TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,

            `CREATE TABLE IF NOT EXISTS Armações (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                data TEXT NOT NULL,
                modeloId INTEGER NOT NULL,
                quantidade INTEGER NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(modeloId) REFERENCES Pecas(id)
            )`,

            `CREATE TABLE IF NOT EXISTS EstoqueArmacoes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                modeloId INTEGER NOT NULL,
                quantidade INTEGER NOT NULL DEFAULT 0,
                ultimaAtualizacao DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(modeloId) REFERENCES Pecas(id),
                UNIQUE(modeloId)
            )`,

            // Histórico geral do sistema — todo INSERT/UPDATE/DELETE feito pelas
            // telas passa por aqui (gravado no processo principal, nunca confiando
            // no renderer). "data" e "hora" ficam separados para facilitar filtro
            // e ordenação por dia; "dadosAntes"/"dadosDepois" guardam o registro em
            // JSON para permitir auditoria completa do que mudou. Acesso restrito a
            // administradores (ver exigirAdmin() em main.js).
            `CREATE TABLE IF NOT EXISTS Historico (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                data TEXT NOT NULL,
                hora TEXT NOT NULL,
                acao TEXT NOT NULL,
                tabela TEXT NOT NULL,
                registroId INTEGER,
                usuarioId INTEGER,
                usuarioNome TEXT,
                descricao TEXT,
                dadosAntes TEXT,
                dadosDepois TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,

            // Registra conflitos detectados pela sincronização (ver
            // resolverConflito em sync.js): quando uma linha chega de outra
            // máquina mais "antiga" (updatedAt) que a versão local, ela NÃO
            // sobrescreve o dado local — fica só registrada aqui para um
            // administrador revisar manualmente em vez de perder dado
            // silenciosamente.
            `CREATE TABLE IF NOT EXISTS Conflitos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                tabela TEXT NOT NULL,
                registroUuid TEXT,
                empresaId TEXT,
                dadoLocal TEXT,
                dadoRecebido TEXT,
                motivo TEXT,
                resolvido INTEGER NOT NULL DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )`,

            // Índices para melhor performance
            `CREATE INDEX IF NOT EXISTS idx_movimentacoes_data ON Movimentacoes(data)`,
            `CREATE INDEX IF NOT EXISTS idx_movimentacoes_tipo ON Movimentacoes(tipo)`,
            `CREATE INDEX IF NOT EXISTS idx_movimentacoes_pecaId ON Movimentacoes(pecaId)`,
            `CREATE INDEX IF NOT EXISTS idx_movimentacoes_corId ON Movimentacoes(corId)`,
            `CREATE INDEX IF NOT EXISTS idx_movimentacoes_data_tipo ON Movimentacoes(data, tipo)`,
            `CREATE INDEX IF NOT EXISTS idx_producoes_data ON Producoes(data)`,
            `CREATE INDEX IF NOT EXISTS idx_producoes_funcionarioId ON Producoes(funcionarioId)`,
            `CREATE INDEX IF NOT EXISTS idx_armacoes_data ON Armações(data)`,
            `CREATE INDEX IF NOT EXISTS idx_armacoes_modeloId ON Armações(modeloId)`,
            `CREATE INDEX IF NOT EXISTS idx_estoque_armacoes_modeloId ON EstoqueArmacoes(modeloId)`,
            `CREATE INDEX IF NOT EXISTS idx_historico_data ON Historico(data)`,
            `CREATE INDEX IF NOT EXISTS idx_historico_data_hora ON Historico(data, hora)`,
            `CREATE INDEX IF NOT EXISTS idx_historico_tabela ON Historico(tabela)`,
            `CREATE INDEX IF NOT EXISTS idx_historico_usuarioId ON Historico(usuarioId)`
        ];

        // Executa as queries em série para evitar condição de corrida
        return queries.reduce((promise, query) => {
            return promise.then(() => this.run(query));
        }, Promise.resolve()).then(() => {
            console.log('✅ Todas as tabelas e índices criados/verificados');
        });
    }

    async verificarEstrutura() {
        try {
            const tabelas = ['Pecas', 'Cores', 'Funcionarios', 'Producoes', 'Movimentacoes', 'Armações', 'EstoqueArmacoes', 'Usuarios'];
            
            for (const tabela of tabelas) {
                try {
                    const colunas = await this.all(`PRAGMA table_info(${tabela})`);
                    console.log(`Estrutura da tabela ${tabela}:`, colunas.map(c => c.name));
                } catch (error) {
                    console.warn(`Erro ao verificar tabela ${tabela}:`, error.message);
                }
            }

            // ── Migração automática: adiciona colunas novas em bancos existentes ──
            const colsProducoes = await this.all(`PRAGMA table_info(Producoes)`);
            if (!colsProducoes.find(c => c.name === 'login_user')) {
                await this.run(`ALTER TABLE Producoes ADD COLUMN login_user TEXT`);
                console.log('✅ Migração: coluna login_user adicionada em Producoes');
            }

            const colsMovimentacoes = await this.all(`PRAGMA table_info(Movimentacoes)`);
            if (!colsMovimentacoes.find(c => c.name === 'login_user')) {
                await this.run(`ALTER TABLE Movimentacoes ADD COLUMN login_user TEXT`);
                console.log('✅ Migração: coluna login_user adicionada em Movimentacoes');
            }

            // Migração: coluna de permissões por conta (controle de acesso por seção)
            const colsUsuarios = await this.all(`PRAGMA table_info(Usuarios)`);
            if (!colsUsuarios.find(c => c.name === 'permissoes')) {
                await this.run(`ALTER TABLE Usuarios ADD COLUMN permissoes TEXT NOT NULL DEFAULT '[]'`);
                console.log('✅ Migração: coluna permissoes adicionada em Usuarios');
            }

            // Migração: vínculo conta <-> funcionário (login pessoal criado no cadastro)
            if (!colsUsuarios.find(c => c.name === 'funcionarioId')) {
                await this.run(`ALTER TABLE Usuarios ADD COLUMN funcionarioId INTEGER REFERENCES Funcionarios(id)`);
                console.log('✅ Migração: coluna funcionarioId adicionada em Usuarios');
            }

            // Criar admin padrão se a tabela Usuarios estiver vazia
            const totalUsuarios = await this.get(`SELECT COUNT(*) as total FROM Usuarios`);
            if (!totalUsuarios || totalUsuarios.total === 0) {
                // Senha padrão: admin123 (hash seguro com salt via scrypt — ver authUtils.js)
                const senhaHash = hashPassword('admin123');
                await this.run(
                    `INSERT OR IGNORE INTO Usuarios (nome, email, senha_hash, role, permissoes) VALUES (?, ?, ?, ?, ?)`,
                    ['Administrador', 'admin@syscadeiras.com', senhaHash, 'admin', '["*"]']
                );
                console.log('✅ Usuário admin padrão criado: admin@syscadeiras.com / admin123');
            }

        } catch (error) {
            console.error('Erro na verificação da estrutura:', error);
        }
    }

    // ── Multiempresa/multimáquina: uuid, empresaId, updatedAt ──
    // Adiciona as colunas em bancos já existentes (ALTER TABLE ... ADD
    // COLUMN é seguro em SQLite mesmo com a tabela populada) e cria
    // triggers que preenchem essas colunas automaticamente em todo
    // INSERT/UPDATE — inclusive os que já existem espalhados pelo app via
    // SQL cru (form-manager.js, sync.js, migrações, etc.). Isso evita ter
    // que alterar dezenas de pontos do código que fazem INSERT/UPDATE hoje.
    async _criarColunasESincronizacao() {
        for (const tabela of TABELAS_SINCRONIZADAS) {
            try {
                const colunas = await this.all(`PRAGMA table_info("${tabela}")`);
                const nomes = colunas.map(c => c.name);

                if (!nomes.includes('uuid')) {
                    await this.run(`ALTER TABLE "${tabela}" ADD COLUMN uuid TEXT`);
                }
                if (!nomes.includes('empresaId')) {
                    await this.run(`ALTER TABLE "${tabela}" ADD COLUMN empresaId TEXT`);
                }
                if (!nomes.includes('updatedAt')) {
                    await this.run(`ALTER TABLE "${tabela}" ADD COLUMN updatedAt TEXT`);
                }

                // Backfill: registros que já existiam antes desta versão
                // (uuid/empresaId/updatedAt nulos) recebem valores agora,
                // uma única vez. empresaId assume a empresa configurada
                // nesta máquina — correto para quem sempre operou com uma
                // única empresa; instalações multiempresa que já tinham
                // dados misturados precisam de uma correção manual pontual
                // (fora do escopo de uma migração automática seguro).
                await this.run(
                    `UPDATE "${tabela}" SET uuid = uuid_gen() WHERE uuid IS NULL`
                );
                await this.run(
                    `UPDATE "${tabela}" SET empresaId = app_empresa_id() WHERE empresaId IS NULL`
                );
                await this.run(
                    `UPDATE "${tabela}" SET updatedAt = COALESCE(updatedAt, created_at, CURRENT_TIMESTAMP) WHERE updatedAt IS NULL`
                );

                await this.run(
                    `CREATE UNIQUE INDEX IF NOT EXISTS "idx_${tabela.replace(/[^a-zA-Z0-9]/g, '_')}_uuid" ON "${tabela}"(uuid)`
                );
                await this.run(
                    `CREATE INDEX IF NOT EXISTS "idx_${tabela.replace(/[^a-zA-Z0-9]/g, '_')}_empresaId" ON "${tabela}"(empresaId)`
                );

                // Preenche uuid/empresaId em todo INSERT novo, caso ainda
                // não tenham vindo preenchidos (ex: sync trazendo uma linha
                // de outra máquina já COM uuid/empresaId — nesse caso o
                // trigger não sobrescreve, por causa do WHEN).
                await this.run(`DROP TRIGGER IF EXISTS "trg_${tabela}_ai"`);
                await this.run(`
                    CREATE TRIGGER "trg_${tabela}_ai" AFTER INSERT ON "${tabela}"
                    WHEN NEW.uuid IS NULL OR NEW.empresaId IS NULL OR NEW.updatedAt IS NULL
                    BEGIN
                        UPDATE "${tabela}" SET
                            uuid = COALESCE(NEW.uuid, uuid_gen()),
                            empresaId = COALESCE(NEW.empresaId, app_empresa_id()),
                            updatedAt = COALESCE(NEW.updatedAt, CURRENT_TIMESTAMP)
                        WHERE id = NEW.id;
                    END;
                `);

                // Atualiza updatedAt a cada UPDATE feito localmente (edição
                // pela própria tela). Quando quem está gravando é o próprio
                // sync trazendo uma linha de outra máquina, ele grava o
                // updatedAt explicitamente (ver sync.js) — o trigger só
                // preenche quando a coluna não veio setada na mesma
                // instrução, então não "rouba" a data original do outro
                // dispositivo.
                await this.run(`DROP TRIGGER IF EXISTS "trg_${tabela}_au"`);
                await this.run(`
                    CREATE TRIGGER "trg_${tabela}_au" AFTER UPDATE ON "${tabela}"
                    WHEN NEW.updatedAt IS OLD.updatedAt
                    BEGIN
                        UPDATE "${tabela}" SET updatedAt = CURRENT_TIMESTAMP WHERE id = NEW.id;
                    END;
                `);
            } catch (e) {
                console.error(`⚠️ Falha ao preparar colunas de sincronização em ${tabela}:`, e.message);
            }
        }
        console.log('✅ Colunas/triggers de sincronização (uuid/empresaId/updatedAt) verificados');
    }

    async pesquisarMovimentacoes(filtros = {}) {
        let sql = `
            SELECT 
                m.*,
                p.nome as pecaNome,
                p.valor as pecaValor,
                c.nome as corNome,
                f.nome as funcionarioNome
            FROM Movimentacoes m
            LEFT JOIN Pecas p ON m.pecaId = p.id
            LEFT JOIN Cores c ON m.corId = c.id
            LEFT JOIN Funcionarios f ON m.funcionarioId = f.id
            WHERE 1=1
        `;
        const params = [];

        if (filtros.dataInicio) {
            sql += ` AND m.data >= ?`;
            params.push(filtros.dataInicio);
        }
        if (filtros.dataFim) {
            sql += ` AND m.data <= ?`;
            params.push(filtros.dataFim);
        }
        if (filtros.tipo) {
            sql += ` AND m.tipo = ?`;
            params.push(filtros.tipo);
        }
        if (filtros.pecaId) {
            sql += ` AND m.pecaId = ?`;
            params.push(filtros.pecaId);
        }
        if (filtros.corId) {
            sql += ` AND m.corId = ?`;
            params.push(filtros.corId);
        }
        if (filtros.producaoId) {
            sql += ` AND m.producaoId = ?`;
            params.push(filtros.producaoId);
        }
        if (filtros.texto) {
            sql += ` AND (p.nome LIKE ? OR c.nome LIKE ? OR m.origem LIKE ?)`;
            const termo = `%${filtros.texto}%`;
            params.push(termo, termo, termo);
        }

        sql += ` ORDER BY m.data DESC, m.id DESC`;
        
        if (filtros.limite) {
            sql += ` LIMIT ?`;
            params.push(filtros.limite);
        }

        return this.all(sql, params);
    }

    async calcularSaldoEstoque(pecaId = null, corId = null) {
        let sql = `
            SELECT 
                m.pecaId,
                p.nome as pecaNome,
                m.corId,
                c.nome as corNome,
                SUM(CASE WHEN m.tipo = 'entrada' THEN m.quantidade ELSE -m.quantidade END) as saldo
            FROM Movimentacoes m
            LEFT JOIN Pecas p ON m.pecaId = p.id
            LEFT JOIN Cores c ON m.corId = c.id
            WHERE 1=1
        `;
        const params = [];

        if (pecaId) {
            sql += ` AND m.pecaId = ?`;
            params.push(pecaId);
        }
        if (corId) {
            sql += ` AND m.corId = ?`;
            params.push(corId);
        }

        sql += ` GROUP BY m.pecaId, m.corId ORDER BY p.nome, c.nome`;

        return this.all(sql, params);
    }

    async pesquisarProducoes(filtros = {}) {
        let sql = `
            SELECT 
                prod.*,
                f.nome as funcionarioNome,
                f.cargo as funcionarioCargo,
                p.nome as pecaNome,
                p.valor as pecaValor,
                c.nome as corNome
            FROM Producoes prod
            LEFT JOIN Funcionarios f ON prod.funcionarioId = f.id
            LEFT JOIN Pecas p ON prod.pecaId = p.id
            LEFT JOIN Cores c ON prod.corId = c.id
            WHERE 1=1
        `;
        const params = [];

        if (filtros.dataInicio) {
            sql += ` AND prod.data >= ?`;
            params.push(filtros.dataInicio);
        }
        if (filtros.dataFim) {
            sql += ` AND prod.data <= ?`;
            params.push(filtros.dataFim);
        }
        if (filtros.funcionarioId) {
            sql += ` AND prod.funcionarioId = ?`;
            params.push(filtros.funcionarioId);
        }
        if (filtros.pecaId) {
            sql += ` AND prod.pecaId = ?`;
            params.push(filtros.pecaId);
        }
        if (filtros.corId) {
            sql += ` AND prod.corId = ?`;
            params.push(filtros.corId);
        }
        if (filtros.horaExtra !== undefined) {
            sql += ` AND prod.horaExtra = ?`;
            params.push(filtros.horaExtra ? 1 : 0);
        }

        sql += ` ORDER BY prod.data DESC, prod.id DESC`;

        return this.all(sql, params);
    }

    async getEstatisticasEstoque() {
        const stats = {};

        const totalItens = await this.get(`
            SELECT 
                COUNT(DISTINCT pecaId || '-' || corId) as totalVariacoes,
                SUM(CASE WHEN tipo = 'entrada' THEN quantidade ELSE -quantidade END) as saldoTotal
            FROM Movimentacoes
        `);

        const itensBaixos = await this.all(`
            SELECT 
                m.pecaId,
                p.nome as pecaNome,
                m.corId,
                c.nome as corNome,
                SUM(CASE WHEN m.tipo = 'entrada' THEN m.quantidade ELSE -m.quantidade END) as saldo
            FROM Movimentacoes m
            LEFT JOIN Pecas p ON m.pecaId = p.id
            LEFT JOIN Cores c ON m.corId = c.id
            GROUP BY m.pecaId, m.corId
            HAVING saldo < 10
            ORDER BY saldo ASC
        `);

        const itensNegativos = await this.all(`
            SELECT 
                m.pecaId,
                p.nome as pecaNome,
                m.corId,
                c.nome as corNome,
                SUM(CASE WHEN m.tipo = 'entrada' THEN m.quantidade ELSE -m.quantidade END) as saldo
            FROM Movimentacoes m
            LEFT JOIN Pecas p ON m.pecaId = p.id
            LEFT JOIN Cores c ON m.corId = c.id
            GROUP BY m.pecaId, m.corId
            HAVING saldo < 0
            ORDER BY saldo ASC
        `);

        const hoje = new Date().toISOString().split('T')[0];
        const movHoje = await this.get(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN tipo = 'entrada' THEN quantidade ELSE 0 END) as entradas,
                SUM(CASE WHEN tipo = 'saida' THEN quantidade ELSE 0 END) as saidas
            FROM Movimentacoes
            WHERE data = ?
        `, [hoje]);

        stats.totalVariacoes = totalItens?.totalVariacoes || 0;
        stats.saldoTotal = totalItens?.saldoTotal || 0;
        stats.itensBaixos = itensBaixos || [];
        stats.itensNegativos = itensNegativos || [];
        stats.movimentacoesHoje = movHoje || { total: 0, entradas: 0, saidas: 0 };

        return stats;
    }

    // ── HISTÓRICO ──
    // Grava uma linha no histórico geral do sistema. Chamado sempre pelo
    // processo principal (main.js), nunca a partir de dados enviados crus
    // pelo renderer, para que o registro não possa ser falsificado.
    async registrarHistorico({ acao, tabela, registroId, usuarioId, usuarioNome, descricao, dadosAntes, dadosDepois }) {
        const agora = new Date();
        const data = agora.toISOString().split('T')[0];
        const hora = agora.toTimeString().split(' ')[0]; // HH:MM:SS
        try {
            await this.run(
                `INSERT INTO Historico (data, hora, acao, tabela, registroId, usuarioId, usuarioNome, descricao, dadosAntes, dadosDepois)
                 VALUES (?,?,?,?,?,?,?,?,?,?)`,
                [
                    data, hora, acao, tabela, registroId ?? null,
                    usuarioId ?? null, usuarioNome ?? null, descricao ?? null,
                    dadosAntes ? JSON.stringify(dadosAntes) : null,
                    dadosDepois ? JSON.stringify(dadosDepois) : null
                ]
            );
        } catch (e) {
            // Histórico nunca deve travar a operação principal do usuário
            console.error('⚠️ Falha ao registrar histórico:', e.message);
        }
    }

    async pesquisarHistorico(filtros = {}) {
        let sql = `SELECT * FROM Historico WHERE 1=1`;
        const params = [];

        if (filtros.dataInicio) { sql += ` AND data >= ?`; params.push(filtros.dataInicio); }
        if (filtros.dataFim)    { sql += ` AND data <= ?`; params.push(filtros.dataFim); }
        if (filtros.tabela)     { sql += ` AND tabela = ?`; params.push(filtros.tabela); }
        if (filtros.acao)       { sql += ` AND acao = ?`; params.push(filtros.acao); }
        if (filtros.usuarioId)  { sql += ` AND usuarioId = ?`; params.push(filtros.usuarioId); }
        if (filtros.texto) {
            sql += ` AND (usuarioNome LIKE ? OR descricao LIKE ? OR tabela LIKE ?)`;
            const termo = `%${filtros.texto}%`;
            params.push(termo, termo, termo);
        }

        sql += ` ORDER BY data DESC, hora DESC, id DESC`;
        if (filtros.limite) { sql += ` LIMIT ?`; params.push(filtros.limite); }

        return this.all(sql, params);
    }

    // better-sqlite3 é síncrono por natureza; os métodos permanecem `async`
    // (retornando Promise) só para não exigir nenhuma mudança em quem os
    // chama com `await`/`.then()` em todo o resto do projeto.
    async run(sql, params = []) {
        try {
            const info = this.db.prepare(sql).run(params);
            return { id: info.lastInsertRowid, changes: info.changes };
        } catch (err) {
            console.error('Erro no SQL:', err);
            console.error('Query:', sql);
            console.error('Params:', params);
            throw err;
        }
    }

    // Executa uma lista de statements [{sql, params}] como uma única
    // transação atômica: ou todos aplicam, ou nenhum aplica (ROLLBACK em
    // caso de erro em qualquer statement). Usado para operações compostas
    // (ex: registrar produção + dar baixa no estoque) onde uma falha no
    // meio do caminho não pode deixar o banco em estado inconsistente.
    //
    // Retorna um array com o resultado {id, changes} de cada statement,
    // na mesma ordem em que foram passados.
    //
    // Não substitui nem altera o comportamento de run()/get()/all() — é um
    // método adicional, opt-in, para quem precisar de atomicidade.
    // better-sqlite3 tem suporte nativo a transações síncronas (db.transaction),
    // com ROLLBACK automático caso a função interna lance uma exceção — dispensa
    // o controle manual de BEGIN/COMMIT/ROLLBACK que o driver antigo (sqlite3)
    // exigia. Mantém a mesma assinatura pública (Promise) e o mesmo suporte ao
    // marcador '$lastId' para encadear um INSERT dependente do id gerado pelo
    // INSERT anterior dentro da mesma transação.
    async runInTransaction(statements) {
        const executar = this.db.transaction((stmts) => {
            const resultados = [];
            for (const { sql, params = [] } of stmts) {
                const paramsResolvidos = params.map(p => {
                    if (p === '$lastId') {
                        const anterior = resultados[resultados.length - 1];
                        return anterior ? anterior.id : null;
                    }
                    return p;
                });

                try {
                    const info = this.db.prepare(sql).run(paramsResolvidos);
                    resultados.push({ id: info.lastInsertRowid, changes: info.changes });
                } catch (err) {
                    console.error('Erro na transação, revertendo:', err);
                    console.error('Query com falha:', sql);
                    console.error('Params:', paramsResolvidos);
                    throw err; // qualquer exceção aqui reverte a transação inteira (better-sqlite3 faz ROLLBACK automático)
                }
            }
            return resultados;
        });

        return executar(statements);
    }

    async get(sql, params = []) {
        return this.db.prepare(sql).get(params);
    }

    async all(sql, params = []) {
        return this.db.prepare(sql).all(params);
    }

    close() {
        if (this.db) {
            this.db.close(); // síncrono em better-sqlite3, sem callback
            this.db = null;
            console.log('Conexão com o banco fechada');
        }
    }
}

module.exports = Database;
// ============================================
// config.js — SysCadeiras
// ============================================
// Resolve dois problemas estruturais da sincronização multiempresa/
// multimáquina:
//
//   1) MULTIMÁQUINA: antes, o sync usava a string fixa 'desktop' em
//      `device_origin` tanto para identificar "este é um app Desktop" quanto
//      para o guard de eco (evitar reprocessar o que a própria instância
//      acabou de enviar). Isso funciona com 1 desktop, mas quebra com 2+:
//      se a Loja A e a Loja B rodam o Desktop, o guard `=== 'desktop'`
//      descarta TAMBÉM as mudanças vindas do desktop da outra loja — ou
//      seja, dois desktops nunca sincronizam entre si.
//
//      Correção: cada instalação ganha um identificador único e persistente
//      (`deviceId`, um UUID gerado uma única vez e salvo em disco). O guard
//      de eco passa a comparar `deviceId` recebido vs. `deviceId` local, e
//      `device_origin` continua existindo apenas para dizer "isto veio de
//      um app Desktop ou Mobile" (tipo de cliente), sem mais fazer parte da
//      lógica de deduplicação.
//
//   2) MULTIEMPRESA: as tabelas do Supabase eram globais — todas as
//      instalações liam e escreviam nas mesmas linhas, então os dados de
//      uma empresa apareciam para as outras. Correção: cada instalação
//      pertence a uma `empresaId` (definida uma vez, na primeira execução,
//      por um administrador — ver `config-definir-empresa` em main.js).
//      Toda leitura/escrita/realtime do sync passa a ser filtrada por essa
//      coluna (ver sync.js). O Supabase também precisa da coluna e de uma
//      política de RLS correspondente — ver supabase/migration.sql.
// ============================================

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { app } = require('electron');

let configPath = null;
let cache = null;

function gerarUuid() {
    if (typeof crypto.randomUUID === 'function') return crypto.randomUUID();
    // fallback para versões de Node sem randomUUID
    return crypto.randomBytes(16).toString('hex');
}

function caminhoConfig() {
    if (!configPath) {
        configPath = path.join(app.getPath('userData'), 'config.json');
    }
    return configPath;
}

function valoresPadrao() {
    return {
        // Identificador único desta instalação (nunca muda depois de criado).
        deviceId: gerarUuid(),
        // Identificador da empresa dona destes dados. 'default' até que um
        // administrador defina explicitamente (ver config-definir-empresa).
        // Instalações que nunca configuram empresa continuam funcionando
        // exatamente como antes (todas em 'default'), sem quebrar quem já
        // usa o sistema com uma única empresa.
        empresaId: 'default',
        empresaNome: '',
        criadoEm: new Date().toISOString(),
    };
}

function carregar() {
    if (cache) return cache;
    const p = caminhoConfig();
    try {
        if (fs.existsSync(p)) {
            const disco = JSON.parse(fs.readFileSync(p, 'utf8'));
            cache = { ...valoresPadrao(), ...disco };
            // Se o arquivo em disco não tinha deviceId (versão antiga /
            // primeira migração), gera um agora e persiste.
            if (!disco.deviceId) salvar(cache);
            return cache;
        }
    } catch (e) {
        console.warn('⚠️ config.js: falha ao ler config.json, recriando:', e.message);
    }
    cache = valoresPadrao();
    salvar(cache);
    return cache;
}

function salvar(dados) {
    cache = dados;
    try {
        fs.mkdirSync(path.dirname(caminhoConfig()), { recursive: true });
        fs.writeFileSync(caminhoConfig(), JSON.stringify(dados, null, 2), 'utf8');
    } catch (e) {
        console.error('❌ config.js: falha ao salvar config.json:', e.message);
    }
}

function getDeviceId() {
    return carregar().deviceId;
}

function getEmpresaId() {
    return carregar().empresaId || 'default';
}

function getEmpresaNome() {
    return carregar().empresaNome || '';
}

// Só deve ser chamado a partir de um canal IPC que já exige admin
// (ver 'config-definir-empresa' em main.js).
function definirEmpresa(empresaId, empresaNome) {
    if (!empresaId || typeof empresaId !== 'string' || !empresaId.trim()) {
        throw new Error('empresaId inválido.');
    }
    const atual = carregar();
    const atualizado = {
        ...atual,
        empresaId: empresaId.trim(),
        empresaNome: (empresaNome || '').trim(),
    };
    salvar(atualizado);
    return atualizado;
}

function getAll() {
    const { deviceId, empresaId, empresaNome, criadoEm } = carregar();
    return { deviceId, empresaId, empresaNome, criadoEm };
}

module.exports = {
    getDeviceId,
    getEmpresaId,
    getEmpresaNome,
    definirEmpresa,
    getAll,
};

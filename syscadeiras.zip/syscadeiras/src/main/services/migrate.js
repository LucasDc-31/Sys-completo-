// migrate.js - Script para migração do banco de dados
const Database = require('./database');

async function migrarBancoDados() {
    console.log('Iniciando migração do banco de dados...');
    
    const database = new Database();
    
    try {
        await database.init();
        console.log('✅ Migração concluída com sucesso!');
        return true;
    } catch (error) {
        console.error('❌ Erro na migração:', error);
        return false;
    } finally {
        database.close();
    }
}

// Executar se chamado diretamente
if (require.main === module) {
    migrarBancoDados().then(success => {
        process.exit(success ? 0 : 1);
    });
}

module.exports = migrarBancoDados;
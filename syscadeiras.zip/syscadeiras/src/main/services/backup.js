const fs = require('fs');
const path = require('path');
const { app } = require('electron');
const BetterSqlite3 = require('better-sqlite3');

// Tabelas que fazem parte do backup/exportação em JSON.
// Mantidas na ordem correta para reimportação (respeitando FKs).
const TABELAS = [
    'Pecas',
    'Cores',
    'Funcionarios',
    'Usuarios',
    'Producoes',
    'Movimentacoes',
    'Comprovantes',
    'Armações',
    'EstoqueArmacoes',
    'Historico'
];

class BackupManager {
    constructor() {
        this.dbPath = null;
        this.db = null; // conexão better-sqlite3 própria, usada apenas para exportar/importar JSON
    }

    async init() {
        const userDataPath = app.getPath('userData');
        this.dbPath = path.join(userDataPath, 'syscadeiras.db');
    }

    // Mantida `async`/Promise por compatibilidade com quem chama
    // `await this._abrirConexao()` — a abertura em si é síncrona no
    // better-sqlite3.
    async _abrirConexao() {
        return new BetterSqlite3(this.dbPath);
    }

    async _all(db, sql, params = []) {
        return db.prepare(sql).all(params);
    }

    async _run(db, sql, params = []) {
        const info = db.prepare(sql).run(params);
        return { id: info.lastInsertRowid, changes: info.changes };
    }

    // ── BACKUP (cópia bruta do arquivo .db) ──
    async criarBackup(destPasta) {
        try {
            if (!destPasta) return { success: false, error: 'Nenhuma pasta selecionada' };
            if (!fs.existsSync(this.dbPath)) return { success: false, error: 'Banco de dados não encontrado' };

            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const nomeArquivo = `syscadeiras-backup-${timestamp}.db`;
            const destino = path.join(destPasta, nomeArquivo);

            fs.copyFileSync(this.dbPath, destino);

            return { success: true, nome: nomeArquivo, caminho: destino };
        } catch (e) {
            console.error('Erro ao criar backup:', e);
            return { success: false, error: e.message };
        }
    }

    async restaurarBackup(backupPath) {
        try {
            if (!backupPath || !fs.existsSync(backupPath)) {
                return { success: false, error: 'Arquivo de backup não encontrado' };
            }

            // Fecha qualquer conexão própria antes de substituir o arquivo
            this.close();

            // Guarda uma cópia de segurança do banco atual, por precaução
            if (fs.existsSync(this.dbPath)) {
                const seguranca = this.dbPath + '.antes-restaurar.bak';
                try { fs.copyFileSync(this.dbPath, seguranca); } catch (_) { /* não crítico */ }
            }

            fs.copyFileSync(backupPath, this.dbPath);

            return { success: true };
        } catch (e) {
            console.error('Erro ao restaurar backup:', e);
            return { success: false, error: e.message };
        }
    }

    // ── EXPORTAR / IMPORTAR JSON ──
    async exportarJSON(destPasta) {
        let db;
        try {
            if (!destPasta) return { success: false, error: 'Nenhuma pasta selecionada' };

            db = await this._abrirConexao();

            const dados = {};
            let totalRegistros = 0;

            for (const tabela of TABELAS) {
                try {
                    const linhas = await this._all(db, `SELECT * FROM "${tabela}"`);
                    dados[tabela] = linhas;
                    totalRegistros += linhas.length;
                } catch (e) {
                    // Tabela pode não existir em bancos antigos - ignora e segue
                    dados[tabela] = [];
                }
            }

            const payload = {
                aplicacao: 'SysCadeiras',
                versao: require('../../../package.json').version,
                dataExportacao: new Date().toISOString(),
                totalRegistros,
                dados
            };

            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const nomeArquivo = `syscadeiras-export-${timestamp}.json`;
            const destino = path.join(destPasta, nomeArquivo);

            fs.writeFileSync(destino, JSON.stringify(payload, null, 2), 'utf-8');

            return { success: true, nome: nomeArquivo, caminho: destino, totalRegistros };
        } catch (e) {
            console.error('Erro ao exportar JSON:', e);
            return { success: false, error: e.message };
        } finally {
            if (db) db.close();
        }
    }

    async importarJSON(jsonPath, confirmado) {
        let db;
        try {
            if (!jsonPath || !fs.existsSync(jsonPath)) {
                return { success: false, error: 'Arquivo JSON não encontrado' };
            }

            const conteudo = fs.readFileSync(jsonPath, 'utf-8');
            const payload = JSON.parse(conteudo);

            if (!payload || !payload.dados) {
                return { success: false, error: 'Arquivo JSON inválido: estrutura de dados não encontrada' };
            }

            // Passo 1: apenas retorna metadata para confirmação do usuário
            if (!confirmado) {
                return {
                    success: true,
                    precisaConfirmacao: true,
                    metadata: {
                        aplicacao: payload.aplicacao || 'Desconhecida',
                        dataExportacao: payload.dataExportacao || null,
                        totalRegistros: payload.totalRegistros ?? Object.values(payload.dados).reduce((acc, arr) => acc + (arr?.length || 0), 0)
                    }
                };
            }

            // Passo 2: importação de fato, com confirmação do usuário
            db = await this._abrirConexao();
            await this._run(db, 'PRAGMA foreign_keys = OFF');

            let totalRegistros = 0;

            // Limpa e reinsere na ordem correta (respeita FKs ao reativar)
            for (const tabela of [...TABELAS].reverse()) {
                if (payload.dados[tabela]) {
                    await this._run(db, `DELETE FROM "${tabela}"`).catch(() => {});
                }
            }

            for (const tabela of TABELAS) {
                const linhas = payload.dados[tabela];
                if (!linhas || linhas.length === 0) continue;

                for (const linha of linhas) {
                    const colunas = Object.keys(linha);
                    const placeholders = colunas.map(() => '?').join(', ');
                    const valores = colunas.map(c => linha[c]);
                    const sql = `INSERT INTO "${tabela}" (${colunas.map(c => `"${c}"`).join(', ')}) VALUES (${placeholders})`;
                    await this._run(db, sql, valores);
                    totalRegistros++;
                }
            }

            await this._run(db, 'PRAGMA foreign_keys = ON');

            return { success: true, totalRegistros };
        } catch (e) {
            console.error('Erro ao importar JSON:', e);
            return { success: false, error: e.message };
        } finally {
            if (db) db.close();
        }
    }

    close() {
        if (this.db) {
            try { this.db.close(); } catch (_) { /* ignora */ }
            this.db = null;
        }
    }
}

module.exports = BackupManager;

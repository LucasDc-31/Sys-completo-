// ============================================
// authUtils.js — Autenticação local (SysCadeiras)
// ============================================
// Substitui a dependência do Supabase Auth: contas agora são criadas e
// autenticadas dentro do próprio sistema, com senha "hasheada" localmente
// (scrypt + salt, nativo do Node — não precisa instalar nada extra).
// ============================================

const crypto = require('crypto');

const KEYLEN = 64;

// Gera um hash no formato "salt:hash" (ambos em hexadecimal)
function hashPassword(senha) {
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.scryptSync(String(senha), salt, KEYLEN).toString('hex');
    return `${salt}:${hash}`;
}

// Verifica uma senha contra o hash salvo.
// Mantém compatibilidade com hashes antigos gerados via btoa() (versões
// anteriores) — sem isso, qualquer conta ainda nesse formato ficaria
// travada para sempre. Retorna um objeto para que quem chama saiba se o
// hash era legado e possa migrá-lo automaticamente para scrypt (ver
// migrarSenhaSeLegada em main.js, chamada logo após um login bem-sucedido).
function verifyPassword(senha, armazenado) {
    if (!armazenado) return { ok: false, legado: false };

    // Formato novo: "salt:hash"
    if (armazenado.includes(':')) {
        const [salt, hashSalvo] = armazenado.split(':');
        try {
            const hashTentativa = crypto.scryptSync(String(senha), salt, KEYLEN);
            const bufSalvo = Buffer.from(hashSalvo, 'hex');
            if (bufSalvo.length !== hashTentativa.length) return { ok: false, legado: false };
            return { ok: crypto.timingSafeEqual(hashTentativa, bufSalvo), legado: false };
        } catch (e) {
            return { ok: false, legado: false };
        }
    }

    // Formato legado (btoa) — aceito apenas para não travar contas antigas;
    // é migrado para scrypt automaticamente assim que o login for aceito.
    try {
        const ok = Buffer.from(String(senha)).toString('base64') === armazenado;
        return { ok, legado: true };
    } catch (e) {
        return { ok: false, legado: false };
    }
}

// Normaliza a lista de permissões (sempre array de strings; '*' = acesso total)
function normalizarPermissoes(permissoes) {
    if (!permissoes) return [];
    if (Array.isArray(permissoes)) return permissoes;
    try {
        const parsed = JSON.parse(permissoes);
        return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
        return [];
    }
}

module.exports = { hashPassword, verifyPassword, normalizarPermissoes };

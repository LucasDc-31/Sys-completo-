// ============================================
// main.js — SysCadeiras v2.0
// ============================================

const { app, BrowserWindow, ipcMain, dialog, shell, Notification, Menu } = require('electron');
const path = require('path');
const fs = require('fs');
const Database = require('./services/database');
const BackupManager = require('./services/backup');
const sync = require('./services/sync');
const config = require('./services/config');
const logger = require('./services/logger');
const { hashPassword, verifyPassword, normalizarPermissoes } = require('./services/auth');

let mainWindow, db, backupManager;
let backupAutomaticoTimer = null;

// Tabelas cujo `id` local não tem significado fora desta máquina (ver
// database.js/sync.js) — para elas, ao excluir, resolvemos o `uuid` do
// registro ANTES de apagar localmente (senão o uuid não existe mais para
// mandar o delete certo pro Supabase) e delegamos ao sync automaticamente,
// em vez de depender só do canal manual 'sync-deletar' chamado pela tela
// (que já não tem mais acesso ao uuid depois que a linha foi apagada).
const TABELAS_SINCRONIZADAS_LOCAL = new Set(['pecas', 'cores', 'funcionarios', 'producoes', 'movimentacoes', 'armações', 'estoquearmacoes']);
function tabelaSupabaseParaExclusao(tabelaLocalNorm, tabelaLocalOriginal) {
    if (tabelaLocalNorm === 'armações' || tabelaLocalNorm === 'armacoes') return 'Armacoes';
    return tabelaLocalOriginal;
}

// ============================================
// CONTROLE DE PERMISSÕES (processo principal)
// ============================================
// Antes, as permissões de cada conta só escondiam botões na tela (script.js).
// Isso é só estética: qualquer chamada dos canais genéricos de banco
// (database.run/get/all, expostos em preload.js) executava direto no SQLite,
// sem checar se a conta logada tinha autorização para aquela tabela. Ou seja,
// um usuário sem a permissão marcada ainda conseguia criar/editar/excluir
// dados daquela seção. Agora a sessão de quem está logado fica guardada aqui
// (nunca confiando no que o renderer diz que é — vem sempre do login) e toda
// escrita (INSERT/UPDATE/DELETE) é validada contra ela.
let sessaoAtual = null; // { id, role, permissoes } da conta logada no Desktop

// Tabela do banco -> permissão(ões) que autorizam ESCREVER nela.
// Quem tiver qualquer uma das permissões da lista pode gravar.
const TABELA_PARA_PERMISSAO = {
    pecas: ['modelos'],
    cores: ['cores'],
    funcionarios: ['funcionarios'],
    producoes: ['producao'],
    // Movimentacoes é gravada tanto pela seção Produção (baixa automática)
    // quanto pela seção Saídas (registro manual de saída) e pelo Backup
    // (restauração/limpeza) — qualquer uma dessas libera.
    movimentacoes: ['producao', 'saidas'],
    'armações': ['armacoes'],
    armacoes: ['armacoes'],
    estoquearmacoes: ['armacoes'],
    comprovantes: ['producao'],
};

// Extrai o nome da tabela alvo de um comando de escrita (INSERT/UPDATE/DELETE).
function extrairTabelaEscrita(sql) {
    const s = String(sql || '').trim();
    let m = s.match(/^insert\s+(?:or\s+\w+\s+)?into\s+["'`\[]?([a-zA-ZÀ-ÿ_]+)/i);
    if (m) return m[1];
    m = s.match(/^update\s+["'`\[]?([a-zA-ZÀ-ÿ_]+)/i);
    if (m) return m[1];
    m = s.match(/^delete\s+from\s+["'`\[]?([a-zA-ZÀ-ÿ_]+)/i);
    if (m) return m[1];
    return null;
}

// Retorna null se a sessão atual pode executar este SQL de escrita,
// ou uma mensagem de erro (string) se deve ser bloqueado.
function verificarPermissaoEscrita(sql) {
    if (!sessaoAtual) return 'Sessão expirada. Faça login novamente.';
    if (sessaoAtual.role === 'admin') return null;

    const permissoes = normalizarPermissoes(sessaoAtual.permissoes);
    if (permissoes.includes('*')) return null;

    const tabela = extrairTabelaEscrita(sql);
    if (!tabela) return null; // não é INSERT/UPDATE/DELETE (ex: PRAGMA) — deixa passar

    const tabelaNorm = tabela.toLowerCase();

    // Tabela de usuários: NUNCA liberada por SQL direto, só pelos canais
    // auth-* (que já exigem role === 'admin', ver abaixo).
    if (tabelaNorm === 'usuarios') {
        return 'Apenas administradores podem gerenciar usuários.';
    }

    // Tabela de conflitos de sincronização: auditoria interna, gravada
    // apenas pelo processo de sync (sync.js, com acesso direto ao banco,
    // fora deste canal). Ninguém deve conseguir inserir/alterar/apagar
    // "conflitos" fabricados pelo canal genérico de SQL do renderer.
    if (tabelaNorm === 'conflitos') {
        return 'Esta tabela é gerenciada internamente pelo sistema.';
    }

    // Permissão "backup" libera escrita em qualquer tabela de dados,
    // pois restaurar/importar/limpar tudo mexe em várias tabelas de uma vez.
    if (permissoes.includes('backup')) return null;

    const permitido = TABELA_PARA_PERMISSAO[tabelaNorm];
    if (!permitido) return null; // tabela não mapeada — não bloqueia
    if (permitido.some(p => permissoes.includes(p))) return null;

    return 'Sua conta não tem permissão para esta ação.';
}

// Retorna null se a sessão atual pode executar este SQL de LEITURA
// (database-get / database-all), ou uma mensagem de erro se deve ser
// bloqueado. Mais permissiva que a de escrita de propósito — hoje toda
// tela carrega listas completas (peças, cores, funcionários etc.) na
// inicialização, então bloquear por tabela quebraria telas legítimas.
// O que esta checagem fecha, sem mudar nenhum fluxo existente, é:
//   1) exigir sessão válida (igual já era exigido para escrita);
//   2) impedir que o canal genérico seja usado para ler a coluna de hash
//      de senha da tabela Usuarios — nenhuma tela hoje faz isso (elas usam
//      a whitelist de colunas em data-manager.js), então não há regressão;
//   3) impedir múltiplas instruções SQL empilhadas (";...") e comandos que
//      não são SELECT/PRAGMA, fechando uma via de abuso do canal cru.
function verificarPermissaoLeitura(sql) {
    if (!sessaoAtual) return 'Sessão expirada. Faça login novamente.';

    const s = String(sql || '').trim();

    // Bloqueia múltiplas instruções na mesma chamada (ex: "SELECT 1; DROP ...").
    // Um único ';' final (sem nada relevante depois) é tolerado.
    const semPontoVirgulaFinal = s.replace(/;\s*$/, '');
    if (semPontoVirgulaFinal.includes(';')) {
        return 'Consulta inválida.';
    }

    // O canal de leitura só deve ser usado para SELECT ou PRAGMA (introspecção
    // de schema, já usado internamente). Qualquer outra coisa é rejeitada aqui
    // como defesa extra — INSERT/UPDATE/DELETE já vão pelo canal de escrita.
    if (!/^select\s/i.test(s) && !/^pragma\s/i.test(s)) {
        return 'Consulta inválida.';
    }

    // Ninguém, admin ou não, precisa ler senha_hash pelo canal genérico —
    // login já é validado inteiramente no processo principal (auth-login).
    if (/\busuarios\b/i.test(s) && /senha_hash/i.test(s)) {
        return 'Consulta não permitida.';
    }

    // Conflitos de sincronização podem conter dados de negócio de outros
    // registros (JSON bruto) — só acessível pelo canal dedicado
    // 'diagnostico-conflitos', que já exige admin.
    if (/\bconflitos\b/i.test(s)) {
        return 'Consulta não permitida. Use o Diagnóstico do sistema (menu Sistema).';
    }

    return null;
}

// Tenta extrair o valor de uma coluna específica a partir do SQL + params,
// para INSERT ("INSERT INTO t (col1, col2, ...) VALUES (?, ?, ...)") e
// UPDATE ("UPDATE t SET col1=?, col2=? WHERE id=?"). Retorna undefined se
// não conseguir identificar com segurança (SQL fora do padrão esperado).
function extrairValorColuna(sql, params, coluna) {
    const s = String(sql || '');
    if (!Array.isArray(params)) return undefined;

    // INSERT INTO tabela (a, b, c) VALUES (?, ?, ?)
    let m = s.match(/insert\s+(?:or\s+\w+\s+)?into\s+["'`\[]?[a-zA-ZÀ-ÿ_]+["'`\]]?\s*\(([^)]+)\)\s*values\s*\(([^)]+)\)/i);
    if (m) {
        const colunas = m[1].split(',').map(c => c.trim().replace(/["'`\[\]]/g, ''));
        const idx = colunas.findIndex(c => c.toLowerCase() === coluna.toLowerCase());
        if (idx === -1) return undefined;
        return params[idx];
    }

    // UPDATE tabela SET a=?, b=?, c=? WHERE id=?
    m = s.match(/update\s+["'`\[]?[a-zA-ZÀ-ÿ_]+["'`\]]?\s+set\s+(.+?)\s+where\s/i);
    if (m) {
        const atribuicoes = m[1].split(',').map(a => a.trim());
        const idx = atribuicoes.findIndex(a => a.toLowerCase().startsWith(coluna.toLowerCase() + '='));
        if (idx === -1) return undefined;
        return params[idx];
    }

    return undefined;
}

// Data local do servidor no formato YYYY-MM-DD (mesmo formato usado pelo
// front em hojeISO()), para comparar com a data enviada pela tela.
function hojeISOLocal() {
    const d = new Date();
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
}

// Funcionários (contas não-admin vinculadas a um funcionário) só podem
// registrar/editar produção:
//   1) com data igual à data de hoje — não em dias passados ou futuros;
//   2) em nome de si mesmos — nunca em nome de outro funcionário.
// Ambas checadas aqui, no processo principal, porque os campos do
// formulário (data e funcionário selecionado) poderiam ser adulterados no
// navegador; esta é a validação que realmente vale. Administradores (e
// contas com permissão '*') não têm essa restrição.
function verificarRestricoesProducao(sql, params) {
    if (!sessaoAtual || sessaoAtual.role === 'admin') return null;
    const permissoes = normalizarPermissoes(sessaoAtual.permissoes);
    if (permissoes.includes('*')) return null;

    const tabela = (extrairTabelaEscrita(sql) || '').toLowerCase();
    const acao = classificarAcaoSql(sql);
    if (acao !== 'CRIAR' && acao !== 'EDITAR') return null; // exclusão segue as permissões normais

    if (tabela === 'producoes') {
        const dataEnviada = extrairValorColuna(sql, params, 'data');
        if (dataEnviada != null && String(dataEnviada) !== hojeISOLocal()) {
            return 'Você só pode registrar ou editar produção com a data de hoje.';
        }

        // Só pode lançar produção vinculada ao próprio cadastro de funcionário.
        if (sessaoAtual.funcionarioId != null) {
            const funcionarioEnviado = extrairValorColuna(sql, params, 'funcionarioId');
            if (funcionarioEnviado != null && Number(funcionarioEnviado) !== Number(sessaoAtual.funcionarioId)) {
                return 'Você só pode registrar produção em seu próprio nome.';
            }
        }
    }

    // A movimentação de estoque gerada por uma produção ("origem = 'Produção'")
    // também carrega o funcionarioId — mesma regra se aplica, para não deixar
    // uma brecha nessa segunda gravação da mesma operação.
    if (tabela === 'movimentacoes' && sessaoAtual.funcionarioId != null) {
        const origemEnviada = extrairValorColuna(sql, params, 'origem');
        if (origemEnviada === 'Produção') {
            const funcionarioEnviado = extrairValorColuna(sql, params, 'funcionarioId');
            if (funcionarioEnviado != null && Number(funcionarioEnviado) !== Number(sessaoAtual.funcionarioId)) {
                return 'Você só pode registrar produção em seu próprio nome.';
            }
        }
    }

    return null;
}

// Exige que a sessão atual seja de um administrador (gestão de usuários).
function exigirAdmin() {
    if (!sessaoAtual) return 'Sessão expirada. Faça login novamente.';
    if (sessaoAtual.role !== 'admin') return 'Apenas administradores podem gerenciar usuários.';
    return null;
}

// ============================================
// HISTÓRICO — auditoria de toda ação de escrita
// ============================================
// Toda vez que uma tela do sistema grava/edita/apaga algo (produção,
// funcionário, cor, saída, armação, etc.) o Desktop passa pelo mesmo canal
// genérico 'database-run'. Interceptamos aqui, no processo principal — nunca
// no renderer — para que o histórico não possa ser adulterado ou omitido
// pela tela. Cada linha fica com data/hora exatas e o usuário logado no
// momento (sempre a sessão validada no login, nunca o que o renderer manda).

function classificarAcaoSql(sql) {
    const s = String(sql || '').trim();
    if (/^insert\s/i.test(s)) return 'CRIAR';
    if (/^update\s/i.test(s)) return 'EDITAR';
    if (/^delete\s/i.test(s)) return 'EXCLUIR';
    return null;
}

// Tenta extrair o id do registro afetado a partir do SQL + params, para
// UPDATE/DELETE que seguem o padrão "WHERE id = ?" (usado em todo o app).
// Quando não dá pra identificar com segurança, retorna null (o histórico
// ainda é gravado, só sem o registroId/estado anterior).
function extrairIdAlvo(sql, params) {
    const s = String(sql || '');
    const m = s.match(/WHERE\s+.*?\bid\s*=\s*\?/i);
    if (!m || !Array.isArray(params) || params.length === 0) return null;
    // O "?" referente ao id é sempre o último parâmetro nas queries deste
    // app (padrão "SET campo=?, campo2=? WHERE id=?" / "DELETE ... WHERE id=?").
    const ultimo = params[params.length - 1];
    const n = parseInt(ultimo, 10);
    return Number.isFinite(n) ? n : null;
}

// Tabelas que não entram no histórico por serem ruído técnico (não são
// dados de negócio) ou já cobertas por outro fluxo mais específico.
const TABELAS_FORA_DO_HISTORICO = new Set(['historico']);

async function registrarHistoricoDeEscrita(sql, params, dadosAntesCapturados, resultDoRun) {
    try {
        const acao = classificarAcaoSql(sql);
        if (!acao) return;

        const tabela = extrairTabelaEscrita(sql);
        if (!tabela) return;
        const tabelaNorm = tabela.toLowerCase();
        if (TABELAS_FORA_DO_HISTORICO.has(tabelaNorm)) return;
        // A gestão de usuários já é registrada com descrição própria e mais
        // clara pelos canais auth-criar-usuario/editar/deletar — evita duplicar.
        if (tabelaNorm === 'usuarios') return;

        if (!db) return;

        // Em INSERT o id só existe depois de rodar (lastID); em UPDATE/DELETE
        // o id já vinha nos params originais (WHERE id = ?).
        const registroId = acao === 'CRIAR'
            ? (resultDoRun?.id ?? null)
            : extrairIdAlvo(sql, params);

        let dadosDepois = null;
        if (acao !== 'EXCLUIR' && registroId != null) {
            try { dadosDepois = await db.get(`SELECT * FROM "${tabela}" WHERE id = ?`, [registroId]); }
            catch (_) { dadosDepois = null; }
        }

        const usuarioNome = sessaoAtual?.nome || sessaoAtual?.email || 'Sistema';
        const rotuloAcao = { CRIAR: 'criou', EDITAR: 'editou', EXCLUIR: 'excluiu' }[acao];
        const descricao = `${usuarioNome} ${rotuloAcao} um registro em ${tabela}${registroId != null ? ' (#' + registroId + ')' : ''}`;

        await db.registrarHistorico({
            acao, tabela, registroId,
            usuarioId: sessaoAtual?.id ?? null,
            usuarioNome,
            descricao,
            dadosAntes: dadosAntesCapturados || null,
            dadosDepois,
        });
    } catch (e) {
        // Nunca deixa uma falha de auditoria travar a operação do usuário
        console.error('⚠️ registrarHistoricoDeEscrita:', e.message);
    }
}

// Captura erros não tratados para não travar o app em produção
process.on('uncaughtException', (err) => {
    console.error('❌ uncaughtException:', err);
});
process.on('unhandledRejection', (reason) => {
    console.error('❌ unhandledRejection:', reason);
});

// ── BACKUP AUTOMÁTICO ──
// Cria uma cópia do banco a cada 24h (e uma logo na abertura do app, se a
// última cópia salva tiver mais de 24h) em userData/backups-automaticos,
// mantendo só as últimas 14 — sem depender do usuário lembrar de fazer
// backup manual. Não substitui o backup manual (que continua deixando o
// usuário escolher a pasta) nem interfere nele.
const PASTA_BACKUP_AUTO_NOME = 'backups-automaticos';
const MAX_BACKUPS_AUTO = 14;
const INTERVALO_BACKUP_AUTO_MS = 24 * 60 * 60 * 1000;

function pastaBackupAutomatico() {
    return path.join(app.getPath('userData'), PASTA_BACKUP_AUTO_NOME);
}

async function executarBackupAutomaticoSeNecessario() {
    try {
        const pasta = pastaBackupAutomatico();
        fs.mkdirSync(pasta, { recursive: true });

        const existentes = fs.readdirSync(pasta)
            .filter(f => f.endsWith('.db'))
            .map(f => ({ nome: f, caminho: path.join(pasta, f), mtime: fs.statSync(path.join(pasta, f)).mtimeMs }))
            .sort((a, b) => b.mtime - a.mtime);

        const maisRecente = existentes[0];
        if (maisRecente && (Date.now() - maisRecente.mtime) < INTERVALO_BACKUP_AUTO_MS) {
            return; // já existe um backup automático recente o suficiente
        }

        if (!backupManager) { backupManager = new BackupManager(); await backupManager.init(); }
        const resultado = await backupManager.criarBackup(pasta);
        if (resultado.success) {
            console.log(`✅ Backup automático criado: ${resultado.nome}`);
        } else {
            console.warn('⚠️ Backup automático falhou:', resultado.error);
        }

        // Poda: mantém só os MAX_BACKUPS_AUTO mais recentes
        const atualizados = fs.readdirSync(pasta)
            .filter(f => f.endsWith('.db'))
            .map(f => ({ nome: f, caminho: path.join(pasta, f), mtime: fs.statSync(path.join(pasta, f)).mtimeMs }))
            .sort((a, b) => b.mtime - a.mtime);
        for (const antigo of atualizados.slice(MAX_BACKUPS_AUTO)) {
            try { fs.unlinkSync(antigo.caminho); } catch (_) { /* não crítico */ }
        }
    } catch (e) {
        console.error('❌ Falha no backup automático:', e.message);
    }
}

function iniciarAgendadorDeBackup() {
    if (backupAutomaticoTimer) clearInterval(backupAutomaticoTimer);
    // Roda uma vez pouco depois de abrir (dá tempo do banco/backupManager
    // estarem prontos) e depois a cada 6h verifica se já passou 24h desde
    // o último — assim funciona mesmo em máquinas que ficam poucas horas
    // ligadas por dia.
    setTimeout(() => executarBackupAutomaticoSeNecessario(), 15_000);
    backupAutomaticoTimer = setInterval(() => executarBackupAutomaticoSeNecessario(), 6 * 60 * 60 * 1000);
}

// ── ATUALIZAÇÃO AUTOMÁTICA ──
// Usa electron-updater apontando para os Releases do GitHub (já publicados
// automaticamente por .github/workflows/release.yml). Import fica dentro de
// try/catch e só é usado se o pacote estiver presente e o app estiver
// empacotado — nunca quebra `npm start`/dev, e nunca tenta atualizar a
// partir do código-fonte rodando direto (app.isPackaged === false).
//
// IMPORTANTE (ver docs/ATUALIZACAO-E-ASSINATURA.md): atualização automática
// silenciosa exige instaladores assinados (Windows) ou notarizados (macOS);
// sem isso, o SO pode bloquear a instalação da atualização baixada. Este
// código já fica pronto para quando a assinatura (item separado) estiver
// configurada — hoje, sem assinatura, o autoUpdater ainda funciona no
// Windows (NSIS não exige assinatura para autoupdate, só mostra o aviso de
// "editor desconhecido" na instalação), mas NÃO funciona no macOS sem
// notarização (a Apple bloqueia).
function verificarAtualizacoes(notificarSeNadaNovo) {
    if (!app.isPackaged) {
        if (notificarSeNadaNovo) console.log('ℹ️ Verificação de atualização ignorada (rodando a partir do código-fonte).');
        return;
    }
    try {
        const { autoUpdater } = require('electron-updater');
        autoUpdater.logger = { info: console.log, warn: console.warn, error: console.error, debug: () => {} };
        autoUpdater.autoDownload = true;

        autoUpdater.on('update-available', (info) => {
            console.log('⬆️ Atualização disponível:', info.version);
        });
        autoUpdater.on('update-not-available', () => {
            if (notificarSeNadaNovo && mainWindow) {
                dialog.showMessageBox(mainWindow, { type: 'info', title: 'SysCadeiras', message: 'Você já está usando a versão mais recente.' });
            }
        });
        autoUpdater.on('error', (err) => console.error('❌ Erro no autoUpdater:', err.message));
        autoUpdater.on('update-downloaded', (info) => {
            if (!mainWindow) return;
            dialog.showMessageBox(mainWindow, {
                type: 'question',
                buttons: ['Reiniciar agora', 'Mais tarde'],
                defaultId: 0,
                title: 'Atualização pronta',
                message: `A versão ${info.version} foi baixada. Reiniciar para instalar agora?`,
            }).then(r => { if (r.response === 0) autoUpdater.quitAndInstall(); });
        });

        autoUpdater.checkForUpdates().catch(e => console.warn('⚠️ Verificação de atualização falhou:', e.message));
    } catch (e) {
        // electron-updater não instalado (ex: build local sem essa
        // dependência) — não é um erro fatal, só desativa o recurso.
        console.warn('⚠️ Atualização automática indisponível:', e.message);
    }
}

// ── MENU (Diagnóstico / Backup / Atualização / Logs) ──
// Colocado no menu nativo em vez de em telas do renderer: evita mexer nas
// telas de negócio existentes só para expor estes recursos operacionais.
function criarMenu() {
    const template = [
        {
            label: 'Sistema',
            submenu: [
                {
                    label: 'Verificar atualizações...',
                    click: () => verificarAtualizacoes(true),
                },
                {
                    label: 'Fazer backup agora',
                    click: async () => {
                        if (!backupManager) { backupManager = new BackupManager(); await backupManager.init(); }
                        const r = await backupManager.criarBackup(pastaBackupAutomatico());
                        dialog.showMessageBox(mainWindow, {
                            type: r.success ? 'info' : 'error',
                            title: 'Backup',
                            message: r.success ? `Backup criado: ${r.nome}` : `Falha ao criar backup: ${r.error}`,
                        });
                    },
                },
                {
                    label: 'Abrir pasta de logs',
                    click: () => shell.openPath(logger.obterCaminhoPasta()),
                },
                {
                    label: 'Diagnóstico do sistema...',
                    click: async () => {
                        const info = await montarDiagnostico();
                        dialog.showMessageBox(mainWindow, {
                            type: 'info',
                            title: 'Diagnóstico — SysCadeiras',
                            message: 'Informações do sistema',
                            detail: Object.entries(info).map(([k, v]) => `${k}: ${v}`).join('\n'),
                        });
                    },
                },
                { type: 'separator' },
                { role: 'quit', label: 'Sair' },
            ],
        },
        {
            label: 'Editar',
            submenu: [{ role: 'undo' }, { role: 'redo' }, { type: 'separator' }, { role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { role: 'selectAll' }],
        },
        {
            label: 'Exibir',
            submenu: [{ role: 'reload' }, { role: 'toggleDevTools' }, { type: 'separator' }, { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' }, { type: 'separator' }, { role: 'togglefullscreen' }],
        },
    ];
    Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

async function montarDiagnostico() {
    let tamanhoBanco = 'desconhecido';
    try {
        if (db?.dbPath && fs.existsSync(db.dbPath)) {
            tamanhoBanco = `${(fs.statSync(db.dbPath).size / 1024 / 1024).toFixed(2)} MB`;
        }
    } catch (_) { /* ignora */ }

    let ultimoBackup = 'nenhum ainda';
    try {
        const pasta = pastaBackupAutomatico();
        if (fs.existsSync(pasta)) {
            const arquivos = fs.readdirSync(pasta).filter(f => f.endsWith('.db'));
            if (arquivos.length) {
                const mais = arquivos.map(f => ({ f, m: fs.statSync(path.join(pasta, f)).mtime })).sort((a, b) => b.m - a.m)[0];
                ultimoBackup = mais.m.toLocaleString('pt-BR');
            }
        }
    } catch (_) { /* ignora */ }

    let conflitosAbertos = 0;
    try {
        if (db) {
            const r = await db.get(`SELECT COUNT(*) as total FROM Conflitos WHERE resolvido = 0`);
            conflitosAbertos = r?.total ?? 0;
        }
    } catch (_) { /* tabela pode não existir em bancos muito antigos ainda não migrados */ }

    const cfg = config.getAll();
    return {
        'Versão do app': app.getVersion(),
        'Electron': process.versions.electron,
        'Node': process.versions.node,
        'Empresa (empresaId)': cfg.empresaId,
        'Máquina (deviceId)': cfg.deviceId,
        'Banco de dados': `${tamanhoBanco} (${db?.dbPath || '—'})`,
        'Sincronização': sync.getClient() ? 'ativa' : 'desativada',
        'Último backup automático': ultimoBackup,
        'Conflitos de sincronização em aberto': conflitosAbertos,
    };
}

async function initializeModules() {
    try {
        logger.iniciar();
        db = new Database();
        await db.init();
        backupManager = new BackupManager();
        await backupManager.init();
        // Inicializa o cliente Supabase cedo para que auth-login funcione
        // antes mesmo da janela estar pronta (o mainWindow pode ser null aqui,
        // mas getClient() já estará disponível para os handlers IPC).
        sync.init(null);
        console.log(`✅ Módulos inicializados (empresaId=${config.getEmpresaId()}, deviceId=${config.getDeviceId()})`);
    } catch (e) { console.error('❌ initializeModules:', e); }
}

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1400, height: 900,
        webPreferences: { nodeIntegration: false, contextIsolation: true, preload: path.join(__dirname, 'preload.js') },
        title: 'SysCadeiras - Controle de Produção & Estoque'
    });
    mainWindow.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
    // Abre DevTools apenas com flag explícita --dev (nunca em produção)
    if (process.argv.includes('--dev')) mainWindow.webContents.openDevTools();
    mainWindow.on('closed', () => {
        sessaoAtual = null;
        if (db) db.close();
        if (backupManager) backupManager.close();
        sync.pararRealtime();
    });
}

// ── DATABASE ──
ipcMain.handle('database-init', async () => {
    try { if (!db) { db = new Database(); await db.init(); } return { success: true }; }
    catch (e) { return { success: false, error: e.message }; }
});
ipcMain.handle('database-run', async (_, sql, params) => {
    const erroPermissao = verificarPermissaoEscrita(sql);
    if (erroPermissao) return { success: false, error: erroPermissao };
    const erroRestricaoProducao = verificarRestricoesProducao(sql, params);
    if (erroRestricaoProducao) return { success: false, error: erroRestricaoProducao };
    try {
        if (!db) { db = new Database(); await db.init(); }
        // Captura o estado "antes" primeiro (precisa do id, que já existe
        // antes do UPDATE/DELETE rodar); a gravação do histórico em si só
        // acontece depois que a operação foi confirmada com sucesso.
        const acao = classificarAcaoSql(sql);
        const tabela = extrairTabelaEscrita(sql);
        const registroId = extrairIdAlvo(sql, params);
        let dadosAntesCapturados = null;
        if (db && tabela && (acao === 'EDITAR' || acao === 'EXCLUIR') && registroId != null) {
            try { dadosAntesCapturados = await db.get(`SELECT * FROM "${tabela}" WHERE id = ?`, [registroId]); }
            catch (_) { dadosAntesCapturados = null; }
        }

        const result = await db.run(sql, params);

        // Registra no histórico em segundo plano — não atrasa a resposta ao renderer.
        registrarHistoricoDeEscrita(sql, params, dadosAntesCapturados, result).catch(() => {});

        // Exclusão em tabela sincronizada: espelha o delete no Supabase pelo
        // uuid (capturado em dadosAntesCapturados, ANTES de a linha sumir
        // localmente — depois disso não haveria mais como saber o uuid).
        // Isso corrige o delete cross-máquina, que antes dependia do `id`
        // local (sem significado fora desta instalação) enviado pela tela
        // pelo canal manual 'sync-deletar'. Não é destrutivo: se a tela
        // também chamar o canal manual com o id antigo, é só um no-op extra.
        if (acao === 'EXCLUIR' && tabela && TABELAS_SINCRONIZADAS_LOCAL.has(tabela.toLowerCase()) && dadosAntesCapturados?.uuid) {
            const tabelaSb = tabelaSupabaseParaExclusao(tabela.toLowerCase(), tabela);
            sync.deletar(tabelaSb, dadosAntesCapturados.uuid).catch(() => {});
        }

        return { success: true, result };
    }
    catch (e) { console.error('db-run:', sql, e); return { success: false, error: e.message }; }
});

// ── TRANSAÇÃO ATÔMICA (canal opt-in, não substitui database-run) ──
// Recebe uma lista de statements [{sql, params}] e executa todos dentro de
// uma única transação SQLite: ou aplica tudo, ou reverte tudo em caso de
// erro em qualquer statement no meio do caminho. Usado por operações
// compostas onde deixar o banco "pela metade" causaria inconsistência
// (ex: gravar a produção mas falhar na baixa de estoque).
//
// Reaproveita exatamente a mesma política de permissão, restrição de
// produção e auditoria de histórico que database-run já aplica — só que
// por statement, dentro da mesma transação.
ipcMain.handle('database-run-transacao', async (_, statements) => {
    if (!Array.isArray(statements) || statements.length === 0) {
        return { success: false, error: 'Lista de statements vazia ou inválida.' };
    }

    // Valida permissão de TODOS os statements antes de iniciar a transação
    // — evita abrir/reverter uma transação por causa de um statement que
    // já sabemos de antemão que será rejeitado.
    for (const stmt of statements) {
        const erroPermissao = verificarPermissaoEscrita(stmt.sql);
        if (erroPermissao) return { success: false, error: erroPermissao };
        const erroRestricaoProducao = verificarRestricoesProducao(stmt.sql, stmt.params);
        if (erroRestricaoProducao) return { success: false, error: erroRestricaoProducao };
    }

    try {
        if (!db) { db = new Database(); await db.init(); }

        // Mesma captura de "antes" que database-run faz, statement a
        // statement, na ordem em que serão executados.
        const dadosAntesPorStatement = [];
        for (const stmt of statements) {
            const acao = classificarAcaoSql(stmt.sql);
            const tabela = extrairTabelaEscrita(stmt.sql);
            const registroId = extrairIdAlvo(stmt.sql, stmt.params);
            let dadosAntesCapturados = null;
            if (tabela && (acao === 'EDITAR' || acao === 'EXCLUIR') && registroId != null) {
                try { dadosAntesCapturados = await db.get(`SELECT * FROM "${tabela}" WHERE id = ?`, [registroId]); }
                catch (_) { dadosAntesCapturados = null; }
            }
            dadosAntesPorStatement.push(dadosAntesCapturados);
        }

        const resultados = await db.runInTransaction(statements);

        // Histórico só é gravado depois que a transação inteira confirmou
        // com sucesso — se algo tivesse revertido, nada disso executa.
        statements.forEach((stmt, i) => {
            registrarHistoricoDeEscrita(stmt.sql, stmt.params, dadosAntesPorStatement[i], resultados[i]).catch(() => {});

            const acao = classificarAcaoSql(stmt.sql);
            const tabela = extrairTabelaEscrita(stmt.sql);
            if (acao === 'EXCLUIR' && tabela && TABELAS_SINCRONIZADAS_LOCAL.has(tabela.toLowerCase()) && dadosAntesPorStatement[i]?.uuid) {
                const tabelaSb = tabelaSupabaseParaExclusao(tabela.toLowerCase(), tabela);
                sync.deletar(tabelaSb, dadosAntesPorStatement[i].uuid).catch(() => {});
            }
        });

        return { success: true, result: resultados };
    }
    catch (e) {
        console.error('db-run-transacao:', e);
        return { success: false, error: e.message };
    }
});
ipcMain.handle('database-get', async (_, sql, params) => {
    const erroPermissao = verificarPermissaoLeitura(sql);
    if (erroPermissao) return { success: false, error: erroPermissao };
    try { if (!db) { db = new Database(); await db.init(); } return { success: true, result: await db.get(sql, params) }; }
    catch (e) { return { success: false, error: e.message }; }
});
ipcMain.handle('database-all', async (_, sql, params) => {
    const erroPermissao = verificarPermissaoLeitura(sql);
    if (erroPermissao) return { success: false, error: erroPermissao };
    try { if (!db) { db = new Database(); await db.init(); } return { success: true, result: await db.all(sql, params) }; }
    catch (e) { console.error('db-all:', sql, e); return { success: false, error: e.message }; }
});
ipcMain.handle('database-migrate', async () => {
    try { if (!db) { db = new Database(); await db.init(); } await db.createTables(); return { success: true }; }
    catch (e) { return { success: false, error: e.message }; }
});
ipcMain.handle('database-pesquisar-movimentacoes', async (_, filtros) => {
    try { if (!db) { db = new Database(); await db.init(); } return { success: true, result: await db.pesquisarMovimentacoes(filtros) }; }
    catch (e) { return { success: false, error: e.message }; }
});

// ── HISTÓRICO — leitura restrita a administradores ──
ipcMain.handle('historico-pesquisar', async (_, filtros) => {
    const erroAdmin = exigirAdmin();
    if (erroAdmin) return { success: false, error: erroAdmin };
    try { if (!db) { db = new Database(); await db.init(); } return { success: true, result: await db.pesquisarHistorico(filtros) }; }
    catch (e) { return { success: false, error: e.message }; }
});

// ── FUNCIONÁRIOS + LOGIN AUTOMÁTICO ──────────────────────────────────────
// Gera um e-mail padrão a partir do nome do funcionário (sem acento, sem
// espaço) + domínio interno fixo, garantindo que não colida com um e-mail
// já cadastrado (acrescenta um sufixo numérico quando necessário).
function slugEmailFuncionario(nome) {
    return String(nome || '')
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // remove acentos
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '.')
        .replace(/^\.+|\.+$/g, '') || 'funcionario';
}

async function gerarEmailDisponivel(nome) {
    const base = slugEmailFuncionario(nome);
    let candidato = `${base}@syscadeiras.local`;
    let contador = 1;
    while (await db.get(`SELECT id FROM Usuarios WHERE email = ?`, [candidato])) {
        contador += 1;
        candidato = `${base}${contador}@syscadeiras.local`;
    }
    return candidato;
}

// Gera uma senha inicial simples e legível para o funcionário poder digitar
// facilmente no primeiro acesso (ele pode trocá-la depois, se quiser, via
// edição de usuário pelo administrador).
function gerarSenhaInicial() {
    return Math.random().toString(36).slice(-8);
}

// Cria o Funcionário e, na mesma operação, a conta de login pessoal dele —
// vinculada por funcionarioId. Essa conta só enxerga a própria produção nos
// relatórios (ver filtro em script.js) e nunca a de outros funcionários,
// a menos que seja marcada como administrador (parâmetro comoAdmin).
ipcMain.handle('funcionario-criar-com-login', async (_, dados) => {
    const erroPermissao = verificarPermissaoEscrita('INSERT INTO Funcionarios');
    if (erroPermissao) return { success: false, error: erroPermissao };
    try {
        if (!db) { db = new Database(); await db.init(); }

        const nome = String(dados?.nome || '').trim();
        const cargo = String(dados?.cargo || '').trim();
        if (!nome || !cargo) return { success: false, error: 'Preencha todos os campos' };

        const comoAdmin = !!dados?.comoAdmin;
        // Por padrão a conta pessoal do funcionário nasce sem nenhuma
        // permissão marcada (nem 'producao', nem 'relatorios') — o admin
        // concede o que for necessário depois, editando o usuário, incluindo
        // escolher quais tipos de relatório ele pode ver (ver PREFIXO_PERMISSAO_RELATORIO
        // no script.js). Se a tela mandou permissões extras, respeita.
        const permissoesExtras = normalizarPermissoes(dados?.permissoes).filter(p => p !== '*');

        const funcResult = await db.run(`INSERT INTO Funcionarios (nome, cargo) VALUES (?, ?)`, [nome, cargo]);
        const funcionarioId = funcResult.id;

        const email = await gerarEmailDisponivel(nome);
        const senha = gerarSenhaInicial();
        const senhaHash = hashPassword(senha);
        const role = comoAdmin ? 'admin' : 'operador';
        const permissoes = comoAdmin ? ['*'] : permissoesExtras;

        const usuarioResult = await db.run(
            `INSERT INTO Usuarios (nome, email, senha_hash, role, ativo, permissoes, funcionarioId) VALUES (?,?,?,?,1,?,?)`,
            [nome, email, senhaHash, role, JSON.stringify(permissoes), funcionarioId]
        );

        await db.registrarHistorico({
            acao: 'CRIAR', tabela: 'Funcionarios', registroId: funcionarioId,
            usuarioId: sessaoAtual?.id ?? null, usuarioNome: sessaoAtual?.nome || 'Sistema',
            descricao: `${sessaoAtual?.nome || 'Sistema'} cadastrou o funcionário "${nome}" e criou o login pessoal dele (${email})`,
            dadosDepois: { id: funcionarioId, nome, cargo },
        });
        await db.registrarHistorico({
            acao: 'CRIAR', tabela: 'Usuarios', registroId: usuarioResult.id,
            usuarioId: sessaoAtual?.id ?? null, usuarioNome: sessaoAtual?.nome || 'Sistema',
            descricao: `Login criado automaticamente para o funcionário "${nome}" (${email})${comoAdmin ? ' — marcado como administrador' : ''}`,
            dadosDepois: { id: usuarioResult.id, nome, email, role, funcionarioId },
        });

        const novoFuncionario = { id: funcionarioId, nome, cargo };
        const novoUsuario = await db.get(`SELECT * FROM Usuarios WHERE id = ?`, [usuarioResult.id]);
        // Não aguarda a sincronização com o Supabase para responder à tela —
        // o cadastro local já está gravado e é o que garante a conta
        // funcionar no Desktop; espelhar é só para o Mobile enxergar o
        // mesmo login, e pode demorar (rede). Aguardar isso aqui era o que
        // fazia a tela de Usuários parecer travada/lenta após cadastrar
        // um funcionário — agora roda em segundo plano.
        if (novoUsuario) espelharUsuarioNoSupabase(novoUsuario).catch(() => {});

        return {
            success: true,
            funcionario: novoFuncionario,
            credenciais: { email, senha, role },
        };
    } catch (e) {
        console.error('funcionario-criar-com-login:', e);
        return { success: false, error: e.message };
    }
});

// Exclui o funcionário e, se existir, a conta de login pessoal vinculada.
ipcMain.handle('funcionario-excluir', async (_, id) => {
    const erroPermissao = verificarPermissaoEscrita('DELETE FROM Funcionarios');
    if (erroPermissao) return { success: false, error: erroPermissao };
    try {
        if (!db) { db = new Database(); await db.init(); }

        const funcionario = await db.get(`SELECT * FROM Funcionarios WHERE id = ?`, [id]);
        const usuarioVinculado = await db.get(`SELECT * FROM Usuarios WHERE funcionarioId = ?`, [id]);

        if (usuarioVinculado) {
            if (usuarioVinculado.role === 'admin') {
                const { total } = await db.get(`SELECT COUNT(*) as total FROM Usuarios WHERE role='admin' AND ativo=1`);
                if (total <= 1) {
                    return { success: false, error: 'Não é possível excluir: este funcionário é o único administrador do sistema.' };
                }
            }
            await db.run(`DELETE FROM Usuarios WHERE id = ?`, [usuarioVinculado.id]);
            // Não aguarda a exclusão espelhar no Supabase antes de responder
            // — o dado local já foi apagado, que é o que garante a exclusão
            // funcionar no Desktop; espelhar é só para o Mobile refletir o
            // mesmo estado, e não deve travar a resposta ao usuário.
            sync.deletar('Usuarios', usuarioVinculado.id).catch(() => {});
        }

        await db.run(`DELETE FROM Funcionarios WHERE id = ?`, [id]);

        await db.registrarHistorico({
            acao: 'EXCLUIR', tabela: 'Funcionarios', registroId: parseInt(id, 10),
            usuarioId: sessaoAtual?.id ?? null, usuarioNome: sessaoAtual?.nome || 'Sistema',
            descricao: `${sessaoAtual?.nome || 'Sistema'} excluiu o funcionário "${funcionario?.nome || id}"${usuarioVinculado ? ' e o login pessoal dele' : ''}`,
            dadosAntes: funcionario || null,
        });

        return { success: true };
    } catch (e) {
        console.error('funcionario-excluir:', e);
        return { success: false, error: e.message };
    }
});

// ── SYNC ──
ipcMain.handle('sync-espelhar', async (_, tabela, dados, conflito) => {
    try { await sync.espelhar(tabela, dados, conflito || 'id'); return { success: true }; }
    catch (e) { return { success: false, error: e.message }; }
});
ipcMain.handle('sync-deletar', async (_, tabela, id) => {
    try { await sync.deletar(tabela, id); return { success: true }; }
    catch (e) { return { success: false, error: e.message }; }
});

// ── BACKUP ──
ipcMain.handle('backup-criar', async (_, dest) => {
    try { if (!backupManager) { backupManager = new BackupManager(); await backupManager.init(); } return await backupManager.criarBackup(dest); }
    catch (e) { return { success: false, error: e.message }; }
});
ipcMain.handle('backup-restaurar', async (_, backupPath) => {
    try {
        // Validação extra além do diálogo nativo (que já restringe a
        // escolha do usuário): confere se o arquivo apontado é mesmo um
        // banco SQLite válido antes de sobrescrever o banco em uso — evita
        // corromper os dados atuais caso este canal seja invocado com um
        // caminho que não veio do diálogo (ex: chamada direta via
        // DevTools/renderer comprometido).
        if (!backupPath || typeof backupPath !== 'string') return { success: false, error: 'Caminho de backup inválido.' };
        if (!fs.existsSync(backupPath)) return { success: false, error: 'Arquivo de backup não encontrado.' };
        const cabecalho = Buffer.alloc(16);
        const fd = fs.openSync(backupPath, 'r');
        fs.readSync(fd, cabecalho, 0, 16, 0);
        fs.closeSync(fd);
        if (cabecalho.toString('utf8', 0, 15) !== 'SQLite format 3') {
            return { success: false, error: 'O arquivo selecionado não é um backup SQLite válido.' };
        }

        if (!backupManager) { backupManager = new BackupManager(); await backupManager.init(); }
        const r = await backupManager.restaurarBackup(backupPath);
        if (r.success) setTimeout(() => { app.relaunch(); app.exit(); }, 2000);
        return r;
    } catch (e) { return { success: false, error: e.message }; }
});
ipcMain.handle('backup-exportar-json', async (_, dest) => {
    try { if (!backupManager) { backupManager = new BackupManager(); await backupManager.init(); } return await backupManager.exportarJSON(dest); }
    catch (e) { return { success: false, error: e.message }; }
});
ipcMain.handle('backup-importar-json', async (_, jsonPath, confirmado) => {
    try { if (!backupManager) { backupManager = new BackupManager(); await backupManager.init(); } return await backupManager.importarJSON(jsonPath, confirmado); }
    catch (e) { return { success: false, error: e.message }; }
});

// ── ARQUIVOS ──
ipcMain.handle('selecionar-pasta', async () => {
    try {
        const r = await dialog.showOpenDialog(mainWindow, { properties: ['openDirectory'], title: 'Selecionar pasta para backup' });
        return r.canceled ? { success: false, canceled: true } : { success: true, path: r.filePaths[0] };
    } catch (e) { return { success: false, error: e.message }; }
});
ipcMain.handle('selecionar-arquivo', async (_, filtros) => {
    try {
        const opts = { properties: ['openFile'], title: 'Selecionar arquivo' };
        if (filtros?.length) opts.filters = filtros;
        const r = await dialog.showOpenDialog(mainWindow, opts);
        return r.canceled ? { success: false, canceled: true } : { success: true, path: r.filePaths[0] };
    } catch (e) { return { success: false, error: e.message }; }
});
// RESTRIÇÃO DE FILESYSTEM: o caminho de destino sempre vem de um diálogo
// nativo do SO (dialog.showSaveDialog) — o usuário escolhe onde salvar,
// nunca uma string arbitrária vinda do renderer. Ainda assim, validamos o
// conteúdo para não permitir gravações grosseiras (ex: um valor não-string
// gigante) e não abrimos automaticamente o Explorer/Finder em local que o
// usuário não escolheu.
const TAMANHO_MAXIMO_EXPORT = 50 * 1024 * 1024; // 50MB — generoso para CSV/texto de relatórios
ipcMain.handle('save-document', async (_, content, defaultName, fileType) => {
    try {
        if (typeof content !== 'string') return { success: false, error: 'Conteúdo inválido.' };
        if (Buffer.byteLength(content, 'utf8') > TAMANHO_MAXIMO_EXPORT) {
            return { success: false, error: 'Arquivo grande demais para exportar.' };
        }
        const ext = fileType === 'csv' ? ['csv'] : ['txt'];
        const r = await dialog.showSaveDialog(mainWindow, { defaultPath: defaultName, filters: [{ name: fileType === 'csv' ? 'CSV' : 'Text', extensions: ext }, { name: 'All Files', extensions: ['*'] }] });
        if (r.canceled) return { success: false, canceled: true };
        fs.writeFileSync(r.filePath, content, 'utf8');
        const open = await dialog.showMessageBox(mainWindow, { type: 'question', buttons: ['Sim', 'Não'], defaultId: 0, title: 'Arquivo Salvo', message: `Salvo!\n${r.filePath}\n\nDeseja abrir?` });
        if (open.response === 0) shell.openPath(r.filePath);
        return { success: true, path: r.filePath };
    } catch (e) { return { success: false, error: e.message }; }
});
// REMOVIDO: 'save-multiple-files', 'check-directory' e 'list-files' foram
// removidos por não serem usados por nenhuma tela do sistema (nenhum
// arquivo em src/renderer/js chama fileSystem.saveMultipleFiles/
// checkDirectory/listFiles) e, por outro lado, exporem primitivas
// perigosas ao processo renderer: criação de diretório em qualquer caminho
// arbitrário do disco (`check-directory`) e listagem recursiva de
// qualquer pasta (`list-files`), sem nenhuma validação de escopo. Manter
// código morto que só serve como superfície de ataque não tem benefício —
// se alguma tela precisar disso no futuro, deve ser reintroduzido já
// restrito a uma pasta base conhecida (ex: dentro de app.getPath('userData')).

// ── AUTH — contas criadas e autenticadas a partir do Desktop ─────────────────
// O SQLite local deste computador continua sendo a fonte de verdade: é aqui
// que o admin cria/edita/exclui contas, e é daqui que o próprio Desktop faz
// login (auth-login lê sempre do SQLite local, nunca da rede).
//
// Para o app Mobile conseguir logar com as MESMAS contas, a tabela Usuarios
// (incluindo o hash scrypt da senha — nunca a senha em texto puro) é
// espelhada no Supabase toda vez que uma conta é criada, editada ou
// desativada/excluída aqui no Desktop. O Mobile só LÊ essa tabela para
// validar login; ele nunca cria/edita usuários (isso continua exclusivo
// do Desktop, como pedido).
async function espelharUsuarioNoSupabase(usuario) {
    try {
        await sync.espelhar('Usuarios', {
            id: usuario.id,
            nome: usuario.nome,
            email: usuario.email,
            senha_hash: usuario.senha_hash,
            role: usuario.role,
            ativo: usuario.ativo,
            permissoes: typeof usuario.permissoes === 'string' ? usuario.permissoes : JSON.stringify(usuario.permissoes || []),
        }, 'id');
    } catch (e) {
        console.warn('⚠️ Não foi possível espelhar usuário no Supabase (login mobile pode ficar desatualizado):', e.message);
    }
}

function mapUsuarioParaCliente(u) {
    if (!u) return u;
    const { senha_hash, ...resto } = u;
    return { ...resto, permissoes: normalizarPermissoes(u.permissoes) };
}

ipcMain.handle('auth-login', async (_, email, senha) => {
    try {
        if (!email || !senha) return { success: false, error: 'Informe e-mail e senha.' };
        if (!db) { db = new Database(); await db.init(); }

        const emailNorm = email.trim().toLowerCase();
        const usuario = await db.get(`SELECT * FROM Usuarios WHERE email = ?`, [emailNorm]);

        const verificacao = usuario ? verifyPassword(senha, usuario.senha_hash) : { ok: false, legado: false };
        if (!usuario || !verificacao.ok) {
            return { success: false, error: 'E-mail ou senha incorretos' };
        }
        if (!usuario.ativo) {
            return { success: false, error: 'Este usuário está bloqueado. Contate um administrador.' };
        }

        // Conta ainda com hash legado (base64) — migra para scrypt agora
        // que sabemos que a senha está correta, de forma transparente para
        // quem está logando (não muda nada do fluxo, só troca o que fica
        // salvo no banco). Falha aqui não deve impedir o login.
        if (verificacao.legado) {
            try {
                const novoHash = hashPassword(senha);
                await db.run('UPDATE Usuarios SET senha_hash = ? WHERE id = ?', [novoHash, usuario.id]);
                console.log(`🔐 Hash de senha migrado para scrypt (usuário: ${usuario.email})`);
            } catch (e) {
                console.error('Falha ao migrar hash legado de senha:', e);
            }
        }

        const usuarioCliente = mapUsuarioParaCliente(usuario);
        // Guarda a sessão no processo principal — é essa cópia (vinda direto
        // do banco, não do que o renderer manda de volta) que passa a valer
        // para autorizar/bloquear as escritas feitas por esta conta e para
        // identificar quem fez cada ação no histórico.
        sessaoAtual = {
            id: usuarioCliente.id,
            nome: usuarioCliente.nome,
            email: usuarioCliente.email,
            role: usuarioCliente.role,
            permissoes: usuarioCliente.permissoes,
            funcionarioId: usuarioCliente.funcionarioId ?? null,
        };

        return { success: true, user: usuarioCliente };
    } catch (e) {
        console.error('auth-login erro:', e);
        return { success: false, error: 'Erro ao autenticar: ' + e.message };
    }
});

// Encerra a sessão guardada no processo principal (chamado no logout do app).
ipcMain.handle('auth-logout', async () => {
    sessaoAtual = null;
    return { success: true };
});

// Listar usuários: sempre lê do SQLite local (fonte da verdade do login)
ipcMain.handle('auth-listar-usuarios', async () => {
    const erroAdmin = exigirAdmin();
    if (erroAdmin) return { success: false, error: erroAdmin };
    try {
        if (!db) { db = new Database(); await db.init(); }
        const usuarios = await db.all(`SELECT id, nome, email, role, ativo, permissoes, funcionarioId FROM Usuarios ORDER BY nome`);
        return { success: true, result: usuarios.map(mapUsuarioParaCliente) };
    } catch (e) { return { success: false, error: e.message }; }
});

// Senha fixa de confirmação exigida para criar uma nova conta no sistema.
const SENHA_CONFIRMACAO_ADMIN = 'admadd';

// Criar usuário: conta e senha criadas direto no sistema, sem depender do Supabase
ipcMain.handle('auth-criar-usuario', async (_, dados) => {
    const erroAdmin = exigirAdmin();
    if (erroAdmin) return { success: false, error: erroAdmin };
    try {
        if (dados.confirmacaoAdmin !== SENHA_CONFIRMACAO_ADMIN) {
            return { success: false, error: 'Senha de confirmação do administrador incorreta.' };
        }

        const emailNorm = dados.email.trim().toLowerCase();
        const nomeNorm  = dados.nome.trim();
        const role      = dados.role || 'operador';
        const permissoes = role === 'admin' ? ['*'] : normalizarPermissoes(dados.permissoes);

        if (!dados.senha || dados.senha.length < 4) {
            return { success: false, error: 'Defina uma senha com pelo menos 4 caracteres.' };
        }

        if (!db) { db = new Database(); await db.init(); }

        const existente = await db.get(`SELECT id FROM Usuarios WHERE email = ?`, [emailNorm]);
        if (existente) return { success: false, error: 'Já existe uma conta com este e-mail.' };

        const senhaHash = hashPassword(dados.senha);
        const r = await db.run(
            `INSERT INTO Usuarios (nome, email, senha_hash, role, ativo, permissoes) VALUES (?,?,?,?,1,?)`,
            [nomeNorm, emailNorm, senhaHash, role, JSON.stringify(permissoes)]
        ).catch(e => ({ error: e }));
        if (r && r.error) return { success: false, error: r.error.message };

        // Espelha a nova conta no Supabase para que o Mobile já possa logar
        // com ela — em segundo plano, sem atrasar a resposta ao Desktop
        // (o cadastro local já está gravado e é o que garante a conta
        // funcionar aqui; o espelhamento é só para o Mobile enxergar o mesmo login).
        const novoUsuario = await db.get(`SELECT * FROM Usuarios WHERE email = ?`, [emailNorm]);
        if (novoUsuario) espelharUsuarioNoSupabase(novoUsuario).catch(() => {});

        return { success: true };
    } catch (e) {
        return { success: false, error: e.message };
    }
});

// Editar usuário: nome, e-mail, perfil, permissões e (opcionalmente) senha
ipcMain.handle('auth-editar-usuario', async (_, id, dados) => {
    const erroAdmin = exigirAdmin();
    if (erroAdmin) return { success: false, error: erroAdmin };
    try {
        const nomeNorm  = dados.nome.trim();
        const emailNorm = dados.email.trim().toLowerCase();
        const role      = dados.role || 'operador';
        const permissoes = role === 'admin' ? ['*'] : normalizarPermissoes(dados.permissoes);

        if (!db) { db = new Database(); await db.init(); }

        await db.run(
            `UPDATE Usuarios SET nome=?, email=?, role=?, ativo=?, permissoes=? WHERE id=?`,
            [nomeNorm, emailNorm, role, dados.ativo ? 1 : 0, JSON.stringify(permissoes), id]
        );

        if (dados.senha) {
            if (dados.senha.length < 4) return { success: false, error: 'A senha deve ter pelo menos 4 caracteres.' };
            const senhaHash = hashPassword(dados.senha);
            await db.run(`UPDATE Usuarios SET senha_hash=? WHERE id=?`, [senhaHash, id]);
        }

        // Espelha a conta atualizada (dados + senha, se trocada) no Supabase
        // — em segundo plano, sem atrasar a resposta ao Desktop (é o mesmo
        // padrão dos outros pontos de espelhamento: o dado local já foi
        // gravado, que é o que garante a edição funcionar aqui).
        const usuarioAtualizado = await db.get(`SELECT * FROM Usuarios WHERE id = ?`, [id]);
        if (usuarioAtualizado) espelharUsuarioNoSupabase(usuarioAtualizado).catch(() => {});

        return { success: true };
    } catch (e) { return { success: false, error: e.message }; }
});

// Deletar usuário
ipcMain.handle('auth-deletar-usuario', async (_, id) => {
    const erroAdmin = exigirAdmin();
    if (erroAdmin) return { success: false, error: erroAdmin };
    try {
        if (!db) { db = new Database(); await db.init(); }

        const alvo = await db.get(`SELECT role, email, uuid FROM Usuarios WHERE id = ?`, [id]);
        if (alvo?.role === 'admin') {
            const { total } = await db.get(`SELECT COUNT(*) as total FROM Usuarios WHERE role='admin' AND ativo=1`);
            if (total <= 1) return { success: false, error: 'Não é possível remover o único administrador' };
        }

        await db.run(`DELETE FROM Usuarios WHERE id=?`, [id]);

        // Remove também do Supabase para que o Mobile não deixe logar com a
        // conta excluída — em segundo plano, sem atrasar a resposta ao
        // Desktop (a exclusão local já aconteceu e é o que importa aqui).
        // Usa o uuid capturado ANTES do delete local (chave estável entre
        // máquinas); cai para o id legado se, por algum motivo, não houver uuid.
        sync.deletar('Usuarios', alvo?.uuid || id).catch(e => console.warn('⚠️ Não foi possível remover usuário do Supabase:', e.message));

        return { success: true };
    } catch (e) { return { success: false, error: e.message }; }
});


// Bloquear/desbloquear usuário — atalho rápido pela lista (equivalente a
// editar e desmarcar "Usuário ativo", mas sem precisar abrir o modal).
// Um usuário bloqueado (ativo=0) não consegue mais fazer login nem no
// Desktop nem no Mobile (auth-login e a validação do Mobile já checam
// usuario.ativo), mas seu cadastro e histórico de produção permanecem
// intactos — só o acesso é suspenso.
ipcMain.handle('auth-alternar-bloqueio', async (_, id, bloquear) => {
    const erroAdmin = exigirAdmin();
    if (erroAdmin) return { success: false, error: erroAdmin };
    try {
        if (!db) { db = new Database(); await db.init(); }

        const alvo = await db.get(`SELECT * FROM Usuarios WHERE id = ?`, [id]);
        if (!alvo) return { success: false, error: 'Usuário não encontrado.' };

        if (bloquear) {
            if (sessaoAtual && alvo.id === sessaoAtual.id) {
                return { success: false, error: 'Você não pode bloquear a própria conta.' };
            }
            if (alvo.role === 'admin') {
                const { total } = await db.get(`SELECT COUNT(*) as total FROM Usuarios WHERE role='admin' AND ativo=1`);
                if (total <= 1) return { success: false, error: 'Não é possível bloquear o único administrador ativo.' };
            }
        }

        const novoAtivo = bloquear ? 0 : 1;
        await db.run(`UPDATE Usuarios SET ativo=? WHERE id=?`, [novoAtivo, id]);

        await db.registrarHistorico({
            acao: 'EDITAR', tabela: 'Usuarios', registroId: parseInt(id, 10),
            usuarioId: sessaoAtual?.id ?? null, usuarioNome: sessaoAtual?.nome || 'Sistema',
            descricao: `${sessaoAtual?.nome || 'Sistema'} ${bloquear ? 'bloqueou' : 'desbloqueou'} o acesso do usuário "${alvo.nome}" (${alvo.email})`,
            dadosAntes: { ativo: alvo.ativo },
            dadosDepois: { ativo: novoAtivo },
        });

        // Espelha no Supabase para que o bloqueio valha também no Mobile —
        // em segundo plano, sem atrasar a resposta ao Desktop (o bloqueio
        // local já foi aplicado e é o que garante o efeito imediato aqui).
        const usuarioAtualizado = await db.get(`SELECT * FROM Usuarios WHERE id = ?`, [id]);
        if (usuarioAtualizado) espelharUsuarioNoSupabase(usuarioAtualizado).catch(() => {});

        return { success: true, ativo: novoAtivo };
    } catch (e) { return { success: false, error: e.message }; }
});

// ── CONFIG (empresaId/deviceId — multiempresa/multimáquina) ──
ipcMain.handle('config-obter', async () => {
    try { return { success: true, result: config.getAll() }; }
    catch (e) { return { success: false, error: e.message }; }
});
ipcMain.handle('config-definir-empresa', async (_, empresaId, empresaNome) => {
    const erroAdmin = exigirAdmin();
    if (erroAdmin) return { success: false, error: erroAdmin };
    try {
        const atualizado = config.definirEmpresa(empresaId, empresaNome);
        await db?.registrarHistorico({
            acao: 'EDITAR', tabela: 'Config', registroId: null,
            usuarioId: sessaoAtual?.id ?? null, usuarioNome: sessaoAtual?.nome || 'Sistema',
            descricao: `${sessaoAtual?.nome || 'Sistema'} definiu a empresa desta instalação para "${empresaId}"${empresaNome ? ' (' + empresaNome + ')' : ''}. Reinicie o app para a sincronização usar o novo escopo.`,
        });
        return { success: true, result: atualizado };
    } catch (e) { return { success: false, error: e.message }; }
});

// ── DIAGNÓSTICO/MONITORAMENTO ──
ipcMain.handle('diagnostico-info', async () => {
    try { return { success: true, result: await montarDiagnostico() }; }
    catch (e) { return { success: false, error: e.message }; }
});
ipcMain.handle('diagnostico-conflitos', async () => {
    const erroAdmin = exigirAdmin();
    if (erroAdmin) return { success: false, error: erroAdmin };
    try {
        if (!db) { db = new Database(); await db.init(); }
        const conflitos = await db.all(`SELECT * FROM Conflitos ORDER BY created_at DESC LIMIT 200`);
        return { success: true, result: conflitos };
    } catch (e) { return { success: false, error: e.message }; }
});

ipcMain.on('show-notification', (_, { title, body }) => {
    try { new Notification({ title: title || 'SysCadeiras', body: body || '' }).show(); } catch (e) {}
});

// ── BOOT ──
app.whenReady().then(async () => {
    await initializeModules();
    createWindow();
    criarMenu();
    iniciarAgendadorDeBackup();
    verificarAtualizacoes(false);

    // sync.init() já foi chamado em initializeModules() para disponibilizar
    // getClient() nos handlers IPC. Aqui apenas passamos o mainWindow e
    // iniciamos realtime + sincronização inicial.
    sync.setMainWindow(mainWindow);
    const syncAtivo = !!sync.getClient();
    if (syncAtivo) {
        await sync.sincronizarInicial(db);
        sync.setDb(db);
        sync.iniciarRealtime();

        // Garante que todas as contas já existentes no SQLite local (ex: o
        // admin padrão criado no primeiro boot) fiquem disponíveis para
        // login no Mobile, mesmo que tenham sido criadas antes desta versão.
        try {
            const todosUsuarios = await db.all(`SELECT * FROM Usuarios`);
            for (const u of todosUsuarios) await espelharUsuarioNoSupabase(u);
            if (todosUsuarios.length) console.log(`✅ ${todosUsuarios.length} usuário(s) espelhado(s) no Supabase para login no Mobile`);
        } catch (e) {
            console.warn('⚠️ Falha ao espelhar usuários existentes no Supabase:', e.message);
        }

        console.log('✅ Supabase Sync ativo');
    }
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        if (backupAutomaticoTimer) clearInterval(backupAutomaticoTimer);
        if (db) db.close();
        if (backupManager) backupManager.close();
        sync.pararRealtime();
        app.quit();
    }
});
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });

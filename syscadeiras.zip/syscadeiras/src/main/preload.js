// ============================================
// preload.js — SysCadeiras v2.0
// ============================================

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {

    database: {
        init:    ()            => ipcRenderer.invoke('database-init'),
        run:     (sql, params) => ipcRenderer.invoke('database-run', sql, params),
        get:     (sql, params) => ipcRenderer.invoke('database-get', sql, params),
        all:     (sql, params) => ipcRenderer.invoke('database-all', sql, params),
        // Executa uma lista de statements [{sql, params}] como transação
        // atômica (tudo ou nada). Opt-in: não afeta quem continua usando run().
        runTransacao: (statements) => ipcRenderer.invoke('database-run-transacao', statements),
        migrate: ()            => ipcRenderer.invoke('database-migrate'),
        invoke:  (method, params) => ipcRenderer.invoke(`database-${method}`, params),
    },

    // 'saveMultipleFiles' / 'checkDirectory' / 'listFiles' foram removidos
    // (código morto + superfície de ataque desnecessária — ver main.js).
    fileSystem: {
        saveDocument: (content, name, type) => ipcRenderer.invoke('save-document', content, name, type),
    },

    // Config: empresaId/deviceId desta instalação (ver services/config.js) —
    // usados para diagnosticar/configurar sincronização multiempresa.
    config: {
        obter:           ()               => ipcRenderer.invoke('config-obter'),
        definirEmpresa:  (empresaId, nome) => ipcRenderer.invoke('config-definir-empresa', empresaId, nome),
    },

    // Diagnóstico/monitoramento (ver services/logger.js e main.js).
    diagnostico: {
        obterInfo:      () => ipcRenderer.invoke('diagnostico-info'),
        listarConflitos: () => ipcRenderer.invoke('diagnostico-conflitos'),
    },

    backup: {
        criar:             (dest)    => ipcRenderer.invoke('backup-criar', dest),
        restaurar:         (p)       => ipcRenderer.invoke('backup-restaurar', p),
        exportarJSON:      (dest)    => ipcRenderer.invoke('backup-exportar-json', dest),
        importarJSON:      (p, conf) => ipcRenderer.invoke('backup-importar-json', p, conf),
        selecionarPasta:   ()        => ipcRenderer.invoke('selecionar-pasta'),
        selecionarArquivo: (filtros) => ipcRenderer.invoke('selecionar-arquivo', filtros),
    },

    sync: {
        espelhar: (tabela, dados, conflito) => ipcRenderer.invoke('sync-espelhar', tabela, dados, conflito),
        deletar:  (tabela, id)             => ipcRenderer.invoke('sync-deletar', tabela, id),

        // CORREÇÃO: cada on*() remove listeners anteriores do mesmo canal antes
        // de registrar o novo. Isso evita acúmulo de handlers quando o renderer
        // é reinicializado (ex: location.reload dentro do Electron) sem destruir
        // o processo — situação que causava o onRecarregar disparar N vezes.
        onNovaProducao: (cb) => {
            ipcRenderer.removeAllListeners('sync:nova-producao');
            ipcRenderer.on('sync:nova-producao', (_, d) => cb(d));
        },
        onNovaMovimentacao: (cb) => {
            ipcRenderer.removeAllListeners('sync:nova-movimentacao');
            ipcRenderer.on('sync:nova-movimentacao', (_, d) => cb(d));
        },
        onNovaArmacao: (cb) => {
            ipcRenderer.removeAllListeners('sync:nova-armacao');
            ipcRenderer.on('sync:nova-armacao', (_, d) => cb(d));
        },
        onCadastro: (cb) => {
            ipcRenderer.removeAllListeners('sync:cadastro');
            ipcRenderer.on('sync:cadastro', (_, d) => cb(d));
        },
        onStatus: (cb) => {
            ipcRenderer.removeAllListeners('sync:status');
            ipcRenderer.on('sync:status', (_, d) => cb(d));
        },
        onRecarregar: (cb) => {
            ipcRenderer.removeAllListeners('sync:recarregar');
            ipcRenderer.on('sync:recarregar', (_, d) => cb(d));
        },

        removerListeners: () => {
            ['sync:nova-producao', 'sync:nova-movimentacao', 'sync:nova-armacao',
             'sync:cadastro', 'sync:status', 'sync:recarregar']
                .forEach(c => ipcRenderer.removeAllListeners(c));
        },
    },

    auth: {
        login:           (email, senha) => ipcRenderer.invoke('auth-login', email, senha),
        logout:          ()             => ipcRenderer.invoke('auth-logout'),
        listarUsuarios:  ()             => ipcRenderer.invoke('auth-listar-usuarios'),
        criarUsuario:    (dados)        => ipcRenderer.invoke('auth-criar-usuario', dados),
        editarUsuario:   (id, dados)    => ipcRenderer.invoke('auth-editar-usuario', id, dados),
        deletarUsuario:  (id)           => ipcRenderer.invoke('auth-deletar-usuario', id),
        alternarBloqueio:(id, bloquear) => ipcRenderer.invoke('auth-alternar-bloqueio', id, bloquear),
    },

    funcionarios: {
        criarComLogin: (dados) => ipcRenderer.invoke('funcionario-criar-com-login', dados),
        excluir:       (id)    => ipcRenderer.invoke('funcionario-excluir', id),
    },

    historico: {
        pesquisar: (filtros) => ipcRenderer.invoke('historico-pesquisar', filtros),
    },

    showNotification: (title, body) => ipcRenderer.send('show-notification', { title, body }),
});

contextBridge.exposeInMainWorld('appInfo', {
    version: '2.0.0',
    name: 'SysCadeiras',
    isElectron: true,
});

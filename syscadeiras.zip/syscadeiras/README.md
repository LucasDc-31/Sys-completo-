# SysCadeiras

Sistema desktop (Electron) de controle de produção, estoque, folha de pagamento e
ranking de funcionários, com sincronização opcional via Supabase.

## Estrutura do projeto

```
syscadeiras/
├── src/
│   ├── main/                      # Processo principal do Electron (Node.js)
│   │   ├── main.js                # Ciclo de vida do app, janelas, IPC
│   │   ├── preload.js             # Ponte segura (contextBridge) main ↔ renderer
│   │   └── services/              # Regras de negócio/infra usadas pelo main
│   │       ├── database.js        # Acesso ao SQLite (era db.js)
│   │       ├── auth.js            # Hash/verificação de senha, permissões (era authUtils.js)
│   │       ├── backup.js          # Backup/restore do banco (era backupManager.js)
│   │       ├── sync.js            # Sincronização com Supabase (era supabaseSync.js)
│   │       └── migrate.js         # Script de migração do schema (era migrate.js)
│   └── renderer/                  # Interface (executa na janela do Electron)
│       ├── index.html
│       ├── css/
│       │   └── style.css
│       └── js/                    # script.js original, dividido por responsabilidade
│           ├── ui-shim.js         # Compatibilidade topbar/sidebar (era <script> inline no HTML)
│           ├── state.js           # Estado global e sistema de permissões
│           ├── login-phrases.js   # Frase do dia (tela de login)
│           ├── form-manager.js    # Abertura/fechamento/validação de formulários
│           ├── data-manager.js    # CRUD central em memória/IPC
│           ├── ui-manager.js      # Telas, listas e tabelas
│           ├── edit.js            # Edição de registros
│           ├── delete.js          # Exclusão e "apagar todos os dados"
│           ├── app-init.js        # Bootstrap da aplicação
│           ├── helpers.js         # Utilitários gerais
│           ├── search.js          # Pesquisa/filtros
│           ├── reports.js         # Relatórios gerais
│           ├── reports-armacoes.js# Relatório de armações
│           ├── export.js          # Seleção e exportação (PDF/Excel)
│           ├── payroll.js         # Folha de pagamento
│           ├── backup-ui.js       # Backup (lado da interface)
│           ├── dashboard.js       # Dashboard e gráficos (Chart.js)
│           ├── receipts-and-stock.js # Comprovantes e alerta de estoque baixo
│           ├── sync-ui.js         # Sincronização (lado da interface)
│           ├── auth-ui.js         # Usuários, permissões, bloqueio de conta
│           └── history.js         # Histórico de ações (admin)
├── build/                         # Ícones/recursos do electron-builder (.ico/.icns/.png)
├── docs/                          # Documentação adicional
├── package.json
├── .gitignore
├── .eslintrc.json
├── .prettierrc.json
└── README.md
```

## O que mudou em relação à versão anterior

O código funcional **não foi reescrito** — a lógica de negócio foi preservada
exatamente como estava. O que mudou foi a organização:

1. **Separação `main` / `renderer`.** Antes, todos os arquivos ficavam soltos na
   raiz, misturando processo principal (Node, acesso a banco/SO) com a interface
   (DOM, telas). Agora cada lado tem sua pasta, o que deixa explícito o que roda
   com privilégios de sistema e o que roda na janela.

2. **`script.js` (5.121 linhas / 216 KB em um único arquivo) foi dividido em 20
   módulos por responsabilidade** (login, formulários, relatórios, dashboard,
   folha de pagamento, backup, sincronização, histórico etc.), usando os
   próprios comentários de seção `// ====` que já existiam no arquivo como
   pontos de corte. Isso facilita achar código, revisar diffs e reduzir
   conflitos de merge — sem exigir um bundler, já que os arquivos continuam
   sendo carregados como `<script>` clássico e na mesma ordem de execução do
   arquivo original (as funções continuam globais, então nenhum `onclick="..."`
   do HTML foi quebrado).

3. **`services/` no processo principal.** `db.js`, `authUtils.js`,
   `backupManager.js`, `supabaseSync.js` e `migrate.js` viraram
   `database.js`, `auth.js`, `backup.js`, `sync.js` e `migrate.js` dentro de
   `src/main/services/`, com nomes mais descritivos e sem lógica de infra
   misturada em `main.js`.

4. **Boas práticas de tooling adicionadas:** `.gitignore` (não versionar
   `node_modules/`, banco `.sqlite`, backups e `dist/`), configuração básica de
   ESLint e Prettier, e um `README.md` documentando a arquitetura.

5. **`package.json` atualizado:** `main` aponta para `src/main/main.js`, a
   lista `files` do `electron-builder` aponta para `src/**/*`, e foi
   adicionado o script `npm run migrate`.

### O que **não** foi alterado

- Nenhuma regra de negócio, query SQL, permissão ou fluxo de UI foi modificado.
- Todos os `require()` internos foram só ajustados para os novos caminhos
  relativos (ex.: `require('./db')` → `require('./services/database')`).
- Todas as chamadas `onclick="..."` do `index.html` continuam funcionando,
  pois as funções continuam sendo globais (`window.*`), só que distribuídas em
  arquivos menores em vez de um único `script.js`.

### Pontos de atenção (resolvidos numa segunda rodada — ver CORRECOES-APLICADAS.md)

Os itens abaixo foram identificados nas auditorias anteriores e já estão
corrigidos neste ZIP:

- ~~`sqlite3` → `better-sqlite3`~~, ~~Electron desatualizado~~, ~~sem
  CI/CD~~, ~~sem pipeline de build automatizado~~, ~~`manifest.json`/`sw.js`/
  ícones ausentes~~ — ver a seção "Correções desta rodada" em
  `CORRECOES-APLICADAS.md` para o detalhe de cada mudança.

`node_modules/` não está incluído no ZIP (como de costume) — rode
`npm install` antes de `npm start`. O `postinstall` já cuida de recompilar
o `better-sqlite3` para a versão do Electron do projeto.

## Como rodar

```bash
npm install
npm start            # inicia o app em desenvolvimento
npm run migrate      # roda a migração do banco de dados, se necessário
npm run lint          # checa qualidade do código
npm run format:check  # confere formatação sem alterar arquivos (usado no CI)
npm run format        # formata com Prettier
npm run pack          # empacota sem gerar instalador (mais rápido, útil para testar)
npm run dist          # gera instalador para a plataforma atual
```

## CI/CD

O projeto tem dois workflows em `.github/workflows/`:

- **`ci.yml`** — roda em todo push/PR: lint (`eslint`), checagem de
  formatação (`prettier --check`) e um build de verificação (`electron-builder
  --dir`) nas três plataformas (Windows/macOS/Linux), para pegar problema de
  empacotamento cedo.
- **`release.yml`** — dispara ao empurrar uma tag `vX.Y.Z` (ex:
  `git tag v1.3.0 && git push origin v1.3.0`): gera o instalador de cada
  plataforma e publica automaticamente como anexo de uma Release do GitHub.

O `.github/dependabot.yml` mantém as dependências do npm (Electron incluído)
e as próprias GitHub Actions em dia, com PRs semanais — para não repetir o
problema de versões desatualizadas.

## Ícones

Os ícones em `build/` (`icon.ico`, `icon.icns`, `icon.png`) e em
`src/renderer/`/`Mobile/` (`icon-192.png`, `icon-512.png`) são um **placeholder**
gerado programaticamente (uma cadeira estilizada), só para o build de
distribuição funcionar de ponta a ponta sem arquivo faltando. Recomenda-se
substituí-los por uma identidade visual definitiva antes de publicar
oficialmente o instalador.

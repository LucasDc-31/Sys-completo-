# Atualização automática e assinatura do instalador

## O que já está pronto no código

- `electron-updater` integrado em `src/main/main.js` (`verificarAtualizacoes`),
  ligado ao menu **Sistema → Verificar atualizações...** e verificado
  automaticamente (silenciosamente) na abertura do app.
- `package.json` → `build.publish` aponta para GitHub Releases — o mesmo
  destino para onde `.github/workflows/release.yml` já publica os
  instaladores automaticamente a cada tag `vX.Y.Z`.
- `.github/workflows/release.yml` já repassa as variáveis de ambiente de
  assinatura (`CSC_LINK`/`CSC_KEY_PASSWORD`/Apple) para o `electron-builder`
  — mas só terá efeito quando os secrets abaixo forem cadastrados.

## O que falta — e por quê não dá para "só codar"

Assinatura de código e notarização exigem uma **identidade verificada
comprada/emitida por terceiros confiáveis** (autoridades certificadoras
para Windows, Apple para macOS). Isso não é algo que se resolve só com
código — precisa de uma decisão e um custo da organização:

### Windows

1. Comprar um certificado de assinatura de código (Code Signing
   Certificate) de uma autoridade certificadora (ex: DigiCert, Sectigo) —
   custo aproximado de US$100–500/ano. Certificados **EV** (Extended
   Validation) evitam o aviso do SmartScreen desde o primeiro download;
   certificados comuns ainda mostram o aviso até acumular reputação.
2. Exportar o certificado como `.pfx` e codificar em base64:
   ```bash
   base64 -w0 certificado.pfx > certificado.pfx.base64
   ```
3. Cadastrar como *secrets* do repositório GitHub:
   - `WIN_CSC_LINK` → conteúdo do `certificado.pfx.base64`
   - `WIN_CSC_KEY_PASSWORD` → senha do `.pfx`

### macOS

1. Ter uma conta Apple Developer Program (US$99/ano) e gerar um
   certificado "Developer ID Application".
2. Cadastrar como *secrets*:
   - `MAC_CSC_LINK` / `MAC_CSC_KEY_PASSWORD` (certificado exportado como
     `.p12` em base64, igual ao processo do Windows)
   - `APPLE_ID`, `APPLE_APP_SPECIFIC_PASSWORD` (gerada em
     appleid.apple.com), `APPLE_TEAM_ID` — necessários para a
     **notarização**, exigida pelo macOS moderno (Gatekeeper bloqueia apps
     não notarizados, mesmo assinados).

### Depois de cadastrar os secrets

Nenhuma mudança de código é necessária — o workflow já está preparado
para usá-los assim que existirem. Um build de release (`git tag vX.Y.Z &&
git push origin vX.Y.Z`) já sairá assinado/notarizado.

## Enquanto isso (sem certificado)

- **Windows:** o instalador funciona normalmente, só mostra o aviso de
  "Editor desconhecido" no primeiro clique — documentado em
  `INSTALACAO-E-OPERACAO.md` para os usuários. **A atualização automática
  (`electron-updater`) funciona mesmo sem assinatura no Windows.**
- **macOS:** sem assinatura + notarização, o macOS bloqueia a abertura do
  app por padrão (é preciso liberar manualmente em Preferências do Sistema
  → Segurança), **e o `electron-updater` normalmente falha em aplicar
  atualizações não assinadas no macOS.** Ou seja, no Mac, atualização
  automática de verdade depende de resolver a assinatura primeiro.
- **Linux:** AppImage/deb não exigem assinatura para rodar; não há bloqueio
  equivalente ao SmartScreen/Gatekeeper.

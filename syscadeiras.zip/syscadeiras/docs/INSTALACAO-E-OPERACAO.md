# SysCadeiras — Instalação e Operação

## 1. Instalação (usuário final)

1. Baixe o instalador da [página de Releases do GitHub](../../releases) correspondente ao seu sistema:
   - Windows: `SysCadeiras-Setup-x.y.z.exe` (instalador) ou a versão `portable`.
   - macOS: `SysCadeiras-x.y.z.dmg`.
   - Linux: `SysCadeiras-x.y.z.AppImage` ou `.deb`.
2. Execute o instalador e siga as instruções na tela.
   - **Windows:** como o instalador ainda não é assinado digitalmente (ver
     `ATUALIZACAO-E-ASSINATURA.md`), o Windows SmartScreen pode mostrar um
     aviso de "Editor desconhecido". Clique em "Mais informações" → "Executar
     assim mesmo". Isso é esperado até que a assinatura de código seja configurada.
3. Na primeira execução, o app cria automaticamente o banco de dados local
   e um usuário administrador padrão (veja a tela de login para as
   credenciais iniciais, ou consulte quem fez a instalação anterior).

## 2. Configurando a empresa desta instalação (multiempresa)

Se esta é a única loja/empresa usando o sistema, **nenhuma ação é
necessária** — a instalação já funciona com o valor padrão (`default`).

Se você tem **mais de uma empresa/loja usando o mesmo projeto Supabase** e
quer que os dados de cada uma fiquem isolados (não aparecerem uma para a
outra):

1. Um administrador deve rodar o script `supabase/migration.sql` no projeto
   Supabase (uma vez só, feito por quem administra o backend — não é uma
   ação do usuário final).
2. Em **cada instalação** do Desktop, um administrador logado define a
   empresa correspondente. Hoje isso é feito via o canal interno
   `config-definir-empresa` (chamado, por exemplo, a partir do DevTools do
   app ou de uma tela futura dedicada — não há ainda uma tela de
   configuração visual para isso; ver seção "Próximos passos" abaixo).
3. Reinicie o app após definir a empresa — a sincronização só usa o novo
   valor a partir da próxima inicialização.

> **Nota:** sem a migração no Supabase, o app continua funcionando
> normalmente (modo de compatibilidade, sem isolamento entre empresas) —
> ver avisos no log (`Sistema → Abrir pasta de logs`).

## 3. Múltiplas máquinas (multimáquina)

Cada instalação recebe automaticamente um identificador único (`deviceId`)
na primeira execução — não é preciso configurar nada para isso. Isso é o
que permite que dois computadores desktop da mesma empresa sincronizem
entre si corretamente (antes desta versão, isso não funcionava — ver
`CORRECOES-APLICADAS.md`).

## 4. Backup

- **Automático:** o app faz uma cópia do banco a cada 24h (verificado a
  cada 6h enquanto o app está aberto) em uma pasta interna, mantendo as
  últimas 14 cópias. Não exige nenhuma ação do usuário.
- **Manual:** menu **Sistema → Fazer backup agora**, ou pela tela de
  backup do app (permite escolher a pasta de destino).
- **Restaurar:** pela tela de backup do app, escolha o arquivo `.db` de
  backup. O app guarda uma cópia do banco atual (`syscadeiras.db.antes-restaurar.bak`)
  antes de sobrescrever, por segurança.
- **Exportar/Importar JSON:** alternativa ao backup binário, útil para
  inspecionar os dados ou migrar entre versões — também disponível na tela
  de backup.

## 5. Atualizações

Menu **Sistema → Verificar atualizações...** Veja
`ATUALIZACAO-E-ASSINATURA.md` para os detalhes técnicos e o que falta
configurar (certificados) para que isso funcione de forma totalmente
automática e sem avisos do sistema operacional.

## 6. Diagnóstico e suporte

Menu **Sistema**:
- **Diagnóstico do sistema...** mostra versão do app, tamanho do banco,
  status da sincronização, empresa/máquina configuradas, data do último
  backup e quantos conflitos de sincronização estão em aberto.
- **Abrir pasta de logs** abre a pasta com o arquivo `app.log` (e seu
  backup rotacionado `app.log.1`) — é o primeiro arquivo a pedir para
  quem for investigar um problema relatado remotamente.

Conflitos de sincronização (quando duas máquinas editam o mesmo registro
quase ao mesmo tempo) ficam registrados na tabela interna `Conflitos` e
podem ser consultados por um administrador (canal `diagnostico-conflitos`)
— nenhuma edição é perdida silenciosamente, apenas fica marcada para
revisão manual em vez de sobrescrever automaticamente.

## 7. Próximos passos recomendados (fora do escopo desta rodada)

- Tela visual de configurações (empresa, diagnóstico, conflitos) em vez de
  depender de canais internos/DevTools.
- Identidade visual definitiva (logo, paleta de cores, ícones) — depende de
  material de marca fornecido pela equipe/design.
- Certificados de assinatura de código (Windows/macOS) — ver
  `ATUALIZACAO-E-ASSINATURA.md`.

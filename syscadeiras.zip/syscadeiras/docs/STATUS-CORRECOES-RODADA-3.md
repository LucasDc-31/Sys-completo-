# Status desta rodada de correções (aplicadas na ordem pedida)

Legenda: ✅ resolvido nesta rodada · 🟡 avançado, com uma parte que depende
de decisão/ação humana fora do código · ⏳ não abordado nesta rodada (motivo explicado)

---

## 🔴 1. Resolver sincronização multiempresa/multimáquina — 🟡

**O que estava quebrado:** duas máquinas Desktop da mesma empresa nunca
sincronizavam entre si (o filtro de "não reprocessar o que eu mesmo
enviei" comparava `device_origin === 'desktop'`, o que descartava
qualquer desktop, não só o próprio). E não existia nenhum conceito de
"empresa" — todas as instalações liam/escreviam nas mesmas linhas do
Supabase.

**O que foi feito:**
- Cada instalação ganhou um `deviceId` único e permanente (`config.js`) —
  o filtro de eco agora compara esse id, não mais um valor genérico.
- Cada instalação tem um `empresaId` (padrão `'default'`, configurável por
  um admin) — toda leitura, escrita e evento em tempo real agora é
  filtrado por ele (`sync.js`).
- Resiliente à ordem de implantação: se o Supabase ainda não tiver as
  colunas novas (script não rodado ainda), o app detecta e cai para o
  comportamento antigo, avisando no log — não trava a sincronização de
  quem ainda não migrou.

**Por que é 🟡 e não ✅:** a parte de configurar qual `empresaId` cada
instalação usa ainda depende de uma ação humana por instalação (rodar a
migração SQL uma vez, e um admin definir a empresa em cada máquina — ver
`docs/INSTALACAO-E-OPERACAO.md`). Isso é esperado (não dá pra "adivinhar"
como suas empresas devem ser separadas), mas ainda não existe uma tela
visual para isso — hoje é feito por um canal interno (`config-definir-empresa`).

---

## 🔴 2. Trocar IDs locais por UUID — 🟡

**O que estava quebrado:** o `id` de cada tabela é um autoincrement LOCAL.
Duas máquinas diferentes podem ter, cada uma, um registro de `id=1` para
peças completamente diferentes. O sync usava esse `id` como chave de
upsert no Supabase — ou seja, uma máquina podia sobrescrever silenciosamente
o registro de outra.

**O que foi feito:**
- Toda tabela sincronizada (`Pecas`, `Cores`, `Funcionarios`, `Producoes`,
  `Movimentacoes`, `Armações`, `EstoqueArmacoes`, `Usuarios`) ganhou uma
  coluna `uuid`, preenchida automaticamente por trigger em todo INSERT —
  **nenhuma tela precisou ser alterada** para isso.
- A sincronização passou a usar `uuid` como chave de conflito no upsert
  (`espelhar()`), em vez do `id` local.
- Registros que dependem de outro (ex: uma Produção referencia um
  Funcionário/Peça/Cor) agora também trocam o `*Id` local pelo `*Uuid` do
  registro pai ao serem espelhados, e resolvem de volta para o `id` LOCAL
  correto desta máquina ao receber — sem isso, o "de quem é essa
  produção" ficaria embaralhado entre máquinas.
- Exclusões (`DELETE`) também passaram a usar `uuid`, capturado automaticamente
  antes do registro sumir localmente.

**Por que é 🟡 e não ✅:** isto NÃO foi uma reescrita de todos os `id`
locais do banco para UUID (o que exigiria trocar toda chave primária, toda
FK e toda tela que referencia registros por id — um projeto grande e
arriscado de fazer sem conseguir rodar a interface gráfica para testar).
Em vez disso, foi resolvido o problema real por trás do pedido: os `id`
locais continuam existindo e funcionando normalmente **dentro de cada
máquina** (não mudou nada nas telas), mas deixaram de ser usados como
identidade **entre máquinas** — esse papel agora é do `uuid`. Isso resolve
a colisão de dados sem o risco de uma migração total de esquema não testável
neste ambiente. Se no futuro quiser eliminar os ids locais por completo
(ex: para simplificar ainda mais o código), é um projeto à parte,
recomendado só depois de repor a suíte de testes de UI (Playwright/Spectron)
para validar cada tela.

---

## 🔴 3. Criar testes automatizados — 🟡

**O que foi feito:**
- `tests/auth.test.js` (10 testes) e `tests/config.test.js` (6 testes) —
  **rodados e passando neste ambiente** (`node --test tests/auth.test.js
  tests/config.test.js`), cobrindo hash/verificação de senha (incl.
  compatibilidade com hash legado), permissões, geração/persistência de
  `deviceId`/`empresaId` e o cenário de duas instalações distintas.
- `tests/database.test.js` — cobre as triggers de `uuid`/`empresaId`/`updatedAt`,
  unicidade de `uuid` e a tabela `Conflitos`.
- `tests/sync.test.js` — cobre o remapeamento de colunas e os nomes de
  tabela (`Armacoes` ↔ `Armações`).
- `scripts/test-db-recovery.js` (`npm run test:recovery`) — teste de ponta
  a ponta do cenário "perdi o banco": cria dados → backup → apaga o banco →
  restaura → confere os dados → confere a cópia de segurança automática →
  testa também o caminho alternativo de exportar/importar JSON.
- `npm test` e `npm run test:recovery` adicionados ao `package.json` e
  chamados em `.github/workflows/ci.yml` — todo Pull Request passa a
  rodá-los automaticamente.

**Por que é 🟡 e não ✅:** `tests/database.test.js`, `tests/sync.test.js` e
`scripts/test-db-recovery.js` dependem de módulos nativos/de rede
(`better-sqlite3`, `@supabase/supabase-js`, `ws`) que **este ambiente de
revisão não conseguiu instalar** (acesso à internet restrito a alguns
domínios; a compilação do `better-sqlite3` precisa baixar um binário de
`nodejs.org`/prebuilds fora da lista liberada). Eles foram escritos com o
mesmo cuidado e revisados linha a linha, e vão rodar normalmente no seu
ambiente de desenvolvimento/CI (que já compila essas mesmas dependências
para o app funcionar) — mas não puderam ser **executados e confirmados**
aqui, diferente dos dois primeiros arquivos. Recomendo rodar `npm test &&
npm run test:recovery` localmente assim que baixar este pacote, antes de
publicar.
- Cobertura ainda não inclui testes de interface (telas) — exigiria
  Playwright/Spectron e um ambiente com display gráfico, fora do escopo
  desta rodada.

---

## 🔴 4. Reforçar todos os IPC — ✅ (incremental sobre uma base já sólida)

O projeto já tinha uma camada de validação robusta (whitelist de
tabelas/SQL, sessão obrigatória, checagem de admin — ver
`CORRECOES-APLICADAS.md`, rodada anterior). Nesta rodada:
- Bloqueado o acesso à tabela interna `Conflitos` pelo canal genérico de
  SQL (leitura e escrita) — só acessível pelo canal dedicado
  `diagnostico-conflitos`, que exige admin.
- Removidos 3 canais IPC mortos e perigosos (`save-multiple-files`,
  `check-directory`, `list-files` — ver item 5 abaixo).
- `backup-restaurar` passou a validar o cabeçalho do arquivo (`SQLite
  format 3`) antes de sobrescrever o banco em uso, mesmo que o caminho não
  tenha vindo do diálogo nativo.
- Novos canais (`config-definir-empresa`, `diagnostico-conflitos`) já
  nascem exigindo admin, seguindo o padrão existente (`exigirAdmin()`).

---

## 🔴 5. Restringir operações de filesystem — ✅

**O que estava exposto:** `check-directory` criava um diretório em
**qualquer caminho arbitrário do disco** informado pelo renderer, e
`list-files` listava o conteúdo de **qualquer pasta arbitrária** — ambos
sem nenhuma tela do sistema realmente usar (`grep` em todo
`src/renderer/js` não encontrou nenhuma chamada a
`fileSystem.checkDirectory`/`listFiles`/`saveMultipleFiles`).

**O que foi feito:** os três canais foram **removidos** (código morto que
só servia como superfície de ataque). `save-document` (o único
efetivamente usado, para exportar relatórios) permanece, mas agora valida
que o conteúdo é uma string dentro de um tamanho razoável antes de gravar
— o caminho de destino já era sempre escolhido pelo usuário via diálogo
nativo do sistema operacional, nunca uma string vinda do renderer.

---

## 🔴 6. Testar recuperação de banco — ✅

Ver item 3 — `scripts/test-db-recovery.js` cobre especificamente este
ponto (backup → perda total → restauração → verificação de integridade →
verificação da cópia de segurança automática → export/import JSON como
caminho alternativo).

---

## 🟠 7. Criar controle de conflitos — ✅

Nova tabela `Conflitos`: quando uma atualização chega de outra máquina e a
versão local é **mais recente** (comparando `updatedAt`), a atualização
recebida **não sobrescreve** o dado local — fica registrada em
`Conflitos` (com o dado local, o dado recebido e o motivo) para revisão
manual, visível pelo menu **Sistema → Diagnóstico do sistema** (contagem)
e pelo canal `diagnostico-conflitos` (lista completa, admin). Nenhuma
edição é perdida silenciosamente.

---

## 🟠 8. Backup automático — ✅

Backup diário automático (verificado a cada 6h, dispara se o último tiver
mais de 24h), guardando as últimas 14 cópias, sem exigir nenhuma ação do
usuário — ver `iniciarAgendadorDeBackup`/`executarBackupAutomaticoSeNecessario`
em `main.js`.

---

## 🟠 9. Atualização automática — 🟡

`electron-updater` integrado e configurado para checar/baixar/instalar
atualizações via GitHub Releases (mesmo canal que `release.yml` já
publica). **Funciona sem certificado no Windows**; no **macOS, precisa da
assinatura/notarização (item 10) para funcionar de fato** — o Gatekeeper
bloqueia binários não notarizados independentemente do updater. Ver
`docs/ATUALIZACAO-E-ASSINATURA.md`.

---

## 🟠 10. Assinatura do instalador — ⏳ (depende de recurso externo pago)

O workflow de release já está pronto para assinar automaticamente assim
que os certificados existirem (`CSC_LINK`/`CSC_KEY_PASSWORD`/credenciais
Apple via secrets do GitHub) — mas **obter um certificado de assinatura de
código é uma decisão e um custo da organização** (certificado pago de uma
autoridade certificadora + conta Apple Developer), não algo que se resolve
só escrevendo código. Passo a passo completo em
`docs/ATUALIZACAO-E-ASSINATURA.md`.

---

## 🟡 11. Monitoramento/diagnóstico — ✅

- `src/main/services/logger.js`: todo `console.log/warn/error` do processo
  principal também é gravado em `userData/logs/app.log` (com rotação em
  ~5MB), sem precisar reproduzir o problema para investigar depois.
- Menu **Sistema → Diagnóstico do sistema...**: versão do app, tamanho do
  banco, status da sincronização, empresa/máquina configuradas, data do
  último backup automático e conflitos de sincronização em aberto.
- Menu **Sistema → Abrir pasta de logs**.

---

## 🟡 12. Identidade visual definitiva — ⏳ (depende de material de marca)

Não abordado nesta rodada. Definir uma identidade visual (logo, paleta,
ícones finais) é uma decisão de design/produto que depende de material
fornecido pela equipe (ou de uma sessão dedicada a isso) — não é algo que
deva ser inventado unilateralmente no código. Os ícones atuais continuam
sendo o placeholder já sinalizado na rodada anterior
(`CORRECOES-APLICADAS.md`).

---

## 🟡 13. Documentação de instalação e operação — ✅

`docs/INSTALACAO-E-OPERACAO.md` (instalação, configuração de
empresa/multimáquina, backup, atualização, diagnóstico) e
`docs/ATUALIZACAO-E-ASSINATURA.md` (detalhes técnicos de update/assinatura).

---

## Antes de publicar esta versão — checklist

1. `npm install` no seu ambiente (compila `better-sqlite3` etc.).
2. `npm test && npm run test:recovery` — confirme que os testes que não
   puderam rodar aqui passam no seu ambiente.
3. Rode `supabase/migration.sql` no seu projeto Supabase.
4. Depois de instalar a nova versão em cada máquina, um admin define a
   empresa correspondente (`config-definir-empresa`) se você tiver mais de
   uma empresa/loja compartilhando o mesmo projeto Supabase.
5. (Opcional, recomendado a médio prazo) Adquira certificados de
   assinatura de código — ver `docs/ATUALIZACAO-E-ASSINATURA.md`.

// Requer better-sqlite3 já instalado/compilado (`npm install` completo) —
// não executa neste ambiente de revisão isolado sem acesso à internet, mas
// roda normalmente no ambiente de desenvolvimento/CI do projeto (a mesma
// dependência nativa que o app usa em produção).
const test = require('node:test');
const assert = require('node:assert/strict');
require('./_setupElectronMock');

function novoDbFresco() {
    delete require.cache[require.resolve('../src/main/services/database')];
    delete require.cache[require.resolve('../src/main/services/config')];
    const Database = require('../src/main/services/database');
    return new Database();
}

test('init() cria as tabelas e não lança exceção', async () => {
    const db = novoDbFresco();
    await db.init();
    const tabelas = await db.all(`SELECT name FROM sqlite_master WHERE type='table'`);
    const nomes = tabelas.map(t => t.name);
    assert.ok(nomes.includes('Pecas'));
    assert.ok(nomes.includes('Conflitos'));
    db.close();
});

test('INSERT em tabela sincronizada preenche uuid/empresaId/updatedAt automaticamente', async () => {
    const db = novoDbFresco();
    await db.init();
    const r = await db.run(`INSERT INTO Pecas (nome, ativo) VALUES ('Armação Teste', 1)`);
    const linha = await db.get(`SELECT * FROM Pecas WHERE id = ?`, [r.lastID]);
    assert.ok(linha.uuid, 'uuid deveria ter sido preenchido pelo trigger');
    assert.equal(linha.empresaId, 'default');
    assert.ok(linha.updatedAt, 'updatedAt deveria ter sido preenchido pelo trigger');
    db.close();
});

test('dois INSERTs geram uuids diferentes (sem colisão)', async () => {
    const db = novoDbFresco();
    await db.init();
    const r1 = await db.run(`INSERT INTO Pecas (nome, ativo) VALUES ('Peça 1', 1)`);
    const r2 = await db.run(`INSERT INTO Pecas (nome, ativo) VALUES ('Peça 2', 1)`);
    const l1 = await db.get(`SELECT uuid FROM Pecas WHERE id = ?`, [r1.lastID]);
    const l2 = await db.get(`SELECT uuid FROM Pecas WHERE id = ?`, [r2.lastID]);
    assert.notEqual(l1.uuid, l2.uuid);
    db.close();
});

test('UPDATE atualiza updatedAt automaticamente quando quem grava não define a coluna', async () => {
    const db = novoDbFresco();
    await db.init();
    const r = await db.run(`INSERT INTO Pecas (nome, ativo) VALUES ('Peça X', 1)`);
    const antes = await db.get(`SELECT updatedAt FROM Pecas WHERE id = ?`, [r.lastID]);
    await new Promise(res => setTimeout(res, 5));
    await db.run(`UPDATE Pecas SET nome = 'Peça X Editada' WHERE id = ?`, [r.lastID]);
    const depois = await db.get(`SELECT updatedAt FROM Pecas WHERE id = ?`, [r.lastID]);
    assert.notEqual(antes.updatedAt, depois.updatedAt);
    db.close();
});

test('uuid tem índice único (não permite duas linhas com o mesmo uuid)', async () => {
    const db = novoDbFresco();
    await db.init();
    const r = await db.run(`INSERT INTO Pecas (nome, ativo) VALUES ('Peça Y', 1)`);
    const linha = await db.get(`SELECT uuid FROM Pecas WHERE id = ?`, [r.lastID]);
    await assert.rejects(
        db.run(`INSERT INTO Pecas (nome, ativo, uuid) VALUES ('Peça Y2', 1, ?)`, [linha.uuid])
    );
    db.close();
});

test('tabela Conflitos aceita registro de conflito de sincronização', async () => {
    const db = novoDbFresco();
    await db.init();
    await db.run(
        `INSERT INTO Conflitos (tabela, registroUuid, empresaId, motivo) VALUES (?,?,?,?)`,
        ['Pecas', 'uuid-fake', 'default', 'teste automatizado']
    );
    const conflitos = await db.all(`SELECT * FROM Conflitos`);
    assert.equal(conflitos.length, 1);
    assert.equal(conflitos[0].resolvido, 0);
    db.close();
});

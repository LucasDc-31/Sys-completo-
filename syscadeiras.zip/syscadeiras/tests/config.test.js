const test = require('node:test');
const assert = require('node:assert/strict');
require('./_setupElectronMock');

// Cada teste usa require('../src/main/services/config') de novo (com
// jest/mocha isso seria resetModules; com node:test usamos delete no cache
// para simular uma "nova instalação" do zero em cada teste).
function carregarConfigFresco() {
    delete require.cache[require.resolve('../src/main/services/config')];
    return require('../src/main/services/config');
}

test('gera um deviceId (uuid) automaticamente na primeira execução', () => {
    const config = carregarConfigFresco();
    const id = config.getDeviceId();
    assert.match(id, /^[0-9a-f-]{16,}$/i, 'deviceId deve parecer um uuid/hex');
});

test('deviceId é estável entre chamadas (mesma instalação)', () => {
    const config = carregarConfigFresco();
    const a = config.getDeviceId();
    const b = config.getDeviceId();
    assert.equal(a, b);
});

test('empresaId começa em "default" (compatível com instalações single-empresa)', () => {
    const config = carregarConfigFresco();
    assert.equal(config.getEmpresaId(), 'default');
});

test('definirEmpresa atualiza e persiste empresaId/empresaNome', () => {
    const config = carregarConfigFresco();
    const atualizado = config.definirEmpresa('loja-centro', 'Ótica Loja Centro');
    assert.equal(atualizado.empresaId, 'loja-centro');
    assert.equal(atualizado.empresaNome, 'Ótica Loja Centro');
    assert.equal(config.getEmpresaId(), 'loja-centro');
    assert.equal(config.getEmpresaNome(), 'Ótica Loja Centro');
});

test('definirEmpresa rejeita empresaId vazio', () => {
    const config = carregarConfigFresco();
    assert.throws(() => config.definirEmpresa('   ', 'Nome'));
});

test('duas instalações "diferentes" (pastas userData diferentes) geram deviceId diferentes', () => {
    // Simula duas máquinas distintas: cada uma com sua própria pasta
    // userData — é exatamente essa diferença que corrige o bug de
    // multimáquina (antes as duas eram identificadas como 'desktop').
    const os = require('os');
    const path = require('path');
    const fs = require('fs');
    const Module = require('module');

    delete require.cache[require.resolve('../src/main/services/config')];
    const pastaA = fs.mkdtempSync(path.join(os.tmpdir(), 'syscadeiras-maquinaA-'));
    const pastaB = fs.mkdtempSync(path.join(os.tmpdir(), 'syscadeiras-maquinaB-'));

    const originalLoad = Module._load;
    let pastaAtual = pastaA;
    Module._load = function (request, parent, isMain) {
        if (request === 'electron') {
            return { app: { getPath: () => pastaAtual, getVersion: () => '0.0.0-test', isPackaged: false } };
        }
        return originalLoad.apply(this, arguments);
    };

    delete require.cache[require.resolve('../src/main/services/config')];
    const configA = require('../src/main/services/config');
    const deviceIdA = configA.getDeviceId();

    pastaAtual = pastaB;
    delete require.cache[require.resolve('../src/main/services/config')];
    const configB = require('../src/main/services/config');
    const deviceIdB = configB.getDeviceId();

    Module._load = originalLoad;

    assert.notEqual(deviceIdA, deviceIdB, 'cada instalação deve ter um deviceId único');
});

// Requer `npm install` completo (com @supabase/supabase-js e ws) — não
// executa neste ambiente de revisão isolado sem acesso à internet para
// baixar essas dependências, mas roda normalmente no ambiente de
// desenvolvimento/CI do projeto (mesmas dependências que o app já usa).
const test = require('node:test');
const assert = require('node:assert/strict');
require('./_setupElectronMock');

const sync = require('../src/main/services/sync');
const { remapearColunas, tabelaLocalDe, tabelaSupabaseDe } = sync._internal;

test('remapearColunas converte colunas lowercase do Postgres para camelCase do SQLite', () => {
    const entrada = { id: 1, pecaid: 5, corid: 2, funcionarioid: 9, horaextra: 1, empresaid: 'loja-1', deviceid: 'abc', updatedat: '2026-01-01' };
    const saida = remapearColunas(entrada);
    assert.equal(saida.pecaId, 5);
    assert.equal(saida.corId, 2);
    assert.equal(saida.funcionarioId, 9);
    assert.equal(saida.horaExtra, 1);
    assert.equal(saida.empresaId, 'loja-1');
    assert.equal(saida.deviceId, 'abc');
    assert.equal(saida.updatedAt, '2026-01-01');
    // colunas sem mapeamento (ex: id, uuid) passam intactas
    assert.equal(saida.id, 1);
});

test('remapearColunas converte as colunas *uuid das FKs', () => {
    const entrada = { pecauuid: 'uuid-peca', coruuid: 'uuid-cor', funcionariouuid: 'uuid-func', producaouuid: 'uuid-prod', modelouuid: 'uuid-modelo' };
    const saida = remapearColunas(entrada);
    assert.equal(saida.pecaUuid, 'uuid-peca');
    assert.equal(saida.corUuid, 'uuid-cor');
    assert.equal(saida.funcionarioUuid, 'uuid-func');
    assert.equal(saida.producaoUuid, 'uuid-prod');
    assert.equal(saida.modeloUuid, 'uuid-modelo');
});

test('tabelaLocalDe/tabelaSupabaseDe convertem "Armacoes" <-> "Armações"', () => {
    assert.equal(tabelaLocalDe('Armacoes'), 'Armações');
    assert.equal(tabelaSupabaseDe('Armações'), 'Armacoes');
    // outras tabelas não mudam
    assert.equal(tabelaLocalDe('Pecas'), 'Pecas');
    assert.equal(tabelaSupabaseDe('Pecas'), 'Pecas');
});

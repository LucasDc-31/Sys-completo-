const test = require('node:test');
const assert = require('node:assert/strict');
const { hashPassword, verifyPassword, normalizarPermissoes } = require('../src/main/services/auth');

test('hashPassword gera um hash no formato salt:hash', () => {
    const hash = hashPassword('minhaSenha123');
    assert.match(hash, /^[0-9a-f]{32}:[0-9a-f]{128}$/);
});

test('hashPassword nunca gera o mesmo hash duas vezes para a mesma senha (salt aleatório)', () => {
    const a = hashPassword('mesmaSenha');
    const b = hashPassword('mesmaSenha');
    assert.notEqual(a, b);
});

test('verifyPassword aceita a senha correta (formato novo)', () => {
    const hash = hashPassword('correta123');
    const r = verifyPassword('correta123', hash);
    assert.equal(r.ok, true);
    assert.equal(r.legado, false);
});

test('verifyPassword rejeita senha errada (formato novo)', () => {
    const hash = hashPassword('correta123');
    const r = verifyPassword('errada456', hash);
    assert.equal(r.ok, false);
});

test('verifyPassword aceita hash legado (base64) e sinaliza legado:true', () => {
    const senha = 'senhaAntiga';
    const hashLegado = Buffer.from(senha).toString('base64');
    const r = verifyPassword(senha, hashLegado);
    assert.equal(r.ok, true);
    assert.equal(r.legado, true);
});

test('verifyPassword rejeita hash legado com senha errada', () => {
    const hashLegado = Buffer.from('senhaAntiga').toString('base64');
    const r = verifyPassword('outraSenha', hashLegado);
    assert.equal(r.ok, false);
});

test('verifyPassword lida com armazenado vazio/nulo sem lançar exceção', () => {
    assert.equal(verifyPassword('qualquer', null).ok, false);
    assert.equal(verifyPassword('qualquer', undefined).ok, false);
    assert.equal(verifyPassword('qualquer', '').ok, false);
});

test('normalizarPermissoes aceita array diretamente', () => {
    assert.deepEqual(normalizarPermissoes(['pecas', 'cores']), ['pecas', 'cores']);
});

test('normalizarPermissoes faz parse de JSON string', () => {
    assert.deepEqual(normalizarPermissoes('["pecas","*"]'), ['pecas', '*']);
});

test('normalizarPermissoes retorna [] para entrada inválida/nula', () => {
    assert.deepEqual(normalizarPermissoes(null), []);
    assert.deepEqual(normalizarPermissoes('não é json'), []);
    assert.deepEqual(normalizarPermissoes('{"nao":"é array"}'), []);
});

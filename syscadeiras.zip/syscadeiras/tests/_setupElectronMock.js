// ============================================
// _setupElectronMock.js — usado só pelos testes
// ============================================
// Os testes rodam com `node --test`, fora do processo Electron. Vários
// serviços (config.js, database.js, backup.js) fazem
// `const { app } = require('electron')` para achar a pasta de dados do
// usuário. Fora do Electron, `require('electron')` resolve para uma
// string (caminho do binário), não um objeto — então interceptamos a
// resolução do módulo 'electron' e devolvemos um objeto fake, apontando
// `app.getPath('userData')` para uma pasta temporária isolada por
// execução de teste. Padrão comum para testar código Electron com Node puro,
// sem precisar de nenhuma dependência nova.
// ============================================

const Module = require('module');
const path = require('path');
const os = require('os');
const fs = require('fs');

const pastaTemporaria = fs.mkdtempSync(path.join(os.tmpdir(), 'syscadeiras-test-'));

const originalLoad = Module._load;
Module._load = function (request, parent, isMain) {
    if (request === 'electron') {
        return {
            app: {
                getPath: (nome) => pastaTemporaria,
                getVersion: () => '0.0.0-test',
                isPackaged: false,
            },
        };
    }
    return originalLoad.apply(this, arguments);
};

module.exports = { pastaTemporaria };

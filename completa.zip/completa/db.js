const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const { app } = require('electron');

class Database {
    constructor() {
        this.db = null;
        this.dbPath = null;
    }

    async init() {
        return new Promise((resolve, reject) => {
            try {
                // Obter o userDataPath de forma segura - garante persistência após instalação
                const userDataPath = app.getPath('userData');
                this.dbPath = path.join(userDataPath, 'syscadeiras.db');
                
                // Criar o diretório se não existir
                const fs = require('fs');
                if (!fs.existsSync(userDataPath)) {
                    fs.mkdirSync(userDataPath, { recursive: true });
                }
                
                console.log('Conectando ao banco em:', this.dbPath);
                console.log('Diretório de dados do usuário:', userDataPath);
                
                this.db = new sqlite3.Database(this.dbPath, (err) => {
                    if (err) {
                        console.error('Erro ao conectar com o banco:', err);
                        reject(err);
                    } else {
                        console.log('✅ Conectado ao SQLite');
                        this.createTables()
                            .then(() => this.verificarEstrutura())
                            .then(resolve)
                            .catch(reject);
                    }
                });
            } catch (error) {
                console.error('Erro no init do Database:', error);
                reject(error);
            }
        });
    }

    createTables() {
        return new Promise((resolve, reject) => {
            const queries = [
                `CREATE TABLE IF NOT EXISTS Pecas (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL,
                    valor REAL NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(nome)
                )`,

                `CREATE TABLE IF NOT EXISTS Cores (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(nome)
                )`,

                `CREATE TABLE IF NOT EXISTS Funcionarios (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL,
                    cargo TEXT NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(nome)
                )`,

                `CREATE TABLE IF NOT EXISTS Producoes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    data TEXT NOT NULL,
                    funcionarioId INTEGER,
                    pecaId INTEGER,
                    corId INTEGER,
                    quantidade INTEGER NOT NULL,
                    horaExtra BOOLEAN DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(funcionarioId) REFERENCES Funcionarios(id),
                    FOREIGN KEY(pecaId) REFERENCES Pecas(id),
                    FOREIGN KEY(corId) REFERENCES Cores(id)
                )`,

                `CREATE TABLE IF NOT EXISTS Movimentacoes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    data TEXT NOT NULL,
                    tipo TEXT NOT NULL,
                    pecaId INTEGER,
                    corId INTEGER,
                    quantidade INTEGER NOT NULL,
                    origem TEXT,
                    producaoId INTEGER,
                    funcionarioId INTEGER,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY(pecaId) REFERENCES Pecas(id),
                    FOREIGN KEY(corId) REFERENCES Cores(id),
                    FOREIGN KEY(funcionarioId) REFERENCES Funcionarios(id)
                )`,

                `CREATE TABLE IF NOT EXISTS Comprovantes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tipo TEXT NOT NULL,
                    numero TEXT NOT NULL,
                    dados TEXT NOT NULL,
                    data TEXT NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )`,

                // Índices para melhor performance de pesquisa
                `CREATE INDEX IF NOT EXISTS idx_movimentacoes_data ON Movimentacoes(data)`,
                `CREATE INDEX IF NOT EXISTS idx_movimentacoes_tipo ON Movimentacoes(tipo)`,
                `CREATE INDEX IF NOT EXISTS idx_movimentacoes_pecaId ON Movimentacoes(pecaId)`,
                `CREATE INDEX IF NOT EXISTS idx_movimentacoes_corId ON Movimentacoes(corId)`,
                `CREATE INDEX IF NOT EXISTS idx_movimentacoes_data_tipo ON Movimentacoes(data, tipo)`,
                `CREATE INDEX IF NOT EXISTS idx_producoes_data ON Producoes(data)`,
                `CREATE INDEX IF NOT EXISTS idx_producoes_funcionarioId ON Producoes(funcionarioId)`
            ];

            let completed = 0;
            queries.forEach(query => {
                this.db.run(query, (err) => {
                    if (err) {
                        console.error('Erro ao criar tabela:', err);
                        reject(err);
                        return;
                    }
                    completed++;
                    if (completed === queries.length) {
                        console.log('✅ Todas as tabelas e índices criados/verificados');
                        resolve();
                    }
                });
            });
        });
    }

    async verificarEstrutura() {
        try {
            // Verificar e adicionar colunas faltantes
            const tabelas = ['Pecas', 'Cores', 'Funcionarios', 'Producoes', 'Movimentacoes'];
            
            for (const tabela of tabelas) {
                try {
                    const colunas = await this.all(`PRAGMA table_info(${tabela})`);
                    console.log(`Estrutura da tabela ${tabela}:`, colunas.map(c => c.name));
                } catch (error) {
                    console.warn(`Erro ao verificar tabela ${tabela}:`, error.message);
                }
            }
            
        } catch (error) {
            console.error('Erro na verificação da estrutura:', error);
        }
    }

    // ======= FUNÇÕES DE PESQUISA OTIMIZADAS =======

    async pesquisarMovimentacoes(filtros = {}) {
        let sql = `
            SELECT 
                m.*,
                p.nome as pecaNome,
                p.valor as pecaValor,
                c.nome as corNome,
                f.nome as funcionarioNome
            FROM Movimentacoes m
            LEFT JOIN Pecas p ON m.pecaId = p.id
            LEFT JOIN Cores c ON m.corId = c.id
            LEFT JOIN Funcionarios f ON m.funcionarioId = f.id
            WHERE 1=1
        `;
        const params = [];

        if (filtros.dataInicio) {
            sql += ` AND m.data >= ?`;
            params.push(filtros.dataInicio);
        }
        if (filtros.dataFim) {
            sql += ` AND m.data <= ?`;
            params.push(filtros.dataFim);
        }
        if (filtros.tipo) {
            sql += ` AND m.tipo = ?`;
            params.push(filtros.tipo);
        }
        if (filtros.pecaId) {
            sql += ` AND m.pecaId = ?`;
            params.push(filtros.pecaId);
        }
        if (filtros.corId) {
            sql += ` AND m.corId = ?`;
            params.push(filtros.corId);
        }
        if (filtros.producaoId) {
            sql += ` AND m.producaoId = ?`;
            params.push(filtros.producaoId);
        }
        if (filtros.texto) {
            sql += ` AND (p.nome LIKE ? OR c.nome LIKE ? OR m.origem LIKE ?)`;
            const termo = `%${filtros.texto}%`;
            params.push(termo, termo, termo);
        }

        sql += ` ORDER BY m.data DESC, m.id DESC`;
        
        if (filtros.limite) {
            sql += ` LIMIT ?`;
            params.push(filtros.limite);
        }

        return this.all(sql, params);
    }

    async calcularSaldoEstoque(pecaId = null, corId = null) {
        let sql = `
            SELECT 
                m.pecaId,
                p.nome as pecaNome,
                m.corId,
                c.nome as corNome,
                SUM(CASE WHEN m.tipo = 'entrada' THEN m.quantidade ELSE -m.quantidade END) as saldo
            FROM Movimentacoes m
            LEFT JOIN Pecas p ON m.pecaId = p.id
            LEFT JOIN Cores c ON m.corId = c.id
            WHERE 1=1
        `;
        const params = [];

        if (pecaId) {
            sql += ` AND m.pecaId = ?`;
            params.push(pecaId);
        }
        if (corId) {
            sql += ` AND m.corId = ?`;
            params.push(corId);
        }

        sql += ` GROUP BY m.pecaId, m.corId ORDER BY p.nome, c.nome`;

        return this.all(sql, params);
    }

    async pesquisarProducoes(filtros = {}) {
        let sql = `
            SELECT 
                prod.*,
                f.nome as funcionarioNome,
                f.cargo as funcionarioCargo,
                p.nome as pecaNome,
                p.valor as pecaValor,
                c.nome as corNome
            FROM Producoes prod
            LEFT JOIN Funcionarios f ON prod.funcionarioId = f.id
            LEFT JOIN Pecas p ON prod.pecaId = p.id
            LEFT JOIN Cores c ON prod.corId = c.id
            WHERE 1=1
        `;
        const params = [];

        if (filtros.dataInicio) {
            sql += ` AND prod.data >= ?`;
            params.push(filtros.dataInicio);
        }
        if (filtros.dataFim) {
            sql += ` AND prod.data <= ?`;
            params.push(filtros.dataFim);
        }
        if (filtros.funcionarioId) {
            sql += ` AND prod.funcionarioId = ?`;
            params.push(filtros.funcionarioId);
        }
        if (filtros.pecaId) {
            sql += ` AND prod.pecaId = ?`;
            params.push(filtros.pecaId);
        }
        if (filtros.corId) {
            sql += ` AND prod.corId = ?`;
            params.push(filtros.corId);
        }
        if (filtros.horaExtra !== undefined) {
            sql += ` AND prod.horaExtra = ?`;
            params.push(filtros.horaExtra ? 1 : 0);
        }

        sql += ` ORDER BY prod.data DESC, prod.id DESC`;

        return this.all(sql, params);
    }

    async getEstatisticasEstoque() {
        const stats = {};

        // Total de itens em estoque
        const totalItens = await this.get(`
            SELECT 
                COUNT(DISTINCT pecaId || '-' || corId) as totalVariacoes,
                SUM(CASE WHEN tipo = 'entrada' THEN quantidade ELSE -quantidade END) as saldoTotal
            FROM Movimentacoes
        `);

        // Itens com estoque baixo (menos de 10 unidades)
        const itensBaixos = await this.all(`
            SELECT 
                m.pecaId,
                p.nome as pecaNome,
                m.corId,
                c.nome as corNome,
                SUM(CASE WHEN m.tipo = 'entrada' THEN m.quantidade ELSE -m.quantidade END) as saldo
            FROM Movimentacoes m
            LEFT JOIN Pecas p ON m.pecaId = p.id
            LEFT JOIN Cores c ON m.corId = c.id
            GROUP BY m.pecaId, m.corId
            HAVING saldo < 10
            ORDER BY saldo ASC
        `);

        // Itens com estoque negativo
        const itensNegativos = await this.all(`
            SELECT 
                m.pecaId,
                p.nome as pecaNome,
                m.corId,
                c.nome as corNome,
                SUM(CASE WHEN m.tipo = 'entrada' THEN m.quantidade ELSE -m.quantidade END) as saldo
            FROM Movimentacoes m
            LEFT JOIN Pecas p ON m.pecaId = p.id
            LEFT JOIN Cores c ON m.corId = c.id
            GROUP BY m.pecaId, m.corId
            HAVING saldo < 0
            ORDER BY saldo ASC
        `);

        // Movimentações do dia
        const hoje = new Date().toISOString().split('T')[0];
        const movHoje = await this.get(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN tipo = 'entrada' THEN quantidade ELSE 0 END) as entradas,
                SUM(CASE WHEN tipo = 'saida' THEN quantidade ELSE 0 END) as saidas
            FROM Movimentacoes
            WHERE data = ?
        `, [hoje]);

        stats.totalVariacoes = totalItens?.totalVariacoes || 0;
        stats.saldoTotal = totalItens?.saldoTotal || 0;
        stats.itensBaixos = itensBaixos || [];
        stats.itensNegativos = itensNegativos || [];
        stats.movimentacoesHoje = movHoje || { total: 0, entradas: 0, saidas: 0 };

        return stats;
    }

    // ======= FUNÇÕES CRUD BÁSICAS =======

    run(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.run(sql, params, function(err) {
                if (err) {
                    console.error('Erro no SQL:', err);
                    console.error('Query:', sql);
                    console.error('Params:', params);
                    reject(err);
                } else {
                    resolve({ id: this.lastID, changes: this.changes });
                }
            });
        });
    }

    get(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.get(sql, params, (err, row) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(row);
                }
            });
        });
    }

    all(sql, params = []) {
        return new Promise((resolve, reject) => {
            this.db.all(sql, params, (err, rows) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(rows);
                }
            });
        });
    }

    close() {
        if (this.db) {
            this.db.close();
            console.log('Conexão com o banco fechada');
        }
    }
}

module.exports = Database;
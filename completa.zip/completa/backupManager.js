// ============================================
// backupManager.js - Sistema Completo de Backup
// ============================================
// Este módulo gerencia todas as operações de backup:
// - Cópia do banco SQLite
// - Restauração de backup
// - Exportação para JSON
// - Importação de JSON
// ============================================

const fs = require('fs');
const path = require('path');
const Database = require('./db');

class BackupManager {
    constructor() {
        this.db = null;
    }

    /**
     * Inicializa a conexão com o banco de dados
     * @returns {Promise<void>}
     */
    async init() {
        try {
            if (!this.db) {
                this.db = new Database();
                await this.db.init();
            }
        } catch (error) {
            console.error('❌ Erro ao inicializar BackupManager:', error);
            throw error;
        }
    }

    /**
     * Fecha a conexão com o banco
     */
    close() {
        if (this.db) {
            this.db.close();
        }
    }

    /**
     ============================================
     * FUNÇÃO 1: FAZER BACKUP DO BANCO
     * ============================================
     * 1. Executa VACUUM no banco para otimizar
     * 2. Abre diálogo para escolher local
     * 3. Copia o arquivo com nome formatado
     * ============================================
     */
    async criarBackup(destinoPath) {
        try {
            console.log('🔄 Iniciando criação de backup...');
            
            // Inicializar conexão se necessário
            await this.init();

            // === PASSO 1: Executar VACUUM para otimizar o banco ===
            console.log('📦 Executando VACUUM no banco de dados...');
            await this.db.run('VACUUM');
            
            // === PASSO 2: Obter caminho do banco de dados ===
            const bancoPath = this.db.dbPath;
            
            if (!bancoPath || !fs.existsSync(bancoPath)) {
                throw new Error('Arquivo do banco de dados não encontrado');
            }

            // === PASSO 3: Gerar nome do arquivo ===
            const dataAtual = new Date();
            const ano = dataAtual.getFullYear();
            const mes = String(dataAtual.getMonth() + 1).padStart(2, '0');
            const dia = String(dataAtual.getDate()).padStart(2, '0');
            const nomeBackup = `backup-${ano}-${mes}-${dia}.db`;

            // === PASSO 4: Definir caminho completo ===
            const caminhoCompleto = path.join(destinoPath, nomeBackup);

            // === PASSO 5: Copiar o arquivo ===
            console.log(`📋 Copiando banco para: ${caminhoCompleto}`);
            fs.copyFileSync(bancoPath, caminhoCompleto);

            console.log('✅ Backup criado com sucesso!');
            
            return {
                success: true,
                caminho: caminhoCompleto,
                nome: nomeBackup,
                tamanho: fs.statSync(caminhoCompleto).size
            };

        } catch (error) {
            console.error('❌ Erro ao criar backup:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * ============================================
     * FUNÇÃO 2: RESTAURAR BACKUP
     * ============================================
     * 1. Verifica se o arquivo de backup existe
     * 2. Substitui o banco atual
     * 3. Retorna sucesso para reiniciar app
     * ============================================
     */
    async restaurarBackup(backupPath) {
        try {
            console.log('🔄 Iniciando restauração de backup...');

            // === PASSO 1: Validar arquivo de backup ===
            if (!fs.existsSync(backupPath)) {
                throw new Error('Arquivo de backup não encontrado');
            }

            // Verificar se é um arquivo .db válido
            const extensao = path.extname(backupPath).toLowerCase();
            if (extensao !== '.db') {
                throw new Error('Arquivo inválido. Selecione um arquivo .db');
            }

            // === PASSO 2: Inicializar conexão ===
            await this.init();
            
            // === PASSO 3: Fechar conexão atual ===
            console.log('🔒 Fechando conexão atual...');
            this.db.close();
            this.db = null;

            // === PASSO 4: Caminho do banco atual ===
            const tempDb = new Database();
            await tempDb.init();
            const bancoAtualPath = tempDb.dbPath;
            tempDb.close();

            // === PASSO 5: Fazer backup de segurança antes de substituir ===
            const backupSeguranca = bancoAtualPath + '.before_restore';
            console.log(`📋 Criando backup de segurança: ${backupSeguranca}`);
            if (fs.existsSync(bancoAtualPath)) {
                fs.copyFileSync(bancoAtualPath, backupSeguranca);
            }

            // === PASSO 6: Substituir o arquivo ===
            console.log(`📋 Substituindo banco atual por: ${backupPath}`);
            fs.copyFileSync(backupPath, bancoAtualPath);

            console.log('✅ Backup restaurado com sucesso!');
            
            return {
                success: true,
                mensagem: 'Backup restaurado. O sistema será reiniciado.'
            };

        } catch (error) {
            console.error('❌ Erro ao restaurar backup:', error);
            return {
                success: false,
                error: error.message
            };
        } finally {
            this.close();
        }
    }

    /**
     * ============================================
     * FUNÇÃO 3: EXPORTAR PARA JSON
     * ============================================
     * 1. Lê todas as tabelas do banco
     * 2. Converte para JSON
     * 3. Salva arquivo
     * ============================================
     */
    async exportarJSON(destinoPath) {
        try {
            console.log('🔄 Iniciando exportação para JSON...');
            
            await this.init();

            // === PASSO 1: Obter lista de tabelas ===
            const tabelas = [
                'Pecas',
                'Cores', 
                'Funcionarios',
                'Producoes',
                'Movimentacoes',
                'Comprovantes'
            ];

            const dados = {};

            // === PASSO 2: Ler dados de cada tabela ===
            for (const tabela of tabelas) {
                try {
                    console.log(`📊 Lendo tabela: ${tabela}`);
                    const registros = await this.db.all(`SELECT * FROM ${tabela} ORDER BY id`);
                    
                    // Remover informações de data de criação se existirem (opcional)
                    dados[tabela] = registros || [];
                    
                } catch (error) {
                    console.warn(`⚠️ Tabela ${tabela} não encontrada ou vazia:`, error.message);
                    dados[tabela] = [];
                }
            }

            // === PASSO 3: Adicionar metadados ===
            const metadata = {
                versao: '1.0',
                dataExportacao: new Date().toISOString(),
                aplicacao: 'SysCadeiras',
                totalRegistros: Object.values(dados).reduce((acc, arr) => acc + arr.length, 0)
            };

            const jsonCompleto = {
                metadata,
                dados
            };

            // === PASSO 4: Gerar nome do arquivo ===
            const dataAtual = new Date();
            const ano = dataAtual.getFullYear();
            const mes = String(dataAtual.getMonth() + 1).padStart(2, '0');
            const dia = String(dataAtual.getDate()).padStart(2, '0');
            const nomeArquivo = `backup-${ano}-${mes}-${dia}.json`;

            const caminhoCompleto = path.join(destinoPath, nomeArquivo);

            // === PASSO 5: Salvar arquivo JSON ===
            console.log(`📋 Salvando JSON em: ${caminhoCompleto}`);
            fs.writeFileSync(
                caminhoCompleto, 
                JSON.stringify(jsonCompleto, null, 2), 
                'utf8'
            );

            console.log('✅ JSON exportado com sucesso!');
            
            return {
                success: true,
                caminho: caminhoCompleto,
                nome: nomeArquivo,
                totalRegistros: jsonCompleto.metadata.totalRegistros,
                tamanho: fs.statSync(caminhoCompleto).size
            };

        } catch (error) {
            console.error('❌ Erro ao exportar JSON:', error);
            return {
                success: false,
                error: error.message
            };
        } finally {
            this.close();
        }
    }

    /**
     * ============================================
     * FUNÇÃO 4: IMPORTAR JSON
     * ============================================
     * 1. Valida arquivo JSON
     * 2. Confirma substituição
     * 3. Importa dados para o banco
     * ============================================
     */
    async importarJSON(jsonPath, confirmarSubstituicao = false) {
        try {
            console.log('🔄 Iniciando importação de JSON...');

            // === PASSO 1: Validar arquivo ===
            if (!fs.existsSync(jsonPath)) {
                throw new Error('Arquivo JSON não encontrado');
            }

            const extensao = path.extname(jsonPath).toLowerCase();
            if (extensao !== '.json') {
                throw new Error('Arquivo inválido. Selecione um arquivo .json');
            }

            // === PASSO 2: Ler e validar JSON ===
            console.log('📖 Lendo arquivo JSON...');
            const conteudo = fs.readFileSync(jsonPath, 'utf8');
            const dadosImport = JSON.parse(conteudo);

            // Validar estrutura do JSON
            if (!dadosImport.metadata || !dadosImport.dados) {
                throw new Error('Arquivo JSON inválido: formato não reconhecido');
            }

            // === PASSO 3: Confirmar substituição (se necessário) ===
            if (!confirmarSubstituicao) {
                return {
                    success: false,
                    precisaConfirmacao: true,
                    metadata: dadosImport.metadata
                };
            }

            // === PASSO 4: Iniciar transação no banco ===
            await this.init();
            
            console.log('🔄 Iniciando importação dos dados...');
            
            // Desabilitar triggers temporariamente (se necessário)
            // await this.db.run('PRAGMA foreign_keys = OFF');

            // === PASSO 5: Limpar tabelas existentes (opcional - comentado para segurança) ===
            // Nota: Por segurança, não estamos limpando automaticamente
            // O usuário deve confirmar a substituição

            // === PASSO 6: Inserir dados em ordem (respeitando chaves estrangeiras) ===
            const ordemTabelas = [
                'Pecas',
                'Cores',
                'Funcionarios',
                'Producoes',
                'Movimentacoes',
                'Comprovantes'
            ];

            for (const tabela of ordemTabelas) {
                const registros = dadosImport.dados[tabela] || [];
                
                if (registros.length === 0) {
                    console.log(`⏭️ Tabela ${tabela} vazia, pulando...`);
                    continue;
                }

                console.log(`📥 Importando ${registros.length} registros para ${tabela}...`);

                for (const registro of registros) {
                    try {
                        // Construir query dinamicamente baseada nas chaves do registro
                        const colunas = Object.keys(registro).filter(col => col !== 'created_at');
                        const placeholders = colunas.map(() => '?').join(',');
                        const valores = colunas.map(col => registro[col]);

                        const sql = `
                            INSERT OR REPLACE INTO ${tabela} 
                            (${colunas.join(',')}) 
                            VALUES (${placeholders})
                        `;

                        await this.db.run(sql, valores);
                        
                    } catch (error) {
                        console.error(`❌ Erro ao importar registro em ${tabela}:`, error);
                        console.error('Registro:', registro);
                        throw error;
                    }
                }
            }

            // Reabilitar triggers
            // await this.db.run('PRAGMA foreign_keys = ON');

            console.log('✅ JSON importado com sucesso!');

            return {
                success: true,
                mensagem: 'Dados importados com sucesso',
                totalRegistros: dadosImport.metadata.totalRegistros
            };

        } catch (error) {
            console.error('❌ Erro ao importar JSON:', error);
            return {
                success: false,
                error: error.message
            };
        } finally {
            this.close();
        }
    }

    /**
     * ============================================
     * FUNÇÃO AUXILIAR: Obter informações do backup
     * ============================================
     */
    obterInfoBackup(caminho) {
        try {
            if (!fs.existsSync(caminho)) {
                return null;
            }

            const stats = fs.statSync(caminho);
            const nome = path.basename(caminho);
            
            // Tentar extrair data do nome (backup-YYYY-MM-DD.db)
            const match = nome.match(/backup-(\d{4})-(\d{2})-(\d{2})/);
            let dataBackup = null;
            
            if (match) {
                dataBackup = `${match[1]}-${match[2]}-${match[3]}`;
            }

            return {
                nome,
                caminho,
                tamanho: stats.size,
                tamanhoFormatado: this.formatarTamanho(stats.size),
                dataModificacao: stats.mtime,
                dataBackup
            };

        } catch (error) {
            console.error('Erro ao obter info do backup:', error);
            return null;
        }
    }

    /**
     * ============================================
     * FUNÇÃO AUXILIAR: Formatar tamanho de arquivo
     * ============================================
     */
    formatarTamanho(bytes) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
}

module.exports = BackupManager;
const { contextBridge, ipcRenderer } = require('electron');

// Expor APIs seguras para o renderer
contextBridge.exposeInMainWorld('electronAPI', {
  database: {
    init: () => ipcRenderer.invoke('database-init'),
    run: (sql, params) => ipcRenderer.invoke('database-run', sql, params),
    get: (sql, params) => ipcRenderer.invoke('database-get', sql, params),
    all: (sql, params) => ipcRenderer.invoke('database-all', sql, params),
    migrate: () => ipcRenderer.invoke('database-migrate'),
    
    // Novas funções de pesquisa
    invoke: (method, params) => ipcRenderer.invoke(`database-${method}`, params)
  },
  
  fileSystem: {
    saveDocument: (content, defaultName, fileType) => 
      ipcRenderer.invoke('save-document', content, defaultName, fileType),
    
    saveMultipleFiles: (files) => 
      ipcRenderer.invoke('save-multiple-files', files),
    
    checkDirectory: (dirPath) =>
      ipcRenderer.invoke('check-directory', dirPath),
    
    listFiles: (dirPath) =>
      ipcRenderer.invoke('list-files', dirPath)
  },
  
  // ============================================
  // NOVAS APIs DE BACKUP
  // ============================================
  backup: {
    criar: (destinoPath) => ipcRenderer.invoke('backup-criar', destinoPath),
    restaurar: (backupPath) => ipcRenderer.invoke('backup-restaurar', backupPath),
    exportarJSON: (destinoPath) => ipcRenderer.invoke('backup-exportar-json', destinoPath),
    importarJSON: (jsonPath, confirmado) => ipcRenderer.invoke('backup-importar-json', jsonPath, confirmado),
    selecionarPasta: () => ipcRenderer.invoke('selecionar-pasta'),
    selecionarArquivo: (filtros) => ipcRenderer.invoke('selecionar-arquivo', filtros)
  },
  
  // Utilitários
  showNotification: (title, body) => {
    ipcRenderer.send('show-notification', { title, body });
  }
});

// Expor versão do app
contextBridge.exposeInMainWorld('appInfo', {
  version: '1.2.0',
  name: 'SysCadeiras',
  isElectron: true
});
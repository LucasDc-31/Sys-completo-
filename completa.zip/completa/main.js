const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const Database = require('./db');

// Variável global para a janela principal
let mainWindow;
let database;

// Criar a janela principal
function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1400,
        height: 900,
        webPreferences: {
            nodeIntegration: false,
            contextIsolation: true,
            preload: path.join(__dirname, 'preload.js')
        },
        icon: path.join(__dirname, 'icon.png'),
        show: false
    });

    // Carregar o arquivo HTML
    mainWindow.loadFile('index.html');

    // Mostrar a janela quando estiver pronta
    mainWindow.once('ready-to-show', () => {
        mainWindow.show();
        
        // Abrir DevTools em desenvolvimento
        if (process.argv.includes('--dev')) {
            mainWindow.webContents.openDevTools();
        }
    });

    // Evento de fechamento
    mainWindow.on('closed', () => {
        mainWindow = null;
    });
}

// Quando o app estiver pronto
app.whenReady().then(() => {
    createWindow();

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });
});

// Fechar o app quando todas as janelas forem fechadas
app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

// ======= HANDLERS DO BANCO DE DADOS =======
ipcMain.handle('database-init', async () => {
    try {
        if (!database) {
            database = new Database();
        }
        await database.init();
        return { success: true };
    } catch (error) {
        console.error('Erro ao inicializar banco:', error);
        return { success: false, error: error.message };
    }
});

ipcMain.handle('database-run', async (event, sql, params = []) => {
    try {
        if (!database) {
            database = new Database();
            await database.init();
        }
        const result = await database.run(sql, params);
        return { success: true, result };
    } catch (error) {
        console.error('Erro no database-run:', error);
        return { success: false, error: error.message };
    }
});

ipcMain.handle('database-get', async (event, sql, params = []) => {
    try {
        if (!database) {
            database = new Database();
            await database.init();
        }
        const result = await database.get(sql, params);
        return { success: true, result };
    } catch (error) {
        console.error('Erro no database-get:', error);
        return { success: false, error: error.message };
    }
});

ipcMain.handle('database-all', async (event, sql, params = []) => {
    try {
        if (!database) {
            database = new Database();
            await database.init();
        }
        const result = await database.all(sql, params);
        return { success: true, result };
    } catch (error) {
        console.error('Erro no database-all:', error);
        return { success: false, error: error.message };
    }
});

ipcMain.handle('database-migrate', async () => {
    try {
        const migrarBancoDados = require('./migrate.js');
        const resultado = await migrarBancoDados();
        return { success: resultado };
    } catch (error) {
        console.error('Erro na migração:', error);
        return { success: false, error: error.message };
    }
});

// ======= NOVOS HANDLERS DE PESQUISA =======
ipcMain.handle('database-pesquisar-movimentacoes', async (event, filtros) => {
    try {
        if (!database) {
            database = new Database();
            await database.init();
        }
        const result = await database.pesquisarMovimentacoes(filtros);
        return { success: true, result };
    } catch (error) {
        console.error('Erro ao pesquisar movimentações:', error);
        return { success: false, error: error.message };
    }
});

ipcMain.handle('database-calcular-saldo-estoque', async (event, pecaId, corId) => {
    try {
        if (!database) {
            database = new Database();
            await database.init();
        }
        const result = await database.calcularSaldoEstoque(pecaId, corId);
        return { success: true, result };
    } catch (error) {
        console.error('Erro ao calcular saldo:', error);
        return { success: false, error: error.message };
    }
});

ipcMain.handle('database-pesquisar-producoes', async (event, filtros) => {
    try {
        if (!database) {
            database = new Database();
            await database.init();
        }
        const result = await database.pesquisarProducoes(filtros);
        return { success: true, result };
    } catch (error) {
        console.error('Erro ao pesquisar produções:', error);
        return { success: false, error: error.message };
    }
});

ipcMain.handle('database-get-estatisticas-estoque', async () => {
    try {
        if (!database) {
            database = new Database();
            await database.init();
        }
        const result = await database.getEstatisticasEstoque();
        return { success: true, result };
    } catch (error) {
        console.error('Erro ao obter estatísticas:', error);
        return { success: false, error: error.message };
    }
});

// ======= HANDLERS DO SISTEMA DE ARQUIVOS =======
ipcMain.handle('save-document', async (event, content, defaultName, fileType) => {
    try {
        const { canceled, filePath } = await dialog.showSaveDialog(mainWindow, {
            title: 'Salvar Documento',
            defaultPath: path.join(app.getPath('documents'), defaultName),
            filters: [
                { name: 'Documentos', extensions: fileType === 'txt' ? ['txt'] : ['html'] },
                { name: 'Todos os Arquivos', extensions: ['*'] }
            ],
            properties: ['showOverwriteConfirmation']
        });

        if (!canceled && filePath) {
            // Garantir que o diretório existe
            const dir = path.dirname(filePath);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }

            fs.writeFileSync(filePath, content, 'utf8');
            return { success: true, path: filePath };
        }
        return { success: false, canceled: true };
    } catch (error) {
        console.error('Erro ao salvar documento:', error);
        return { success: false, error: error.message };
    }
});

ipcMain.handle('save-multiple-files', async (event, files) => {
    try {
        const { canceled, filePaths } = await dialog.showOpenDialog(mainWindow, {
            title: 'Selecionar Pasta para Salvar Arquivos',
            properties: ['openDirectory', 'createDirectory', 'promptToCreate']
        });

        if (!canceled && filePaths && filePaths.length > 0) {
            const basePath = filePaths[0];
            const results = [];
            const errors = [];

            // Criar subpasta com timestamp
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const savePath = path.join(basePath, `SysCadeiras_${timestamp}`);
            
            if (!fs.existsSync(savePath)) {
                fs.mkdirSync(savePath, { recursive: true });
            }

            for (const file of files) {
                try {
                    const filePath = path.join(savePath, file.name);
                    fs.writeFileSync(filePath, file.content, 'utf8');
                    results.push({ 
                        name: file.name, 
                        path: filePath, 
                        success: true 
                    });
                } catch (error) {
                    errors.push({ 
                        name: file.name, 
                        error: error.message 
                    });
                    results.push({ 
                        name: file.name, 
                        success: false, 
                        error: error.message 
                    });
                }
            }

            return { 
                success: true, 
                basePath: savePath, 
                results,
                errors: errors.length > 0 ? errors : null
            };
        }
        return { success: false, canceled: true };
    } catch (error) {
        console.error('Erro ao salvar múltiplos arquivos:', error);
        return { success: false, error: error.message };
    }
});

// Handler para verificar se diretório existe
ipcMain.handle('check-directory', async (event, dirPath) => {
    try {
        const exists = fs.existsSync(dirPath);
        return { success: true, exists };
    } catch (error) {
        return { success: false, error: error.message };
    }
});

// Handler para listar arquivos em um diretório
ipcMain.handle('list-files', async (event, dirPath) => {
    try {
        if (!fs.existsSync(dirPath)) {
            return { success: false, error: 'Diretório não existe' };
        }
        const files = fs.readdirSync(dirPath);
        return { success: true, files };
    } catch (error) {
        return { success: false, error: error.message };
    }
});

// ============================================
// HANDLERS DO SISTEMA DE BACKUP
// ============================================

// Handler para criar backup do banco
ipcMain.handle('backup-criar', async (event, destinoPath) => {
    try {
        console.log('📦 Recebida solicitação de backup...');
        
        const BackupManager = require('./backupManager');
        const backupManager = new BackupManager();
        
        const resultado = await backupManager.criarBackup(destinoPath);
        
        return resultado;
        
    } catch (error) {
        console.error('❌ Erro no handler backup-criar:', error);
        return { success: false, error: error.message };
    }
});

// Handler para restaurar backup
ipcMain.handle('backup-restaurar', async (event, backupPath) => {
    try {
        console.log('📦 Recebida solicitação de restauração...');
        
        const BackupManager = require('./backupManager');
        const backupManager = new BackupManager();
        
        const resultado = await backupManager.restaurarBackup(backupPath);
        
        // Se sucesso, agendar reinicialização
        if (resultado.success) {
            setTimeout(() => {
                console.log('🔄 Reiniciando aplicação após restauração...');
                app.relaunch();
                app.exit();
            }, 2000);
        }
        
        return resultado;
        
    } catch (error) {
        console.error('❌ Erro no handler backup-restaurar:', error);
        return { success: false, error: error.message };
    }
});

// Handler para exportar JSON
ipcMain.handle('backup-exportar-json', async (event, destinoPath) => {
    try {
        console.log('📦 Recebida solicitação de exportação JSON...');
        
        const BackupManager = require('./backupManager');
        const backupManager = new BackupManager();
        
        const resultado = await backupManager.exportarJSON(destinoPath);
        
        return resultado;
        
    } catch (error) {
        console.error('❌ Erro no handler backup-exportar-json:', error);
        return { success: false, error: error.message };
    }
});

// Handler para importar JSON
ipcMain.handle('backup-importar-json', async (event, jsonPath, confirmado) => {
    try {
        console.log('📦 Recebida solicitação de importação JSON...');
        
        const BackupManager = require('./backupManager');
        const backupManager = new BackupManager();
        
        const resultado = await backupManager.importarJSON(jsonPath, confirmado);
        
        return resultado;
        
    } catch (error) {
        console.error('❌ Erro no handler backup-importar-json:', error);
        return { success: false, error: error.message };
    }
});

// Handler para selecionar pasta
ipcMain.handle('selecionar-pasta', async () => {
    try {
        const { canceled, filePaths } = await dialog.showOpenDialog(mainWindow, {
            title: 'Selecionar Pasta para Salvar Backup',
            properties: ['openDirectory', 'createDirectory']
        });

        if (!canceled && filePaths.length > 0) {
            return { success: true, path: filePaths[0] };
        }
        
        return { success: false, canceled: true };
        
    } catch (error) {
        return { success: false, error: error.message };
    }
});

// Handler para selecionar arquivo
ipcMain.handle('selecionar-arquivo', async (event, filtros) => {
    try {
        const { canceled, filePaths } = await dialog.showOpenDialog(mainWindow, {
            title: 'Selecionar Arquivo de Backup',
            filters: filtros || [
                { name: 'Arquivos de Backup', extensions: ['db', 'json'] },
                { name: 'Todos os Arquivos', extensions: ['*'] }
            ],
            properties: ['openFile']
        });

        if (!canceled && filePaths.length > 0) {
            return { success: true, path: filePaths[0] };
        }
        
        return { success: false, canceled: true };
        
    } catch (error) {
        return { success: false, error: error.message };
    }
});
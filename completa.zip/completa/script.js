        // ============================================
        // ESTADO GLOBAL
        // ============================================
        let producoes = [];
        let pecas = [];
        let funcionarios = [];
        let cores = [];
        let movimentacoes = [];
        
        let tipoRelatorioAtual = 'geral';
        let deferredPrompt;
        let producoesSelecionadas = new Set();
        let timeoutPesquisa = null;
        
        // Variáveis globais para os gráficos
        let entradaSaidaChart = null;
        let topItensChart = null;
        let movimentacoesPorDiaChart = null;
        let producaoFuncionariosChart = null;

        // ============================================
        // GERENCIADOR CENTRAL DE FORMULÁRIOS
        // ============================================
        const FormManager = {
            // Configuração dos formulários
            forms: {
                producao: {
                    id: 'formProducao',
                    hiddenId: 'producaoId',
                    btnSalvar: 'btnSalvarProducao',
                    btnCancelar: 'btnCancelarEdicao',
                    defaults: {
                        dataProducao: () => hojeISO(),
                        funcionarioProducao: '',
                        horaExtra: false
                    },
                    onReset: function() {
                        const container = document.getElementById('itensProducao');
                        if (container) {
                            container.innerHTML = `
                                <div class="itemProducao" data-index="0">
                                    <div class="form-row">
                                        <label for="pecaProducao">🪑 Modelo:</label>
                                        <select id="pecaProducao" class="peca-select" required>
                                            <option value="">Selecione um modelo</option>
                                            ${pecas.map(p => `<option value="${p.id}">${p.nome}</option>`).join('')}
                                        </select>
                                    </div>
                                    <div class="form-row">
                                        <label for="corProducao">🎨 Cor:</label>
                                        <select id="corProducao" class="cor-select" required>
                                            <option value="">Selecione uma cor</option>
                                            ${cores.map(c => `<option value="${c.id}">${c.nome}</option>`).join('')}
                                        </select>
                                    </div>
                                    <div class="form-row">
                                        <label for="quantidade">📊 Quantidade:</label>
                                        <input type="number" class="quantidade" id="quantidade" min="1" required>
                                    </div>
                                    <div class="form-row">
                                        <label for="horaExtra">⏰ Hora Extra (+50%):</label>
                                        <input type="checkbox" class="hora-extra-checkbox" id="horaExtra">
                                    </div>
                                </div>
                            `;
                        }
                    }
                },
                peca: {
                    id: 'formPeca',
                    hiddenId: 'pecaId',
                    btnSalvar: 'btnSalvarPeca',
                    btnCancelar: 'btnCancelarEdicaoPeca',
                    defaults: {
                        nomePeca: '',
                        valorPeca: ''
                    },
                    onReset: function() {
                        document.getElementById('nomePeca').value = '';
                        document.getElementById('valorPeca').value = '';
                    }
                },
                funcionario: {
                    id: 'formFuncionario',
                    hiddenId: 'funcionarioId',
                    btnSalvar: 'btnSalvarFuncionario',
                    btnCancelar: 'btnCancelarEdicaoFuncionario',
                    defaults: {
                        nomeFuncionario: '',
                        cargoFuncionario: ''
                    },
                    onReset: function() {
                        document.getElementById('nomeFuncionario').value = '';
                        document.getElementById('cargoFuncionario').value = '';
                    }
                },
                cor: {
                    id: 'formCor',
                    hiddenId: 'corId',
                    btnSalvar: 'btnSalvarCor',
                    btnCancelar: 'btnCancelarEdicaoCor',
                    defaults: {
                        nomeCor: ''
                    },
                    onReset: function() {
                        document.getElementById('nomeCor').value = '';
                    }
                },
                saida: {
                    id: 'formSaida',
                    hiddenId: 'saidaId',
                    btnSalvar: 'btnSalvarSaida',
                    btnCancelar: 'btnCancelarSaida',
                    defaults: {
                        dataSaida: () => hojeISO(),
                        pecaSaida: '',
                        corSaida: '',
                        qtdSaida: '',
                        obsSaida: ''
                    },
                    onReset: function() {
                        document.getElementById('dataSaida').value = hojeISO();
                        document.getElementById('pecaSaida').value = '';
                        document.getElementById('corSaida').value = '';
                        document.getElementById('qtdSaida').value = '';
                        document.getElementById('obsSaida').value = '';
                    }
                }
            },

            // Estado de edição atual
            editingState: {
                formName: null,
                id: null
            },

            /**
             * Inicializa todos os formulários com event listeners
             */
            init() {
                for (const [name, config] of Object.entries(this.forms)) {
                    const form = document.getElementById(config.id);
                    if (form) {
                        form.addEventListener('submit', (e) => this.handleSubmit(e, name));
                    }
                }

                document.addEventListener('click', (e) => {
                    const editBtn = e.target.closest('.btn-editar');
                    if (editBtn) {
                        e.preventDefault();
                        const handler = editBtn.getAttribute('data-edit-handler');
                        if (handler && typeof window[handler] === 'function') {
                            window[handler](parseInt(editBtn.getAttribute('data-id')));
                        }
                    }
                });

                console.log('✅ FormManager inicializado');
            },

            /**
             * Handler central de submit de formulários
             */
            async handleSubmit(e, formName) {
                e.preventDefault();
                
                const config = this.forms[formName];
                if (!config) return;

                try {
                    if (formName === 'producao') await this.salvarProducao();
                    else if (formName === 'peca') await this.salvarPeca();
                    else if (formName === 'funcionario') await this.salvarFuncionario();
                    else if (formName === 'cor') await this.salvarCor();
                    else if (formName === 'saida') await this.salvarSaida();
                    
                    this.resetForm(formName);
                    
                } catch (error) {
                    console.error(`❌ Erro ao salvar ${formName}:`, error);
                    alert(`❌ Erro ao salvar: ${error.message}`);
                }
            },

            /**
             * Preenche formulário para edição
             */
            fillForEdit(formName, data) {
                const config = this.forms[formName];
                if (!config) return;

                if (config.hiddenId && data.id) {
                    document.getElementById(config.hiddenId).value = data.id;
                }

                for (const [field, value] of Object.entries(data)) {
                    const element = document.getElementById(field);
                    if (element) {
                        if (element.type === 'checkbox') {
                            element.checked = !!value;
                        } else {
                            element.value = value ?? '';
                        }
                    }
                }

                this.setEditingMode(formName, true);
                
                if (config.onEdit) {
                    config.onEdit(data);
                }
            },

            /**
             * Reseta formulário para estado padrão
             */
            resetForm(formName) {
                const config = this.forms[formName];
                if (!config) return;

                if (config.hiddenId) {
                    document.getElementById(config.hiddenId).value = '';
                }

                for (const [field, defaultValue] of Object.entries(config.defaults)) {
                    const element = document.getElementById(field);
                    if (element) {
                        const value = typeof defaultValue === 'function' ? defaultValue() : defaultValue;
                        if (element.type === 'checkbox') {
                            element.checked = value;
                        } else {
                            element.value = value;
                        }
                    }
                }

                if (config.onReset) {
                    config.onReset();
                }

                this.setEditingMode(formName, false);
            },

            /**
             * Alterna entre modo de edição e criação
             */
            setEditingMode(formName, isEditing) {
                const config = this.forms[formName];
                if (!config) return;

                const btnSalvar = document.getElementById(config.btnSalvar);
                if (btnSalvar) {
                    btnSalvar.textContent = isEditing ? '✏️ Atualizar' : '💾 Salvar';
                }

                const btnCancelar = document.getElementById(config.btnCancelar);
                if (btnCancelar) {
                    btnCancelar.style.display = isEditing ? 'inline-block' : 'none';
                }

                if (isEditing) {
                    this.editingState.formName = formName;
                    this.editingState.id = document.getElementById(config.hiddenId)?.value;
                } else {
                    this.editingState.formName = null;
                    this.editingState.id = null;
                }
            },

            /**
             * Cancela edição atual
             */
            cancelEditing(formName) {
                this.resetForm(formName);
            },

            // ===== MÉTODOS ESPECÍFICOS DE SALVAMENTO =====

            async salvarPeca() {
                const id = document.getElementById('pecaId').value;
                const nome = document.getElementById('nomePeca').value.trim();
                const valor = parseFloat(document.getElementById('valorPeca').value);

                if (!nome || isNaN(valor) || valor <= 0) {
                    throw new Error('Preencha todos os campos corretamente');
                }

                if (id) {
                    await window.electronAPI.database.run(
                        'UPDATE Pecas SET nome=?, valor=? WHERE id=?',
                        [nome, valor, id]
                    );
                } else {
                    await window.electronAPI.database.run(
                        'INSERT INTO Pecas (nome, valor) VALUES (?, ?)',
                        [nome, valor]
                    );
                }

                await DataManager.refreshData();
            },

            async salvarFuncionario() {
                const id = document.getElementById('funcionarioId').value;
                const nome = document.getElementById('nomeFuncionario').value.trim();
                const cargo = document.getElementById('cargoFuncionario').value.trim();

                if (!nome || !cargo) throw new Error('Preencha todos os campos');

                if (id) {
                    await window.electronAPI.database.run(
                        'UPDATE Funcionarios SET nome=?, cargo=? WHERE id=?',
                        [nome, cargo, id]
                    );
                } else {
                    await window.electronAPI.database.run(
                        'INSERT INTO Funcionarios (nome, cargo) VALUES (?, ?)',
                        [nome, cargo]
                    );
                }

                await DataManager.refreshData();
            },

            async salvarCor() {
                const id = document.getElementById('corId').value;
                const nome = document.getElementById('nomeCor').value.trim();

                if (!nome) throw new Error('Informe o nome da cor');

                if (id) {
                    await window.electronAPI.database.run(
                        'UPDATE Cores SET nome=? WHERE id=?',
                        [nome, id]
                    );
                } else {
                    await window.electronAPI.database.run(
                        'INSERT INTO Cores (nome) VALUES (?)',
                        [nome]
                    );
                }

                await DataManager.refreshData();
            },

            async salvarSaida() {
                const id = document.getElementById('saidaId').value;
                const data = document.getElementById('dataSaida').value;
                const pecaId = parseInt(document.getElementById('pecaSaida').value);
                const corId = parseInt(document.getElementById('corSaida').value);
                const quantidade = parseInt(document.getElementById('qtdSaida').value);
                const obs = document.getElementById('obsSaida').value.trim();

                if (!pecaId || !corId || !quantidade) {
                    throw new Error('Preencha todos os campos obrigatórios');
                }

                const saldo = calcularSaldo(pecaId, corId);
                if (saldo < quantidade) {
                    const faltam = quantidade - saldo;
                    if (!confirm(`⚠️ Saldo insuficiente!\nSaldo: ${saldo}\nFaltam: ${faltam}\nRegistrar mesmo assim?`)) {
                        return;
                    }
                }

                if (id) {
                    await window.electronAPI.database.run(
                        'UPDATE Movimentacoes SET data=?, pecaId=?, corId=?, quantidade=?, origem=? WHERE id=?',
                        [data, pecaId, corId, quantidade, obs, id]
                    );
                } else {
                    await window.electronAPI.database.run(
                        'INSERT INTO Movimentacoes (data, tipo, pecaId, corId, quantidade, origem) VALUES (?, ?, ?, ?, ?, ?)',
                        [data, 'saida', pecaId, corId, quantidade, obs]
                    );
                }

                await DataManager.refreshData();

                const novoSaldo = calcularSaldo(pecaId, corId);
                if (novoSaldo < 0) {
                    alert('⚠️ Estoque ficou negativo!');
                }
            },

            async salvarProducao() {
                const id = document.getElementById('producaoId').value;
                const data = document.getElementById('dataProducao').value;
                const funcionarioId = parseInt(document.getElementById('funcionarioProducao').value);

                if (!funcionarioId) throw new Error('Selecione um funcionário');

                const itens = this.coletarItensProducao();
                if (itens.length === 0) throw new Error('Adicione pelo menos um item');

                for (const item of itens) {
                    let producaoId;
                    if (id) {
                        await window.electronAPI.database.run(
                            'UPDATE Producoes SET data=?, funcionarioId=?, pecaId=?, corId=?, quantidade=?, horaExtra=? WHERE id=?',
                            [data, funcionarioId, item.pecaId, item.corId, item.quantidade, item.horaExtra ? 1 : 0, id]
                        );
                        producaoId = id;
                    } else {
                        const result = await window.electronAPI.database.run(
                            'INSERT INTO Producoes (data, funcionarioId, pecaId, corId, quantidade, horaExtra) VALUES (?, ?, ?, ?, ?, ?)',
                            [data, funcionarioId, item.pecaId, item.corId, item.quantidade, item.horaExtra ? 1 : 0]
                        );
                        producaoId = result.result.id;
                    }

                    await window.electronAPI.database.run(
                        'INSERT INTO Movimentacoes (data, tipo, pecaId, corId, quantidade, origem, producaoId, funcionarioId) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                        [data, 'entrada', item.pecaId, item.corId, item.quantidade, 'Produção', producaoId, funcionarioId]
                    );
                }

                await DataManager.refreshData();
            },

            coletarItensProducao() {
                const itens = [];
                const itensElements = document.querySelectorAll('.itemProducao');

                itensElements.forEach((item, index) => {
                    let pecaId, corId, quantidade, horaExtra;

                    if (index === 0) {
                        pecaId = parseInt(item.querySelector('#pecaProducao, .peca-select')?.value);
                        corId = parseInt(item.querySelector('#corProducao, .cor-select')?.value);
                        quantidade = parseInt(item.querySelector('.quantidade, #quantidade')?.value);
                        horaExtra = item.querySelector('.hora-extra-checkbox, #horaExtra')?.checked || false;
                    } else {
                        pecaId = parseInt(item.querySelector('.peca-item')?.value);
                        corId = parseInt(item.querySelector('.cor-item')?.value);
                        quantidade = parseInt(item.querySelector('.quantidade-item')?.value);
                        horaExtra = item.querySelector('.hora-extra-item')?.checked || false;
                    }

                    if (pecaId && corId && quantidade) {
                        itens.push({ pecaId, corId, quantidade, horaExtra });
                    }
                });

                return itens;
            }
        };

        // ============================================
        // GERENCIADOR CENTRAL DE DADOS
        // ============================================
        const DataManager = {
            /**
             * Recarrega todos os dados do banco e atualiza interface
             */
            async refreshData() {
                try {
                    console.log('🔄 Recarregando dados...');

                    await this.loadDataFromDB();

                    UIManager.refreshAllSelects();
                    UIManager.refreshAllTables();

                    console.log('✅ Dados atualizados');
                } catch (error) {
                    console.error('❌ Erro ao recarregar dados:', error);
                }
            },

            /**
             * Carrega dados do banco para os arrays em memória
             */
            async loadDataFromDB() {
                try {
                    const pecasResult = await window.electronAPI.database.all('SELECT * FROM Pecas ORDER BY nome');
                    pecas = pecasResult.success ? pecasResult.result : [];

                    const coresResult = await window.electronAPI.database.all('SELECT * FROM Cores ORDER BY nome');
                    cores = coresResult.success ? coresResult.result : [];

                    const funcResult = await window.electronAPI.database.all('SELECT * FROM Funcionarios ORDER BY nome');
                    funcionarios = funcResult.success ? funcResult.result : [];

                    const prodResult = await window.electronAPI.database.all('SELECT * FROM Producoes ORDER BY data DESC');
                    producoes = prodResult.success ? prodResult.result : [];

                    const movResult = await window.electronAPI.database.all('SELECT * FROM Movimentacoes ORDER BY data DESC');
                    movimentacoes = movResult.success ? movResult.result : [];

                    console.log('✅ Dados carregados:', {
                        pecas: pecas.length,
                        cores: cores.length,
                        funcionarios: funcionarios.length,
                        producoes: producoes.length,
                        movimentacoes: movimentacoes.length
                    });
                } catch (error) {
                    console.error('❌ Erro ao carregar dados:', error);
                    throw error;
                }
            },

            /**
             * Busca um registro específico
             */
            findById(array, id) {
                return array.find(item => item.id === parseInt(id));
            }
        };

        // ============================================
        // GERENCIADOR CENTRAL DA INTERFACE
        // ============================================
        const UIManager = {
            /**
             * Atualiza todos os selects da aplicação
             */
            refreshAllSelects() {
                console.log('🔄 Atualizando todos os selects...');

                this.refreshSelect('funcionarioProducao', funcionarios, 'Selecione um funcionário');
                
                document.querySelectorAll('.itemProducao').forEach((item, index) => {
                    if (index === 0) {
                        const selectPeca = item.querySelector('#pecaProducao, .peca-select');
                        if (selectPeca) this.refreshSelectElement(selectPeca, pecas, 'Selecione um modelo');
                        
                        const selectCor = item.querySelector('#corProducao, .cor-select');
                        if (selectCor) this.refreshSelectElement(selectCor, cores, 'Selecione uma cor');
                    } else {
                        const selectPeca = item.querySelector('.peca-item');
                        if (selectPeca) this.refreshSelectElement(selectPeca, pecas, 'Selecione um modelo');
                        
                        const selectCor = item.querySelector('.cor-item');
                        if (selectCor) this.refreshSelectElement(selectCor, cores, 'Selecione uma cor');
                    }
                });

                this.refreshSelect('pecaSaida', pecas, 'Selecione um modelo');
                this.refreshSelect('corSaida', cores, 'Selecione uma cor');

                this.refreshSelect('filtroFuncionario', funcionarios, 'Todos', true);
                this.refreshSelect('filtroPeca', pecas, 'Todos', true);
                this.refreshSelect('filtroCor', cores, 'Todos', true);
                this.refreshSelect('pecaEst', pecas, 'Todos', true);
                this.refreshSelect('corEst', cores, 'Todos', true);

                this.refreshSelect('filtroPecaEstoque', pecas, 'Todas as peças', true);
                this.refreshSelect('filtroCorEstoque', cores, 'Todas as cores', true);
            },

            /**
             * Atualiza um select específico pelo ID
             */
            refreshSelect(selectId, data, placeholder, includeAll = false) {
                const select = document.getElementById(selectId);
                if (!select) return;

                const currentValue = select.value;
                this.refreshSelectElement(select, data, placeholder, includeAll);

                if (currentValue && Array.from(select.options).some(opt => opt.value == currentValue)) {
                    select.value = currentValue;
                }
            },

            /**
             * Atualiza um elemento select
             */
            refreshSelectElement(select, data, placeholder, includeAll = false) {
                if (!select) return;

                const currentValue = select.value;
                select.innerHTML = '';

                const optionPlaceholder = document.createElement('option');
                optionPlaceholder.value = '';
                optionPlaceholder.textContent = placeholder;
                select.appendChild(optionPlaceholder);

                data.forEach(item => {
                    const option = document.createElement('option');
                    option.value = item.id;
                    option.textContent = item.nome;
                    select.appendChild(option);
                });

                if (currentValue && Array.from(select.options).some(opt => opt.value == currentValue)) {
                    select.value = currentValue;
                }
            },

            /**
             * Atualiza todas as tabelas da aplicação
             */
            refreshAllTables() {
                this.refreshProducaoTable();
                this.refreshPecasTable();
                this.refreshFuncionariosTable();
                this.refreshCoresTable();
                this.refreshSaldosTable();
            },

            refreshProducaoTable() {
                const tbody = document.querySelector('#tabelaProducao tbody');
                if (!tbody) return;

                tbody.innerHTML = '';
                const hoje = hojeISO();
                const producaoHoje = producoes.filter(p => p.data === hoje);

                if (producaoHoje.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="9" class="text-center" style="padding: 40px;">📭 Nenhuma produção registrada hoje</td></tr>';
                    return;
                }

                producaoHoje.forEach(producao => {
                    const funcionario = DataManager.findById(funcionarios, producao.funcionarioId);
                    const peca = DataManager.findById(pecas, producao.pecaId);
                    const cor = DataManager.findById(cores, producao.corId);

                    let valorUnitario = peca ? peca.valor : 0;
                    let valorTotal = valorUnitario * producao.quantidade;

                    if (producao.horaExtra) {
                        valorUnitario = valorUnitario * 1.5;
                        valorTotal = valorUnitario * producao.quantidade;
                    }

                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${formatarData(producao.data)}</td>
                        <td>${funcionario ? funcionario.nome : 'N/A'}</td>
                        <td>${peca ? peca.nome : 'N/A'}</td>
                        <td>${cor ? cor.nome : 'N/A'}</td>
                        <td>${producao.quantidade}</td>
                        <td>${producao.horaExtra ? '<span class="badge-tipo badge-pedido">SIM</span>' : 'Não'}</td>
                        <td class="valor">${formatarMoeda(valorUnitario)}</td>
                        <td class="valor">${formatarMoeda(valorTotal)}</td>
                        <td class="actions">
                            <button class="btn-editar" data-edit-handler="editarProducao" data-id="${producao.id}">✏️</button>
                            <button class="btn-excluir" onclick="excluirProducao(${producao.id})">🗑️</button>
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            },

            refreshPecasTable() {
                const tbody = document.querySelector('#tabelaPecas tbody');
                if (!tbody) return;

                tbody.innerHTML = '';

                if (pecas.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="3" class="text-center" style="padding: 40px;">📭 Nenhuma peça cadastrada</td></tr>';
                    return;
                }

                pecas.forEach(peca => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${peca.nome}</td>
                        <td class="valor">${formatarMoeda(peca.valor)}</td>
                        <td class="actions">
                            <button class="btn-editar" data-edit-handler="editarPeca" data-id="${peca.id}">✏️</button>
                            <button class="btn-excluir" onclick="excluirPeca(${peca.id})">🗑️</button>
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            },

            refreshFuncionariosTable() {
                const tbody = document.querySelector('#tabelaFuncionarios tbody');
                if (!tbody) return;

                tbody.innerHTML = '';

                if (funcionarios.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="3" class="text-center" style="padding: 40px;">📭 Nenhum funcionário cadastrado</td></tr>';
                    return;
                }

                funcionarios.forEach(funcionario => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${funcionario.nome}</td>
                        <td>${funcionario.cargo}</td>
                        <td class="actions">
                            <button class="btn-editar" data-edit-handler="editarFuncionario" data-id="${funcionario.id}">✏️</button>
                            <button class="btn-excluir" onclick="excluirFuncionario(${funcionario.id})">🗑️</button>
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            },

            refreshCoresTable() {
                const tbody = document.querySelector('#tabelaCores tbody');
                if (!tbody) return;

                tbody.innerHTML = '';

                if (cores.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="2" class="text-center" style="padding: 40px;">📭 Nenhuma cor cadastrada</td></tr>';
                    return;
                }

                cores.forEach(cor => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${cor.nome}</td>
                        <td class="actions">
                            <button class="btn-editar" data-edit-handler="editarCor" data-id="${cor.id}">✏️</button>
                            <button class="btn-excluir" onclick="excluirCor(${cor.id})">🗑️</button>
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            },

            refreshSaldosTable() {
                const tbody = document.querySelector('#tabelaSaldos tbody');
                if (!tbody) return;

                const saldosArray = this.calcularSaldos();

                saldosArray.sort((a, b) => {
                    const pecaA = DataManager.findById(pecas, a.pecaId);
                    const pecaB = DataManager.findById(pecas, b.pecaId);
                    const corA = DataManager.findById(cores, a.corId);
                    const corB = DataManager.findById(cores, b.corId);

                    if (!pecaA || !pecaB) return 0;
                    if (pecaA.nome < pecaB.nome) return -1;
                    if (pecaA.nome > pecaB.nome) return 1;

                    const nomeCorA = corA ? corA.nome : '';
                    const nomeCorB = corB ? corB.nome : '';
                    return nomeCorA.localeCompare(nomeCorB);
                });

                tbody.innerHTML = '';

                if (saldosArray.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="3" class="text-center" style="padding: 40px;">📭 Nenhum saldo calculado</td></tr>';
                    return;
                }

                saldosArray.forEach(s => {
                    const peca = DataManager.findById(pecas, s.pecaId);
                    const cor = DataManager.findById(cores, s.corId);
                    if (!peca) return;

                    let classeSaldo = 'saldo-ok';
                    if (s.saldo < 0) classeSaldo = 'saldo-negativo';
                    else if (s.saldo < 5) classeSaldo = 'saldo-critico';
                    else if (s.saldo < 10) classeSaldo = 'saldo-alerta';

                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${peca.nome}</td>
                        <td>${cor ? cor.nome : 'Sem cor'}</td>
                        <td class="${classeSaldo}">${s.saldo}</td>
                    `;
                    tbody.appendChild(tr);
                });
            },

            calcularSaldos() {
                const saldos = {};

                movimentacoes.forEach(mov => {
                    const key = `${mov.pecaId}-${mov.corId}`;
                    if (!saldos[key]) {
                        saldos[key] = { pecaId: mov.pecaId, corId: mov.corId, saldo: 0 };
                    }
                    saldos[key].saldo += mov.tipo === 'entrada' ? mov.quantidade : -mov.quantidade;
                });

                return Object.values(saldos);
            }
        };

        // ============================================
        // FUNÇÕES DE EDIÇÃO
        // ============================================

        function editarPeca(id) {
            const peca = DataManager.findById(pecas, id);
            if (!peca) return;
            
            FormManager.fillForEdit('peca', {
                pecaId: peca.id,
                nomePeca: peca.nome,
                valorPeca: peca.valor
            });
        }

        function editarFuncionario(id) {
            const funcionario = DataManager.findById(funcionarios, id);
            if (!funcionario) return;
            
            FormManager.fillForEdit('funcionario', {
                funcionarioId: funcionario.id,
                nomeFuncionario: funcionario.nome,
                cargoFuncionario: funcionario.cargo
            });
        }

        function editarCor(id) {
            const cor = DataManager.findById(cores, id);
            if (!cor) return;
            
            FormManager.fillForEdit('cor', {
                corId: cor.id,
                nomeCor: cor.nome
            });
        }

        function editarProducao(id) {
            const producao = DataManager.findById(producoes, id);
            if (!producao) return;
            
            document.getElementById('producaoId').value = producao.id;
            document.getElementById('dataProducao').value = producao.data;
            document.getElementById('funcionarioProducao').value = producao.funcionarioId;

            const primeiroItem = document.querySelector('.itemProducao[data-index="0"], .itemProducao:first-child');
            if (primeiroItem) {
                const pecaSelect = primeiroItem.querySelector('#pecaProducao, .peca-select');
                if (pecaSelect) pecaSelect.value = producao.pecaId;
                
                const corSelect = primeiroItem.querySelector('#corProducao, .cor-select');
                if (corSelect) corSelect.value = producao.corId;
                
                const quantidadeInput = primeiroItem.querySelector('.quantidade, #quantidade');
                if (quantidadeInput) quantidadeInput.value = producao.quantidade;
                
                const checkbox = primeiroItem.querySelector('.hora-extra-checkbox, #horaExtra');
                if (checkbox) checkbox.checked = producao.horaExtra || false;
            }

            FormManager.setEditingMode('producao', true);
        }

        function cancelarEdicaoPeca() {
            FormManager.cancelEditing('peca');
        }

        function cancelarEdicaoFuncionario() {
            FormManager.cancelEditing('funcionario');
        }

        function cancelarEdicaoCor() {
            FormManager.cancelEditing('cor');
        }

        function cancelarEdicao() {
            FormManager.cancelEditing('producao');
        }

        function cancelarSaida() {
            FormManager.cancelEditing('saida');
        }

        // ============================================
        // FUNÇÕES DE EXCLUSÃO
        // ============================================

        async function excluirPeca(id) {
            if (!confirm('⚠️ Tem certeza que deseja excluir esta peça?')) return;
            
            try {
                await window.electronAPI.database.run('DELETE FROM Pecas WHERE id=?', [id]);
                await DataManager.refreshData();
                alert('✅ Peça excluída com sucesso!');
            } catch (error) {
                console.error('❌ Erro ao excluir peça:', error);
                alert('❌ Erro ao excluir peça: ' + error.message);
            }
        }

        async function excluirFuncionario(id) {
            if (!confirm('⚠️ Tem certeza que deseja excluir este funcionário?')) return;
            
            try {
                await window.electronAPI.database.run('DELETE FROM Funcionarios WHERE id=?', [id]);
                await DataManager.refreshData();
                alert('✅ Funcionário excluído com sucesso!');
            } catch (error) {
                console.error('❌ Erro ao excluir funcionário:', error);
                alert('❌ Erro ao excluir funcionário: ' + error.message);
            }
        }

        async function excluirCor(id) {
            if (!confirm('⚠️ Tem certeza que deseja excluir esta cor?')) return;
            
            try {
                await window.electronAPI.database.run('DELETE FROM Cores WHERE id=?', [id]);
                await DataManager.refreshData();
                alert('✅ Cor excluída com sucesso!');
            } catch (error) {
                console.error('❌ Erro ao excluir cor:', error);
                alert('❌ Erro ao excluir cor: ' + error.message);
            }
        }

        async function excluirProducao(id) {
            if (!confirm('⚠️ Tem certeza que deseja excluir este registro de produção?')) return;
            
            try {
                await window.electronAPI.database.run('DELETE FROM Producoes WHERE id=?', [id]);
                
                const movs = movimentacoes.filter(m => m.producaoId === id);
                for (const mov of movs) {
                    await window.electronAPI.database.run('DELETE FROM Movimentacoes WHERE id=?', [mov.id]);
                }
                
                await DataManager.refreshData();
                alert('✅ Produção excluída com sucesso!');
                
            } catch (error) {
                console.error('❌ Erro ao excluir produção:', error);
                alert('❌ Erro ao excluir produção: ' + error.message);
            }
        }

        // ============================================
        // INICIALIZAÇÃO
        // ============================================

        document.addEventListener('DOMContentLoaded', async function() {
            await inicializarSistema();
        });

        async function inicializarSistema() {
            try {
                console.log('🚀 Inicializando sistema SysCadeiras...');
                
                await window.electronAPI.database.init();
                
                await transferirDadosLocalStorage();
                
                await DataManager.loadDataFromDB();
                
                FormManager.init();
                
                inicializarAplicacao();
                
                configurarPWA();
                
            } catch (error) {
                console.error('❌ Erro crítico na inicialização:', error);
                alert('Erro ao inicializar o sistema. Recarregue a página.');
            }
        }

        async function transferirDadosLocalStorage() {
            const temPecas = localStorage.getItem('pecas');
            const temFuncionarios = localStorage.getItem('funcionarios');
            const temCores = localStorage.getItem('cores');
            const temProducoes = localStorage.getItem('producoes');
            const temMovimentacoes = localStorage.getItem('movimentacoes');
            
            if (temPecas || temFuncionarios || temCores || temProducoes || temMovimentacoes) {
                const modal = document.getElementById('modalMigracao');
                const progresso = document.getElementById('progressoMigracao');
                const status = document.getElementById('statusMigracao');
                const log = document.getElementById('logMigracao');
                
                modal.style.display = 'flex';
                log.innerHTML = '';
                
                function adicionarLog(msg) {
                    log.innerHTML += `<div>${msg}</div>`;
                    log.scrollTop = log.scrollHeight;
                }
                
                try {
                    adicionarLog('📦 Iniciando transferência de dados...');
                    
                    if (temPecas) {
                        const pecasLocal = JSON.parse(temPecas);
                        adicionarLog(`📦 Transferindo ${pecasLocal.length} peças...`);
                        
                        for (const peca of pecasLocal) {
                            await window.electronAPI.database.run(
                                'INSERT OR IGNORE INTO Pecas (id, nome, valor) VALUES (?, ?, ?)',
                                [peca.id, peca.nome, peca.valor]
                            );
                        }
                    }
                    
                    progresso.style.width = '20%';
                    status.textContent = 'Peças transferidas...';
                    
                    if (temCores) {
                        const coresLocal = JSON.parse(temCores);
                        adicionarLog(`🎨 Transferindo ${coresLocal.length} cores...`);
                        
                        for (const cor of coresLocal) {
                            await window.electronAPI.database.run(
                                'INSERT OR IGNORE INTO Cores (id, nome) VALUES (?, ?)',
                                [cor.id, cor.nome]
                            );
                        }
                    }
                    
                    progresso.style.width = '40%';
                    status.textContent = 'Cores transferidas...';
                    
                    if (temFuncionarios) {
                        const funcLocal = JSON.parse(temFuncionarios);
                        adicionarLog(`👷 Transferindo ${funcLocal.length} funcionários...`);
                        
                        for (const func of funcLocal) {
                            await window.electronAPI.database.run(
                                'INSERT OR IGNORE INTO Funcionarios (id, nome, cargo) VALUES (?, ?, ?)',
                                [func.id, func.nome, func.cargo]
                            );
                        }
                    }
                    
                    progresso.style.width = '60%';
                    status.textContent = 'Funcionários transferidos...';
                    
                    if (temProducoes) {
                        const prodLocal = JSON.parse(temProducoes);
                        adicionarLog(`🏭 Transferindo ${prodLocal.length} produções...`);
                        
                        for (const prod of prodLocal) {
                            await window.electronAPI.database.run(
                                'INSERT OR IGNORE INTO Producoes (id, data, funcionarioId, pecaId, corId, quantidade, horaExtra) VALUES (?, ?, ?, ?, ?, ?, ?)',
                                [prod.id, prod.data, prod.funcionarioId, prod.pecaId, prod.corId, prod.quantidade, prod.horaExtra ? 1 : 0]
                            );
                        }
                    }
                    
                    progresso.style.width = '80%';
                    status.textContent = 'Produções transferidas...';
                    
                    if (temMovimentacoes) {
                        const movLocal = JSON.parse(temMovimentacoes);
                        adicionarLog(`📊 Transferindo ${movLocal.length} movimentações...`);
                        
                        for (const mov of movLocal) {
                            await window.electronAPI.database.run(
                                'INSERT OR IGNORE INTO Movimentacoes (id, data, tipo, pecaId, corId, quantidade, origem, producaoId, funcionarioId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                                [mov.id, mov.data, mov.tipo, mov.pecaId, mov.corId, mov.quantidade, mov.origem, mov.producaoId, mov.funcionarioId]
                            );
                        }
                    }
                    
                    progresso.style.width = '100%';
                    status.textContent = '✅ Transferência concluída!';
                    
                    localStorage.clear();
                    
                    adicionarLog('✅ Todos os dados foram transferidos com sucesso!');
                    adicionarLog('🗑️ localStorage limpo.');
                    
                    setTimeout(() => {
                        modal.style.display = 'none';
                    }, 2000);
                    
                } catch (error) {
                    adicionarLog(`❌ Erro na transferência: ${error.message}`);
                    status.textContent = '❌ Erro na transferência';
                    console.error('Erro na migração:', error);
                }
            }
        }

        function inicializarAplicacao() {
            producoes = producoes.map(p => ({ corId: p.corId !== undefined ? p.corId : null, ...p }));
            movimentacoes = movimentacoes.map(m => ({ corId: m.corId !== undefined ? m.corId : null, ...m }));
            
            UIManager.refreshAllSelects();
            UIManager.refreshAllTables();
            
            document.getElementById('dataProducao').value = hojeISO();
            document.getElementById('dataSaida').value = hojeISO();
            document.getElementById('mesFolha').value = hojeISO().substring(0, 7);
            
            configurarEventListeners();
            
            console.log('✅ Aplicação inicializada com sucesso!');
        }

        function configurarEventListeners() {
            const hoje = hojeISO();
            document.querySelectorAll('input[type="date"]').forEach(input => {
                if (!input.value) input.value = hoje;
            });
            
            document.getElementById('pesquisaEstoque').addEventListener('keyup', function() {
                clearTimeout(timeoutPesquisa);
                timeoutPesquisa = setTimeout(pesquisarEstoque, 500);
            });
        }

        function configurarPWA() {
            window.addEventListener('beforeinstallprompt', (e) => {
                e.preventDefault();
                deferredPrompt = e;
                document.getElementById('btnInstall').style.display = 'block';
            });
            
            document.getElementById('btnInstall').addEventListener('click', async () => {
                if (deferredPrompt) {
                    deferredPrompt.prompt();
                    const { outcome } = await deferredPrompt.userChoice;
                    if (outcome === 'accepted') {
                        document.getElementById('btnInstall').style.display = 'none';
                    }
                    deferredPrompt = null;
                }
            });
        }

        // ============================================
        // FUNÇÕES AUXILIARES
        // ============================================

        function hojeISO() { 
            return new Date().toISOString().split('T')[0]; 
        }

        function formatarData(dataISO) { 
            if (!dataISO) return '';
            const data = new Date(dataISO + 'T00:00:00');
            return data.toLocaleDateString('pt-BR');
        }

        function formatarMoeda(valor) {
            return new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL'
            }).format(valor || 0);
        }

        function calcularSaldo(pecaId, corId) {
            let saldo = 0;
            movimentacoes.forEach(mov => {
                if (mov.pecaId === pecaId && mov.corId === corId) {
                    saldo += mov.tipo === 'entrada' ? mov.quantidade : -mov.quantidade;
                }
            });
            return saldo;
        }

        function adicionarItemProducao() {
            const container = document.getElementById('itensProducao');
            const novoItem = document.createElement('div');
            novoItem.className = 'itemProducao';
            const index = container.children.length;
            novoItem.setAttribute('data-index', index);
            
            novoItem.innerHTML = `
                <div class="form-row">
                    <label>🪑 Modelo:</label>
                    <select class="peca-item" required>
                        <option value="">Selecione um modelo</option>
                        ${pecas.map(p => `<option value="${p.id}">${p.nome}</option>`).join('')}
                    </select>
                </div>
                <div class="form-row">
                    <label>🎨 Cor:</label>
                    <select class="cor-item" required>
                        <option value="">Selecione uma cor</option>
                        ${cores.map(c => `<option value="${c.id}">${c.nome}</option>`).join('')}
                    </select>
                </div>
                <div class="form-row">
                    <label>📊 Quantidade:</label>
                    <input type="number" class="quantidade-item" min="1" required>
                </div>
                <div class="form-row">
                    <label>⏰ Hora Extra (+50%):</label>
                    <input type="checkbox" class="hora-extra-item">
                </div>
                <button type="button" class="btn-excluir" onclick="this.parentElement.remove()">
                    🗑️ Remover Item
                </button>
                <hr style="margin: 15px 0;">
            `;
            container.appendChild(novoItem);
        }

        function showSection(id, btn) {
            document.querySelectorAll('.section').forEach(s => {
                s.classList.remove('active');
                s.style.display = 'none';
            });
            
            document.querySelectorAll('.menu button').forEach(b => {
                b.classList.remove('active');
            });
            
            const sec = document.getElementById(id);
            if (sec) {
                sec.classList.add('active');
                sec.style.display = 'block';
            }
            
            if (btn) {
                btn.classList.add('active');
            }
            
            if (id === 'estoque') {
                UIManager.refreshSaldosTable();
            } else if (id === 'producao') {
                UIManager.refreshProducaoTable();
            }
        }

        function atualizarSistema() {
            if (confirm('🔄 Deseja atualizar o sistema? Isso irá recarregar todos os dados e atualizar a interface.')) {
                location.reload();
            }
        }

        // ============================================
        // FUNÇÕES DE PESQUISA (mantidas)
        // ============================================

        async function pesquisarEstoque() {
            const termo = document.getElementById('pesquisaEstoque').value;
            const loadingIndicator = document.getElementById('loadingIndicator');
            const resultadoInfo = document.getElementById('resultadoPesquisa');
            
            loadingIndicator.style.display = 'inline-block';
            resultadoInfo.style.display = 'flex';
            
            try {
                const filtros = {
                    texto: termo || undefined
                };
                
                const result = await window.electronAPI.database.invoke(
                    'pesquisar-movimentacoes',
                    filtros
                );
                
                document.getElementById('infoResultado').innerHTML = 
                    `📊 Encontrados ${result.success ? result.result.length : 0} resultados`;
                
            } catch (error) {
                console.error('Erro na pesquisa:', error);
                document.getElementById('infoResultado').innerHTML = '❌ Erro na pesquisa';
            } finally {
                loadingIndicator.style.display = 'none';
            }
        }

        async function aplicarFiltrosEstoque() {
            const pecaId = document.getElementById('filtroPecaEstoque').value;
            const corId = document.getElementById('filtroCorEstoque').value;
            const dataInicio = document.getElementById('filtroDataInicio').value;
            const dataFim = document.getElementById('filtroDataFim').value;
            
            const loadingIndicator = document.getElementById('loadingIndicator');
            const resultadoInfo = document.getElementById('resultadoPesquisa');
            
            loadingIndicator.style.display = 'inline-block';
            resultadoInfo.style.display = 'flex';
            
            try {
                let saldosFiltrados = await calcularSaldosComFiltros(pecaId, corId, dataInicio, dataFim);
                
                document.getElementById('infoResultado').innerHTML = 
                    `📊 Encontradas ${saldosFiltrados.length} variações de estoque`;
                
                // Renderizar diretamente sem usar o UIManager (é uma visualização filtrada)
                const tbody = document.querySelector('#tabelaSaldos tbody');
                tbody.innerHTML = '';
                
                saldosFiltrados.sort((a, b) => {
                    const pecaA = DataManager.findById(pecas, a.pecaId);
                    const pecaB = DataManager.findById(pecas, b.pecaId);
                    const corA = DataManager.findById(cores, a.corId);
                    const corB = DataManager.findById(cores, b.corId);

                    if (!pecaA || !pecaB) return 0;
                    if (pecaA.nome < pecaB.nome) return -1;
                    if (pecaA.nome > pecaB.nome) return 1;

                    const nomeCorA = corA ? corA.nome : '';
                    const nomeCorB = corB ? corB.nome : '';
                    return nomeCorA.localeCompare(nomeCorB);
                });

                saldosFiltrados.forEach(s => {
                    const peca = DataManager.findById(pecas, s.pecaId);
                    const cor = DataManager.findById(cores, s.corId);
                    if (!peca) return;

                    let classeSaldo = 'saldo-ok';
                    if (s.saldo < 0) classeSaldo = 'saldo-negativo';
                    else if (s.saldo < 5) classeSaldo = 'saldo-critico';
                    else if (s.saldo < 10) classeSaldo = 'saldo-alerta';

                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${peca.nome}</td>
                        <td>${cor ? cor.nome : 'Sem cor'}</td>
                        <td class="${classeSaldo}">${s.saldo}</td>
                    `;
                    tbody.appendChild(tr);
                });
                
            } catch (error) {
                console.error('Erro ao aplicar filtros:', error);
                document.getElementById('infoResultado').innerHTML = '❌ Erro ao aplicar filtros';
            } finally {
                loadingIndicator.style.display = 'none';
            }
        }

        async function calcularSaldosComFiltros(pecaId, corId, dataInicio, dataFim) {
            let movFiltradas = movimentacoes;
            
            if (dataInicio) {
                movFiltradas = movFiltradas.filter(m => m.data >= dataInicio);
            }
            if (dataFim) {
                movFiltradas = movFiltradas.filter(m => m.data <= dataFim);
            }
            
            const saldos = {};
            movFiltradas.forEach(mov => {
                if (pecaId && mov.pecaId != pecaId) return;
                if (corId && mov.corId != corId) return;
                
                const key = `${mov.pecaId}-${mov.corId}`;
                if (!saldos[key]) {
                    saldos[key] = { pecaId: mov.pecaId, corId: mov.corId, saldo: 0 };
                }
                saldos[key].saldo += mov.tipo === 'entrada' ? mov.quantidade : -mov.quantidade;
            });
            
            return Object.values(saldos);
        }

        function limparFiltrosEstoque() {
            document.getElementById('pesquisaEstoque').value = '';
            document.getElementById('filtroPecaEstoque').value = '';
            document.getElementById('filtroCorEstoque').value = '';
            document.getElementById('filtroDataInicio').value = '';
            document.getElementById('filtroDataFim').value = '';
            
            document.getElementById('resultadoPesquisa').style.display = 'none';
            UIManager.refreshSaldosTable();
        }

        // ============================================
        // FUNÇÕES DE RELATÓRIOS (mantidas)
        // ============================================

        function mudarTipoRelatorio(tipo) {
            tipoRelatorioAtual = tipo;
            
            document.querySelectorAll('.tipo-relatorio button').forEach(btn => {
                btn.classList.remove('active');
            });
            document.getElementById(`btnRelatorio${tipo.charAt(0).toUpperCase() + tipo.slice(1)}`).classList.add('active');
            
            document.getElementById('filtrosRelatorioGeral').style.display = tipo === 'geral' ? 'block' : 'none';
            document.getElementById('filtrosRelatorioModelos').style.display = tipo === 'modelos' ? 'block' : 'none';
            document.getElementById('filtrosRelatorioEstoque').style.display = tipo === 'estoque' ? 'block' : 'none';
            document.getElementById('filtrosRelatorioFolha').style.display = tipo === 'folha' ? 'block' : 'none';
            
            document.getElementById('resultadoRelatorioGeral').style.display = tipo === 'geral' ? 'block' : 'none';
            document.getElementById('resultadoRelatorioModelos').style.display = tipo === 'modelos' ? 'block' : 'none';
            document.getElementById('resultadoRelatorioEstoque').style.display = tipo === 'estoque' ? 'block' : 'none';
            document.getElementById('resultadoRelatorioFolha').style.display = tipo === 'folha' ? 'block' : 'none';
        }

        function gerarRelatorio() {
            if (tipoRelatorioAtual === 'geral') {
                gerarRelatorioGeral();
            } else if (tipoRelatorioAtual === 'modelos') {
                gerarRelatorioModelos();
            } else if (tipoRelatorioAtual === 'estoque') {
                gerarRelatorioEstoque();
            }
        }

        function gerarRelatorioGeral() {
            const dataInicio = document.getElementById('dataInicio').value;
            const dataFim = document.getElementById('dataFim').value;
            const funcionarioId = document.getElementById('filtroFuncionario').value;
            const pecaId = document.getElementById('filtroPeca').value;
            const corId = document.getElementById('filtroCor').value;
            
            let producoesFiltradas = producoes.filter(p => {
                if (dataInicio && p.data < dataInicio) return false;
                if (dataFim && p.data > dataFim) return false;
                if (funcionarioId && p.funcionarioId != funcionarioId) return false;
                if (pecaId && p.pecaId != pecaId) return false;
                if (corId && p.corId != corId) return false;
                return true;
            });
            
            const tbody = document.querySelector('#tabelaRelatorio tbody');
            tbody.innerHTML = '';
            
            if (producoesFiltradas.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="9" class="text-center" style="padding: 40px;">
                            📭 Nenhuma produção encontrada com os filtros selecionados
                        </td>
                    </tr>
                `;
                document.getElementById('totalGeral').textContent = formatarMoeda(0);
                return;
            }
            
            let totalGeral = 0;
            producoesFiltradas.forEach(producao => {
                const funcionario = DataManager.findById(funcionarios, producao.funcionarioId);
                const peca = DataManager.findById(pecas, producao.pecaId);
                const cor = DataManager.findById(cores, producao.corId);
                
                let valorUnitario = peca ? peca.valor : 0;
                let valorTotal = valorUnitario * producao.quantidade;
                
                if (producao.horaExtra) {
                    valorUnitario = valorUnitario * 1.5;
                    valorTotal = valorUnitario * producao.quantidade;
                }
                
                totalGeral += valorTotal;
                
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>
                        <input type="checkbox" class="checkbox-selecao" value="${producao.id}" 
                               onchange="toggleProducaoSelecionada(${producao.id}, this.checked)">
                    </td>
                    <td>${formatarData(producao.data)}</td>
                    <td>${funcionario ? funcionario.nome : 'N/A'}</td>
                    <td>${peca ? peca.nome : 'N/A'}</td>
                    <td>${cor ? cor.nome : 'N/A'}</td>
                    <td>${producao.quantidade}</td>
                    <td>${producao.horaExtra ? '<span class="badge-tipo badge-pedido">SIM</span>' : 'Não'}</td>
                    <td class="valor">${formatarMoeda(valorUnitario)}</td>
                    <td class="valor">${formatarMoeda(valorTotal)}</td>
                `;
                tbody.appendChild(tr);
            });
            
            document.getElementById('totalGeral').textContent = formatarMoeda(totalGeral);
            producoesSelecionadas.clear();
            document.getElementById('selecionarTodos').checked = false;
        }

        function gerarRelatorioModelos() {
            const dataInicio = document.getElementById('dataInicioPeca').value;
            const dataFim = document.getElementById('dataFimPeca').value;
            
            let producoesFiltradas = producoes.filter(p => {
                if (dataInicio && p.data < dataInicio) return false;
                if (dataFim && p.data > dataFim) return false;
                return true;
            });
            
            const agrupado = {};
            producoesFiltradas.forEach(producao => {
                const key = `${producao.pecaId}-${producao.corId}`;
                if (!agrupado[key]) {
                    agrupado[key] = { pecaId: producao.pecaId, corId: producao.corId, quantidade: 0 };
                }
                agrupado[key].quantidade += producao.quantidade;
            });
            
            const tbody = document.querySelector('#tabelaRelatorioModelos tbody');
            tbody.innerHTML = '';
            
            if (Object.keys(agrupado).length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="5" class="text-center" style="padding: 40px;">
                            📭 Nenhuma produção encontrada no período
                        </td>
                    </tr>
                `;
                document.getElementById('totalGeralModelos').textContent = formatarMoeda(0);
                return;
            }
            
            let totalGeral = 0;
            Object.values(agrupado).forEach(item => {
                const peca = DataManager.findById(pecas, item.pecaId);
                const cor = DataManager.findById(cores, item.corId);
                const valorTotal = peca ? peca.valor * item.quantidade : 0;
                totalGeral += valorTotal;
                
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${peca ? peca.nome : 'N/A'}</td>
                    <td>${cor ? cor.nome : 'N/A'}</td>
                    <td>${item.quantidade}</td>
                    <td class="valor">${peca ? formatarMoeda(peca.valor) : 'N/A'}</td>
                    <td class="valor">${formatarMoeda(valorTotal)}</td>
                `;
                tbody.appendChild(tr);
            });
            
            document.getElementById('totalGeralModelos').textContent = formatarMoeda(totalGeral);
        }

        function gerarRelatorioEstoque() {
            const dataInicio = document.getElementById('dataInicioEst').value;
            const dataFim = document.getElementById('dataFimEst').value;
            const tipoMov = document.getElementById('tipoMovEst').value;
            const pecaId = document.getElementById('pecaEst').value;
            const corId = document.getElementById('corEst').value;
            
            let movFiltradas = movimentacoes.filter(m => {
                if (dataInicio && m.data < dataInicio) return false;
                if (dataFim && m.data > dataFim) return false;
                if (tipoMov && m.tipo !== tipoMov) return false;
                if (pecaId && m.pecaId != pecaId) return false;
                if (corId && m.corId != corId) return false;
                return true;
            });
            
            const tbody = document.querySelector('#tabelaRelatorioEstoque tbody');
            tbody.innerHTML = '';
            
            if (movFiltradas.length === 0) {
                tbody.innerHTML = `
                    <tr>
                        <td colspan="6" class="text-center" style="padding: 40px;">
                            📭 Nenhuma movimentação encontrada com os filtros selecionados
                        </td>
                    </tr>
                `;
                document.getElementById('saldoPeriodo').textContent = '0';
                return;
            }
            
            let saldoPeriodo = 0;
            movFiltradas.forEach(mov => {
                const peca = DataManager.findById(pecas, mov.pecaId);
                const cor = DataManager.findById(cores, mov.corId);
                saldoPeriodo += mov.tipo === 'entrada' ? mov.quantidade : -mov.quantidade;
                
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${formatarData(mov.data)}</td>
                    <td>
                        ${mov.tipo === 'entrada' 
                            ? '<span class="badge-tipo badge-entrada">Entrada</span>' 
                            : '<span class="badge-tipo badge-saida">Saída</span>'}
                    </td>
                    <td>${peca ? peca.nome : 'N/A'}</td>
                    <td>${cor ? cor.nome : 'N/A'}</td>
                    <td>${mov.quantidade}</td>
                    <td>${mov.origem || ''}</td>
                `;
                tbody.appendChild(tr);
            });
            
            document.getElementById('saldoPeriodo').textContent = saldoPeriodo;
        }

        function toggleProducaoSelecionada(id, checked) {
            if (checked) {
                producoesSelecionadas.add(id);
            } else {
                producoesSelecionadas.delete(id);
            }
            const totalCheckboxes = document.querySelectorAll('.checkbox-selecao').length;
            document.getElementById('selecionarTodos').checked = 
                producoesSelecionadas.size === totalCheckboxes && totalCheckboxes > 0;
        }

        function selecionarTodasProducoes(checked) {
            producoesSelecionadas.clear();
            document.querySelectorAll('.checkbox-selecao').forEach(cb => {
                cb.checked = checked;
                if (checked) {
                    producoesSelecionadas.add(parseInt(cb.value));
                }
            });
        }

        async function apagarProducaoSelecionada() {
            if (producoesSelecionadas.size === 0) {
                alert('⚠️ Selecione pelo menos um registro de produção para apagar.');
                return;
            }
            
            if (!confirm(`⚠️ Tem certeza que deseja apagar ${producoesSelecionadas.size} registro(s) de produção?`)) return;
            
            try {
                for (const id of producoesSelecionadas) {
                    await window.electronAPI.database.run('DELETE FROM Producoes WHERE id=?', [id]);
                    
                    const movs = movimentacoes.filter(m => m.producaoId === id);
                    for (const mov of movs) {
                        await window.electronAPI.database.run('DELETE FROM Movimentacoes WHERE id=?', [mov.id]);
                    }
                }
                
                await DataManager.refreshData();
                producoesSelecionadas.clear();
                
                alert(`✅ ${producoesSelecionadas.size} produção(ões) excluída(s) com sucesso!`);
                
            } catch (error) {
                console.error('❌ Erro ao apagar produções:', error);
                alert('❌ Erro ao apagar produções: ' + error.message);
            }
        }

        function exportarDados() {
            const dataInicio = document.getElementById('dataInicio').value;
            const dataFim = document.getElementById('dataFim').value;
            const funcionarioId = document.getElementById('filtroFuncionario').value;
            const pecaId = document.getElementById('filtroPeca').value;
            const corId = document.getElementById('filtroCor').value;
            
            let producoesFiltradas = producoes.filter(p => {
                if (dataInicio && p.data < dataInicio) return false;
                if (dataFim && p.data > dataFim) return false;
                if (funcionarioId && p.funcionarioId != funcionarioId) return false;
                if (pecaId && p.pecaId != pecaId) return false;
                if (corId && p.corId != corId) return false;
                return true;
            });
            
            if (producoesFiltradas.length === 0) {
                alert('⚠️ Não há produções para exportar com os filtros selecionados.');
                return;
            }
            
            producoesFiltradas.sort((a, b) => a.data.localeCompare(b.data));
            
            let totalGeral = 0;
            let totalItens = 0;
            
            let csv = '='.repeat(100) + '\n';
            csv += 'RELATÓRIO GERAL DE PRODUÇÃO - SYSCADEIRAS\n';
            csv += '='.repeat(100) + '\n\n';
            
            csv += `PERÍODO: ${dataInicio ? formatarData(dataInicio) : 'TODOS'} até ${dataFim ? formatarData(dataFim) : 'TODOS'}\n`;
            csv += `DATA DE GERAÇÃO: ${new Date().toLocaleString('pt-BR')}\n`;
            csv += `TOTAL DE REGISTROS: ${producoesFiltradas.length}\n\n`;
            
            csv += 'FILTROS APLICADOS:\n';
            csv += `- Funcionário: ${funcionarioId ? (funcionarios.find(f => f.id == funcionarioId)?.nome || 'Todos') : 'Todos'}\n`;
            csv += `- Modelo: ${pecaId ? (pecas.find(p => p.id == pecaId)?.nome || 'Todos') : 'Todos'}\n`;
            csv += `- Cor: ${corId ? (cores.find(c => c.id == corId)?.nome || 'Todas') : 'Todas'}\n\n`;
            
            csv += '-'.repeat(100) + '\n';
            csv += 'DETALHAMENTO DA PRODUÇÃO\n';
            csv += '-'.repeat(100) + '\n';
            
            csv += 'Data;Dia Semana;Funcionário;Modelo;Cor;Quantidade;Hora Extra;Valor Unit.(R$);Valor Total(R$)\n';
            
            const diasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
            
            producoesFiltradas.forEach(producao => {
                const funcionario = funcionarios.find(f => f.id === producao.funcionarioId);
                const peca = pecas.find(p => p.id === producao.pecaId);
                const cor = cores.find(c => c.id === producao.corId);
                
                const dataObj = new Date(producao.data + 'T00:00:00');
                const diaSemana = diasSemana[dataObj.getDay()];
                
                const valorUnitarioBase = peca ? peca.valor : 0;
                const valorUnitario = producao.horaExtra ? valorUnitarioBase * 1.5 : valorUnitarioBase;
                const valorTotal = valorUnitario * producao.quantidade;
                
                totalGeral += valorTotal;
                totalItens += producao.quantidade;
                
                const linha = [
                    formatarData(producao.data),
                    diaSemana,
                    funcionario ? funcionario.nome : 'N/A',
                    peca ? peca.nome : 'N/A',
                    cor ? cor.nome : 'Sem cor',
                    producao.quantidade,
                    producao.horaExtra ? 'SIM' : 'NÃO',
                    valorUnitario.toFixed(2).replace('.', ','),
                    valorTotal.toFixed(2).replace('.', ',')
                ];
                
                csv += linha.join(';') + '\n';
            });
            
            csv += '\n' + '='.repeat(100) + '\n';
            csv += 'RESUMO GERAL\n';
            csv += '='.repeat(100) + '\n\n';
            
            csv += `Total de Itens Produzidos: ${totalItens}\n`;
            csv += `Valor Total Produzido: R$ ${totalGeral.toFixed(2).replace('.', ',')}\n`;
            csv += `Média por Registro: R$ ${(totalGeral / producoesFiltradas.length).toFixed(2).replace('.', ',')}\n\n`;
            
            csv += '-'.repeat(100) + '\n';
            csv += 'RESUMO POR FUNCIONÁRIO\n';
            csv += '-'.repeat(100) + '\n';
            csv += 'Funcionário;Quantidade de Registros;Total Itens;Valor Total(R$)\n';
            
            const resumoFuncionarios = {};
            producoesFiltradas.forEach(p => {
                if (!resumoFuncionarios[p.funcionarioId]) {
                    resumoFuncionarios[p.funcionarioId] = {
                        nome: funcionarios.find(f => f.id === p.funcionarioId)?.nome || 'N/A',
                        registros: 0,
                        itens: 0,
                        valor: 0
                    };
                }
                
                const peca = pecas.find(pc => pc.id === p.pecaId);
                const valorBase = peca ? peca.valor : 0;
                const valorUnit = p.horaExtra ? valorBase * 1.5 : valorBase;
                
                resumoFuncionarios[p.funcionarioId].registros++;
                resumoFuncionarios[p.funcionarioId].itens += p.quantidade;
                resumoFuncionarios[p.funcionarioId].valor += valorUnit * p.quantidade;
            });
            
            Object.values(resumoFuncionarios).forEach(f => {
                csv += `${f.nome};${f.registros};${f.itens};${f.valor.toFixed(2).replace('.', ',')}\n`;
            });
            
            csv += '\n' + '='.repeat(100) + '\n';
            csv += 'FIM DO RELATÓRIO\n';
            csv += '='.repeat(100) + '\n';
            
            const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            
            let nomeArquivo = 'relatorio_producao';
            if (dataInicio) nomeArquivo += `_${dataInicio}`;
            if (dataFim) nomeArquivo += `_a_${dataFim}`;
            nomeArquivo += '.csv';
            
            link.setAttribute('download', nomeArquivo);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            alert(`✅ Relatório exportado com sucesso!\n📊 Total de registros: ${producoesFiltradas.length}\n💰 Valor total: R$ ${totalGeral.toFixed(2)}`);
        }

        function exportarEstoqueCSV() {
            const dataInicio = document.getElementById('dataInicioEst').value;
            const dataFim = document.getElementById('dataFimEst').value;
            const tipoMov = document.getElementById('tipoMovEst').value;
            const pecaId = document.getElementById('pecaEst').value;
            const corId = document.getElementById('corEst').value;
            
            let movFiltradas = movimentacoes.filter(m => {
                if (dataInicio && m.data < dataInicio) return false;
                if (dataFim && m.data > dataFim) return false;
                if (tipoMov && m.tipo !== tipoMov) return false;
                if (pecaId && m.pecaId != pecaId) return false;
                if (corId && m.corId != corId) return false;
                return true;
            });
            
            if (movFiltradas.length === 0) {
                alert('⚠️ Não há movimentações para exportar com os filtros selecionados.');
                return;
            }
            
            movFiltradas.sort((a, b) => a.data.localeCompare(b.data));
            
            const saldos = {};
            let totalEntradas = 0;
            let totalSaidas = 0;
            
            movFiltradas.forEach(mov => {
                const key = `${mov.pecaId}-${mov.corId}`;
                if (!saldos[key]) {
                    saldos[key] = {
                        pecaId: mov.pecaId,
                        corId: mov.corId,
                        entradas: 0,
                        saidas: 0,
                        saldo: 0
                    };
                }
                
                if (mov.tipo === 'entrada') {
                    saldos[key].entradas += mov.quantidade;
                    totalEntradas += mov.quantidade;
                } else {
                    saldos[key].saidas += mov.quantidade;
                    totalSaidas += mov.quantidade;
                }
                
                saldos[key].saldo += mov.tipo === 'entrada' ? mov.quantidade : -mov.quantidade;
            });
            
            let csv = '='.repeat(100) + '\n';
            csv += 'RELATÓRIO DE MOVIMENTAÇÕES DE ESTOQUE - SYSCADEIRAS\n';
            csv += '='.repeat(100) + '\n\n';
            
            csv += `PERÍODO: ${dataInicio ? formatarData(dataInicio) : 'TODOS'} até ${dataFim ? formatarData(dataFim) : 'TODOS'}\n`;
            csv += `DATA DE GERAÇÃO: ${new Date().toLocaleString('pt-BR')}\n`;
            csv += `TOTAL DE MOVIMENTAÇÕES: ${movFiltradas.length}\n\n`;
            
            csv += 'FILTROS APLICADOS:\n';
            csv += `- Tipo: ${tipoMov === 'entrada' ? 'Entradas' : tipoMov === 'saida' ? 'Saídas' : 'Todos'}\n`;
            csv += `- Modelo: ${pecaId ? (pecas.find(p => p.id == pecaId)?.nome || 'Todos') : 'Todos'}\n`;
            csv += `- Cor: ${corId ? (cores.find(c => c.id == corId)?.nome || 'Todas') : 'Todas'}\n\n`;
            
            csv += '-'.repeat(100) + '\n';
            csv += 'MOVIMENTAÇÕES DETALHADAS\n';
            csv += '-'.repeat(100) + '\n';
            
            csv += 'Data;Dia Semana;Tipo;Modelo;Cor;Quantidade;Origem/Observação\n';
            
            const diasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
            
            movFiltradas.forEach(mov => {
                const dataObj = new Date(mov.data + 'T00:00:00');
                const diaSemana = diasSemana[dataObj.getDay()];
                const peca = pecas.find(p => p.id === mov.pecaId);
                const cor = cores.find(c => c.id === mov.corId);
                
                const linha = [
                    formatarData(mov.data),
                    diaSemana,
                    mov.tipo === 'entrada' ? 'ENTRADA' : 'SAÍDA',
                    peca ? peca.nome : 'N/A',
                    cor ? cor.nome : 'Sem cor',
                    mov.quantidade,
                    mov.origem || '-'
                ];
                
                csv += linha.join(';') + '\n';
            });
            
            csv += '\n' + '='.repeat(100) + '\n';
            csv += 'RESUMO DO ESTOQUE\n';
            csv += '='.repeat(100) + '\n\n';
            
            csv += `Total de Entradas no Período: ${totalEntradas}\n`;
            csv += `Total de Saídas no Período: ${totalSaidas}\n`;
            csv += `Saldo Líquido do Período: ${totalEntradas - totalSaidas}\n\n`;
            
            csv += '-'.repeat(100) + '\n';
            csv += 'SALDO ATUAL POR MODELO/COR\n';
            csv += '-'.repeat(100) + '\n';
            csv += 'Modelo;Cor;Entradas;Saídas;Saldo Atual\n';
            
            Object.values(saldos).forEach(item => {
                const peca = pecas.find(p => p.id === item.pecaId);
                const cor = cores.find(c => c.id === item.corId);
                
                csv += `${peca ? peca.nome : 'N/A'};${cor ? cor.nome : 'Sem cor'};${item.entradas};${item.saidas};${item.saldo}\n`;
            });
            
            csv += '\n' + '='.repeat(100) + '\n';
            csv += 'FIM DO RELATÓRIO\n';
            csv += '='.repeat(100) + '\n';
            
            const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            
            let nomeArquivo = 'relatorio_estoque';
            if (dataInicio) nomeArquivo += `_${dataInicio}`;
            if (dataFim) nomeArquivo += `_a_${dataFim}`;
            nomeArquivo += '.csv';
            
            link.setAttribute('download', nomeArquivo);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            alert(`✅ Relatório de estoque exportado com sucesso!\n📊 Total de movimentações: ${movFiltradas.length}\n📦 Saldo líquido: ${totalEntradas - totalSaidas}`);
        }

        function gerarListaFolhaPagamento() {
            const mesAno = document.getElementById('mesFolha').value;
            if (!mesAno) {
                alert('⚠️ Por favor, selecione o mês/ano.');
                return;
            }
            
            const [ano, mes] = mesAno.split('-');
            const dataInicio = `${ano}-${mes}-01`;
            const ultimoDia = new Date(ano, mes, 0).getDate();
            const dataFim = `${ano}-${mes}-${ultimoDia}`;
            
            const producoesMes = producoes.filter(p => {
                return p.data >= dataInicio && p.data <= dataFim;
            });
            
            if (producoesMes.length === 0) {
                alert(`📭 Não há produções registradas para ${mes}/${ano}.`);
                return;
            }
            
            const producoesPorFuncionario = {};
            producoesMes.forEach(producao => {
                const funcionarioId = producao.funcionarioId;
                if (!producoesPorFuncionario[funcionarioId]) {
                    producoesPorFuncionario[funcionarioId] = {
                        producoes: [],
                        totalItens: 0,
                        totalValor: 0,
                        diasTrabalhados: new Set()
                    };
                }
                producoesPorFuncionario[funcionarioId].producoes.push(producao);
                producoesPorFuncionario[funcionarioId].diasTrabalhados.add(producao.data);
            });
            
            Object.keys(producoesPorFuncionario).forEach(funcionarioId => {
                const prods = producoesPorFuncionario[funcionarioId].producoes;
                prods.forEach(producao => {
                    const peca = pecas.find(p => p.id === producao.pecaId);
                    let valorPeca = peca ? peca.valor : 0;
                    if (producao.horaExtra) {
                        valorPeca = valorPeca * 1.5;
                    }
                    const valorTotal = valorPeca * producao.quantidade;
                    producoesPorFuncionario[funcionarioId].totalItens += producao.quantidade;
                    producoesPorFuncionario[funcionarioId].totalValor += valorTotal;
                });
            });
            
            const funcionariosIds = Object.keys(producoesPorFuncionario).sort((a, b) => {
                const funcA = funcionarios.find(f => f.id == a);
                const funcB = funcionarios.find(f => f.id == b);
                return (funcA?.nome || '').localeCompare(funcB?.nome || '');
            });
            
            let html = `
                <table style="width: 100%; border-collapse: collapse; margin-top: 20px; box-shadow: 0 2px 8px rgba(0,0,0,.1); border-radius: 8px; overflow: hidden;">
                    <thead>
                        <tr style="background: #2c3e50; color: #fff;">
                            <th style="padding: 14px 12px; text-align: left; font-weight: 600;">Funcionário</th>
                            <th style="padding: 14px 12px; text-align: left; font-weight: 600;">Cargo</th>
                            <th style="padding: 14px 12px; text-align: center; font-weight: 600;">Dias</th>
                            <th style="padding: 14px 12px; text-align: right; font-weight: 600;">Qtd. Itens</th>
                            <th style="padding: 14px 12px; text-align: right; font-weight: 600;">Valor Total</th>
                            <th style="padding: 14px 12px; text-align: center; font-weight: 600;">Ação</th>
                        </tr>
                    </thead>
                    <tbody>
            `;
            
            let totalGeralItens = 0;
            let totalGeralValor = 0;
            
            funcionariosIds.forEach(funcionarioId => {
                const funcionario = funcionarios.find(f => f.id == funcionarioId);
                if (!funcionario) return;
                
                const dados = producoesPorFuncionario[funcionarioId];
                totalGeralItens += dados.totalItens;
                totalGeralValor += dados.totalValor;
                
                html += `
                    <tr style="border-bottom: 1px solid #eee; transition: background .2s;">
                        <td style="padding: 14px 12px;">${funcionario.nome}</td>
                        <td style="padding: 14px 12px;">${funcionario.cargo}</td>
                        <td style="padding: 14px 12px; text-align: center;">${dados.diasTrabalhados.size}</td>
                        <td style="padding: 14px 12px; text-align: right; font-weight: 600;">${dados.totalItens}</td>
                        <td style="padding: 14px 12px; text-align: right; font-weight: 600; font-family: monospace;">R$ ${dados.totalValor.toFixed(2)}</td>
                        <td style="padding: 14px 12px; text-align: center;">
                            <button onclick="exportarProducaoFuncionarioDetalhado('${funcionarioId}', '${mes}', '${ano}', '${funcionario.nome.replace(/'/g, "\\'")}')" style="background: #1abc9c; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; font-weight: 500; transition: all .2s;" onmouseover="this.style.background='#16a085'; this.style.transform='translateY(-2px)';" onmouseout="this.style.background='#1abc9c'; this.style.transform='translateY(0)';">📤 Exportar CSV</button>
                        </td>
                    </tr>
                `;
            });
            
            html += `
                    </tbody>
                    <tfoot>
                        <tr style="background: #f8f9fa; font-weight: 600;">
                            <td colspan="3" style="padding: 14px 12px; text-align: right;">TOTAL GERAL:</td>
                            <td style="padding: 14px 12px; text-align: right; font-weight: 600;">${totalGeralItens}</td>
                            <td style="padding: 14px 12px; text-align: right; font-weight: 600; font-family: monospace;">R$ ${totalGeralValor.toFixed(2)}</td>
                            <td style="padding: 14px 12px;"></td>
                        </tr>
                    </tfoot>
                </table>
            `;
            
            html += `
                <div class="text-center mt-20" style="display: flex; gap: 10px; justify-content: center;">
                    <button class="btn-primary" onclick="exportarTodosFuncionarios()">
                        📤 Exportar Todos os Funcionários (CSV Individual)
                    </button>
                </div>
            `;
            
            document.getElementById('tabelaFolhaPagamento').innerHTML = html;
            
            window.folhaPagamentoData = {
                mes,
                ano,
                producoesPorFuncionario,
                funcionarios
            };
        }

        function exportarProducaoFuncionarioDetalhado(funcionarioId, mes, ano, nomeFuncionario) {
            const producoesMes = producoes.filter(p => {
                const dataInicio = `${ano}-${mes}-01`;
                const ultimoDia = new Date(ano, mes, 0).getDate();
                const dataFim = `${ano}-${mes}-${ultimoDia}`;
                return p.data >= dataInicio && p.data <= dataFim && p.funcionarioId == funcionarioId;
            });
            
            if (producoesMes.length === 0) {
                alert('⚠️ Nenhuma produção encontrada para este funcionário no período.');
                return;
            }
            
            producoesMes.sort((a, b) => a.data.localeCompare(b.data));
            
            let totalItens = 0;
            let totalValor = 0;
            let totalHorasExtras = 0;
            let totalItensHoraExtra = 0;
            
            producoesMes.forEach(producao => {
                const peca = pecas.find(p => p.id === producao.pecaId);
                const valorUnitarioBase = peca ? peca.valor : 0;
                const valorComHoraExtra = producao.horaExtra ? valorUnitarioBase * 1.5 : valorUnitarioBase;
                const valorTotal = valorComHoraExtra * producao.quantidade;
                
                totalItens += producao.quantidade;
                totalValor += valorTotal;
                
                if (producao.horaExtra) {
                    totalHorasExtras++;
                    totalItensHoraExtra += producao.quantidade;
                }
            });
            
            let csv = '='.repeat(100) + '\n';
            csv += 'RELATÓRIO DE PRODUÇÃO - FUNCIONÁRIO\n';
            csv += '='.repeat(100) + '\n\n';
            
            csv += `FUNCIONÁRIO: ${nomeFuncionario}\n`;
            csv += `PERÍODO: ${mes}/${ano}\n`;
            csv += `DATA DE GERAÇÃO: ${new Date().toLocaleString('pt-BR')}\n`;
            csv += `TOTAL DE REGISTROS: ${producoesMes.length}\n\n`;
            
            csv += '-'.repeat(100) + '\n';
            csv += 'DETALHAMENTO DIÁRIO DA PRODUÇÃO\n';
            csv += '-'.repeat(100) + '\n';
            
            csv += 'Data;Dia Semana;Modelo;Cor;Quantidade;Hora Extra;Valor Unit.(R$);Valor Total(R$)\n';
            
            const producoesPorData = {};
            producoesMes.forEach(p => {
                if (!producoesPorData[p.data]) producoesPorData[p.data] = [];
                producoesPorData[p.data].push(p);
            });
            
            const diasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
            
            Object.keys(producoesPorData).sort().forEach(data => {
                const producoesDoDia = producoesPorData[data];
                const dataObj = new Date(data + 'T00:00:00');
                const diaSemana = diasSemana[dataObj.getDay()];
                
                producoesDoDia.forEach(producao => {
                    const peca = pecas.find(p => p.id === producao.pecaId);
                    const cor = cores.find(c => c.id === producao.corId);
                    
                    const valorUnitarioBase = peca ? peca.valor : 0;
                    const valorUnitario = producao.horaExtra ? valorUnitarioBase * 1.5 : valorUnitarioBase;
                    const valorTotal = valorUnitario * producao.quantidade;
                    
                    const linha = [
                        formatarData(producao.data),
                        diaSemana,
                        peca ? peca.nome : 'N/A',
                        cor ? cor.nome : 'Sem cor',
                        producao.quantidade,
                        producao.horaExtra ? 'SIM' : 'NÃO',
                        valorUnitario.toFixed(2).replace('.', ','),
                        valorTotal.toFixed(2).replace('.', ',')
                    ];
                    
                    csv += linha.join(';') + '\n';
                });
                
                const totalDia = producoesDoDia.reduce((acc, prod) => {
                    const peca = pecas.find(p => p.id === prod.pecaId);
                    const valorBase = peca ? peca.valor : 0;
                    const valorUnit = prod.horaExtra ? valorBase * 1.5 : valorBase;
                    return acc + (valorUnit * prod.quantidade);
                }, 0);
                
                csv += ';;;;;;;SUBTOTAL DO DIA:;R$ ' + totalDia.toFixed(2).replace('.', ',') + '\n';
                csv += ';\n';
            });
            
            csv += '\n' + '='.repeat(100) + '\n';
            csv += 'RESUMO DO PERÍODO\n';
            csv += '='.repeat(100) + '\n\n';
            
            csv += `Total de Itens Produzidos: ${totalItens}\n`;
            csv += `Total de Dias com Produção: ${Object.keys(producoesPorData).length}\n`;
            csv += `Total de Dias com Hora Extra: ${totalHorasExtras}\n`;
            csv += `Total de Itens em Hora Extra: ${totalItensHoraExtra}\n`;
            csv += `Média Diária de Produção: ${(totalItens / Object.keys(producoesPorData).length).toFixed(2)}\n`;
            csv += `Valor Total Produzido: R$ ${totalValor.toFixed(2).replace('.', ',')}\n\n`;
            
            csv += '-'.repeat(100) + '\n';
            csv += 'PRODUÇÃO POR MODELO\n';
            csv += '-'.repeat(100) + '\n';
            csv += 'Modelo;Cor;Quantidade;Valor Unit.(R$);Valor Total(R$)\n';
            
            const producaoPorModelo = {};
            producoesMes.forEach(producao => {
                const peca = pecas.find(p => p.id === producao.pecaId);
                const cor = cores.find(c => c.id === producao.corId);
                const key = `${producao.pecaId}-${producao.corId}`;
                
                if (!producaoPorModelo[key]) {
                    producaoPorModelo[key] = {
                        modelo: peca ? peca.nome : 'N/A',
                        cor: cor ? cor.nome : 'Sem cor',
                        quantidade: 0,
                        valorUnitario: peca ? peca.valor : 0
                    };
                }
                
                producaoPorModelo[key].quantidade += producao.quantidade;
            });
            
            Object.values(producaoPorModelo).forEach(item => {
                const valorTotal = item.valorUnitario * item.quantidade;
                csv += `${item.modelo};${item.cor};${item.quantidade};${item.valorUnitario.toFixed(2).replace('.', ',')};${valorTotal.toFixed(2).replace('.', ',')}\n`;
            });
            
            csv += '\n' + '='.repeat(100) + '\n';
            csv += 'FIM DO RELATÓRIO\n';
            csv += '='.repeat(100) + '\n';
            
            const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            
            const nomeArquivo = `producao_${nomeFuncionario.replace(/[^\w\s]/gi, '').replace(/\s+/g, '_')}_${mes}_${ano}.csv`;
            link.setAttribute('download', nomeArquivo);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            alert(`✅ Relatório detalhado de ${nomeFuncionario} exportado com sucesso!`);
        }

        function exportarTodosFuncionarios() {
            const mesAno = document.getElementById('mesFolha').value;
            if (!mesAno) {
                alert('⚠️ Por favor, selecione o mês/ano.');
                return;
            }
            
            const [ano, mes] = mesAno.split('-');
            
            const dataInicio = `${ano}-${mes}-01`;
            const ultimoDia = new Date(ano, mes, 0).getDate();
            const dataFim = `${ano}-${mes}-${ultimoDia}`;
            
            const funcionariosComProducao = new Set();
            producoes.forEach(p => {
                if (p.data >= dataInicio && p.data <= dataFim) {
                    funcionariosComProducao.add(p.funcionarioId);
                }
            });
            
            if (funcionariosComProducao.size === 0) {
                alert('📭 Nenhum funcionário com produção no período.');
                return;
            }
            
            let contador = 0;
            Array.from(funcionariosComProducao).forEach(funcionarioId => {
                const funcionario = funcionarios.find(f => f.id == funcionarioId);
                if (funcionario) {
                    exportarProducaoFuncionarioDetalhado(funcionarioId, mes, ano, funcionario.nome);
                    contador++;
                }
            });
            
            setTimeout(() => {
                alert(`✅ ${contador} relatórios de funcionários foram exportados!`);
            }, 500);
        }

        // ============================================
        // FUNÇÕES DE BACKUP (mantidas)
        // ============================================

        async function criarBackup() {
            try {
                console.log('📦 Iniciando processo de backup...');
                
                const pastaResult = await window.electronAPI.backup.selecionarPasta();
                
                if (!pastaResult.success) {
                    if (pastaResult.canceled) {
                        alert('⏸️ Operação cancelada pelo usuário.');
                    } else {
                        alert('❌ Erro ao selecionar pasta: ' + pastaResult.error);
                    }
                    return;
                }
                
                const loadingMsg = document.createElement('div');
                loadingMsg.className = 'loading-spinner';
                loadingMsg.style.position = 'fixed';
                loadingMsg.style.top = '50%';
                loadingMsg.style.left = '50%';
                loadingMsg.style.transform = 'translate(-50%, -50%)';
                loadingMsg.style.zIndex = '10001';
                loadingMsg.style.width = '50px';
                loadingMsg.style.height = '50px';
                document.body.appendChild(loadingMsg);
                
                const resultado = await window.electronAPI.backup.criar(pastaResult.path);
                
                document.body.removeChild(loadingMsg);
                
                if (resultado.success) {
                    alert(
                        `✅ Backup criado com sucesso!\n\n` +
                        `📁 Arquivo: ${resultado.nome}\n` +
                        `📍 Local: ${resultado.caminho}\n` +
                        `📊 Tamanho: ${resultado.tamanho} bytes`
                    );
                } else {
                    alert('❌ Erro ao criar backup: ' + resultado.error);
                }
                
            } catch (error) {
                console.error('❌ Erro em criarBackup:', error);
                alert('❌ Erro inesperado: ' + error.message);
            }
        }

        async function restaurarBackup() {
            try {
                console.log('📦 Iniciando processo de restauração...');
                
                const confirmar = confirm(
                    '⚠️ ATENÇÃO: Restaurar um backup substituirá TODOS os dados atuais!\n\n' +
                    'O sistema será reiniciado automaticamente após a restauração.\n\n' +
                    'Deseja continuar?'
                );
                
                if (!confirmar) {
                    return;
                }
                
                const arquivoResult = await window.electronAPI.backup.selecionarArquivo([
                    { name: 'Arquivos de Backup', extensions: ['db'] }
                ]);
                
                if (!arquivoResult.success) {
                    if (arquivoResult.canceled) {
                        alert('⏸️ Operação cancelada pelo usuário.');
                    } else {
                        alert('❌ Erro ao selecionar arquivo: ' + arquivoResult.error);
                    }
                    return;
                }
                
                const loadingMsg = document.createElement('div');
                loadingMsg.className = 'loading-spinner';
                loadingMsg.style.position = 'fixed';
                loadingMsg.style.top = '50%';
                loadingMsg.style.left = '50%';
                loadingMsg.style.transform = 'translate(-50%, -50%)';
                loadingMsg.style.zIndex = '10001';
                loadingMsg.style.width = '50px';
                loadingMsg.style.height = '50px';
                document.body.appendChild(loadingMsg);
                
                const resultado = await window.electronAPI.backup.restaurar(arquivoResult.path);
                
                document.body.removeChild(loadingMsg);
                
                if (resultado.success) {
                    alert(
                        `✅ Backup restaurado com sucesso!\n\n` +
                        `🔄 O sistema será reiniciado em alguns segundos...`
                    );
                } else {
                    alert('❌ Erro ao restaurar backup: ' + resultado.error);
                }
                
            } catch (error) {
                console.error('❌ Erro em restaurarBackup:', error);
                alert('❌ Erro inesperado: ' + error.message);
            }
        }

        async function exportarJSON() {
            try {
                console.log('📦 Iniciando exportação JSON...');
                
                const pastaResult = await window.electronAPI.backup.selecionarPasta();
                
                if (!pastaResult.success) {
                    if (pastaResult.canceled) {
                        alert('⏸️ Operação cancelada pelo usuário.');
                    } else {
                        alert('❌ Erro ao selecionar pasta: ' + pastaResult.error);
                    }
                    return;
                }
                
                const loadingMsg = document.createElement('div');
                loadingMsg.className = 'loading-spinner';
                loadingMsg.style.position = 'fixed';
                loadingMsg.style.top = '50%';
                loadingMsg.style.left = '50%';
                loadingMsg.style.transform = 'translate(-50%, -50%)';
                loadingMsg.style.zIndex = '10001';
                loadingMsg.style.width = '50px';
                loadingMsg.style.height = '50px';
                document.body.appendChild(loadingMsg);
                
                const resultado = await window.electronAPI.backup.exportarJSON(pastaResult.path);
                
                document.body.removeChild(loadingMsg);
                
                if (resultado.success) {
                    alert(
                        `✅ JSON exportado com sucesso!\n\n` +
                        `📁 Arquivo: ${resultado.nome}\n` +
                        `📊 Total de registros: ${resultado.totalRegistros}\n` +
                        `📍 Local: ${resultado.caminho}`
                    );
                } else {
                    alert('❌ Erro ao exportar JSON: ' + resultado.error);
                }
                
            } catch (error) {
                console.error('❌ Erro em exportarJSON:', error);
                alert('❌ Erro inesperado: ' + error.message);
            }
        }

        async function importarJSON() {
            try {
                console.log('📦 Iniciando importação JSON...');
                
                const arquivoResult = await window.electronAPI.backup.selecionarArquivo([
                    { name: 'Arquivos JSON', extensions: ['json'] }
                ]);
                
                if (!arquivoResult.success) {
                    if (arquivoResult.canceled) {
                        alert('⏸️ Operação cancelada pelo usuário.');
                    } else {
                        alert('❌ Erro ao selecionar arquivo: ' + arquivoResult.error);
                    }
                    return;
                }
                
                const loadingMsg = document.createElement('div');
                loadingMsg.className = 'loading-spinner';
                loadingMsg.style.position = 'fixed';
                loadingMsg.style.top = '50%';
                loadingMsg.style.left = '50%';
                loadingMsg.style.transform = 'translate(-50%, -50%)';
                loadingMsg.style.zIndex = '10001';
                loadingMsg.style.width = '50px';
                loadingMsg.style.height = '50px';
                document.body.appendChild(loadingMsg);
                
                const verificacao = await window.electronAPI.backup.importarJSON(arquivoResult.path, false);
                
                if (verificacao.precisaConfirmacao) {
                    document.body.removeChild(loadingMsg);
                    
                    const metadata = verificacao.metadata;
                    const confirmar = confirm(
                        `📄 Arquivo: ${metadata.aplicacao}\n` +
                        `📅 Data: ${new Date(metadata.dataExportacao).toLocaleString()}\n` +
                        `📊 Total de registros: ${metadata.totalRegistros}\n\n` +
                        `⚠️ Deseja substituir os dados atuais por estes registros?`
                    );
                    
                    if (!confirmar) {
                        return;
                    }
                    
                    document.body.appendChild(loadingMsg);
                    
                    const resultado = await window.electronAPI.backup.importarJSON(arquivoResult.path, true);
                    
                    document.body.removeChild(loadingMsg);
                    
                    if (resultado.success) {
                        alert(
                            `✅ JSON importado com sucesso!\n\n` +
                            `📊 Total de registros importados: ${resultado.totalRegistros}`
                        );
                        
                        await DataManager.refreshData();
                        
                    } else {
                        alert('❌ Erro ao importar JSON: ' + resultado.error);
                    }
                } else {
                    document.body.removeChild(loadingMsg);
                    
                    if (!verificacao.success) {
                        alert('❌ Erro ao importar JSON: ' + verificacao.error);
                    }
                }
                
            } catch (error) {
                console.error('❌ Erro em importarJSON:', error);
                alert('❌ Erro inesperado: ' + error.message);
            }
        }

        // ============================================
        // FUNÇÕES DO DASHBOARD (mantidas)
        // ============================================

        async function mostrarEstatisticas() {
            const modal = document.getElementById('modalEstatisticas');
            const conteudo = document.getElementById('estatisticasConteudo');
            
            try {
                const stats = await calcularEstatisticasDashboard();
                
                let html = `
                    <div class="periodo-selector">
                        <button class="periodo-btn active" onclick="atualizarDashboard('7dias', event)">7 Dias</button>
                        <button class="periodo-btn" onclick="atualizarDashboard('30dias', event)">30 Dias</button>
                        <button class="periodo-btn" onclick="atualizarDashboard('mesAtual', event)">Mês Atual</button>
                        <button class="periodo-btn" onclick="atualizarDashboard('personalizado', event)">Personalizado</button>
                    </div>
                    
                    <div id="dataRangePersonalizado" style="display: none;" class="data-range">
                        <input type="date" id="dataInicioDash" class="form-control" value="${stats.ultimos7Dias.inicio}">
                        <input type="date" id="dataFimDash" class="form-control" value="${stats.ultimos7Dias.fim}">
                        <button class="btn-primary" onclick="aplicarDataPersonalizada()">Aplicar</button>
                    </div>
                    
                    <div class="kpi-grid">
                        <div class="kpi-card entrada">
                            <div class="kpi-icon">📥</div>
                            <div class="kpi-label">Total de Entradas</div>
                            <div class="kpi-number" id="totalEntradas">${stats.totalEntradas}</div>
                        </div>
                        <div class="kpi-card saida">
                            <div class="kpi-icon">📤</div>
                            <div class="kpi-label">Total de Saídas</div>
                            <div class="kpi-number" id="totalSaidas">${stats.totalSaidas}</div>
                        </div>
                        <div class="kpi-card producao">
                            <div class="kpi-icon">🏭</div>
                            <div class="kpi-label">Produções</div>
                            <div class="kpi-number" id="totalProducoes">${stats.totalProducoes}</div>
                        </div>
                        <div class="kpi-card estoque">
                            <div class="kpi-icon">📦</div>
                            <div class="kpi-label">Saldo Atual</div>
                            <div class="kpi-number" id="saldoAtual">${stats.saldoAtual}</div>
                        </div>
                    </div>
                    
                    <div class="dashboard-grid">
                        <div class="dashboard-card">
                            <h3>📊 Entradas vs Saídas (${stats.periodoAtual})</h3>
                            <div class="chart-container">
                                <canvas id="graficoEntradaSaida"></canvas>
                            </div>
                            <div class="stats-row">
                                <div class="stats-item">
                                    <div class="stats-value" id="mediaEntradas">${stats.mediaEntradas}</div>
                                    <div class="stats-label">Média Entradas/dia</div>
                                </div>
                                <div class="stats-item">
                                    <div class="stats-value" id="mediaSaidas">${stats.mediaSaidas}</div>
                                    <div class="stats-label">Média Saídas/dia</div>
                                </div>
                                <div class="stats-item">
                                    <div class="stats-value" id="totalMovimentacoes">${stats.totalMovimentacoes}</div>
                                    <div class="stats-label">Total Mov.</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="dashboard-card">
                            <h3>📈 Movimentações por Dia</h3>
                            <div class="chart-container">
                                <canvas id="graficoMovimentacoesDia"></canvas>
                            </div>
                            <div class="stats-row stats-total">
                                <div class="stats-item">
                                    <div class="stats-value" id="diaPico">${stats.diaPico.data}</div>
                                    <div class="stats-label">Dia de Pico</div>
                                </div>
                                <div class="stats-item">
                                    <div class="stats-value" id="movimentosPico">${stats.diaPico.total}</div>
                                    <div class="stats-label">Movimentações</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="dashboard-grid">
                        <div class="dashboard-card">
                            <h3>🏆 Top 5 Itens Mais Movimentados</h3>
                            <div class="chart-container" style="height: 250px;">
                                <canvas id="graficoTopItens"></canvas>
                            </div>
                            <div class="top-itens" id="listaTopItens">
                                ${gerarListaTopItens(stats.topItens)}
                            </div>
                        </div>
                        
                        <div class="dashboard-card">
                            <h3>👷 Produção por Funcionário</h3>
                            <div class="chart-container">
                                <canvas id="graficoProducaoFuncionarios"></canvas>
                            </div>
                            <div class="top-itens" id="listaTopFuncionarios">
                                ${gerarListaTopFuncionarios(stats.producaoFuncionarios)}
                            </div>
                        </div>
                    </div>
                `;
                
                conteudo.innerHTML = html;
                
                setTimeout(() => {
                    criarGraficoEntradaSaida(stats.dadosGrafico);
                    criarGraficoMovimentacoesDia(stats.movimentosPorDia);
                    criarGraficoTopItens(stats.topItens);
                    criarGraficoProducaoFuncionarios(stats.producaoFuncionarios);
                }, 100);
                
                window.dashboardData = stats;
                
            } catch (error) {
                console.error('Erro ao carregar dashboard:', error);
                conteudo.innerHTML = '<p style="color: #e74c3c; text-align: center; padding: 40px;">❌ Erro ao carregar dashboard</p>';
            }
            
            modal.style.display = 'flex';
        }

        async function calcularEstatisticasDashboard(periodo = '7dias', dataInicio = null, dataFim = null) {
            const hoje = new Date();
            let inicio = new Date(hoje);
            let fim = new Date(hoje);
            
            if (periodo === '7dias') {
                inicio.setDate(hoje.getDate() - 7);
            } else if (periodo === '30dias') {
                inicio.setDate(hoje.getDate() - 30);
            } else if (periodo === 'mesAtual') {
                inicio = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
                fim = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0);
            } else if (periodo === 'personalizado' && dataInicio && dataFim) {
                inicio = new Date(dataInicio);
                fim = new Date(dataFim);
            }
            
            const dataInicioStr = inicio.toISOString().split('T')[0];
            const dataFimStr = fim.toISOString().split('T')[0];
            
            const movPeriodo = movimentacoes.filter(m => 
                m.data >= dataInicioStr && m.data <= dataFimStr
            );
            
            const producoesPeriodo = producoes.filter(p => 
                p.data >= dataInicioStr && p.data <= dataFimStr
            );
            
            const totalEntradas = movPeriodo
                .filter(m => m.tipo === 'entrada')
                .reduce((acc, m) => acc + m.quantidade, 0);
            
            const totalSaidas = movPeriodo
                .filter(m => m.tipo === 'saida')
                .reduce((acc, m) => acc + m.quantidade, 0);
            
            const totalProducoes = producoesPeriodo.length;
            
            const saldoAtual = movimentacoes.reduce((acc, m) => 
                acc + (m.tipo === 'entrada' ? m.quantidade : -m.quantidade), 0
            );
            
            const diasMap = new Map();
            for (let d = new Date(inicio); d <= fim; d.setDate(d.getDate() + 1)) {
                const dataStr = d.toISOString().split('T')[0];
                diasMap.set(dataStr, { entrada: 0, saida: 0, total: 0 });
            }
            
            movPeriodo.forEach(mov => {
                if (diasMap.has(mov.data)) {
                    const dia = diasMap.get(mov.data);
                    dia[mov.tipo] += mov.quantidade;
                    dia.total += mov.quantidade;
                }
            });
            
            const diasArray = Array.from(diasMap.entries()).sort((a, b) => a[0].localeCompare(b[0]));
            
            const itensCount = {};
            movPeriodo.forEach(mov => {
                const key = `${mov.pecaId}-${mov.corId}`;
                if (!itensCount[key]) {
                    itensCount[key] = { total: 0, entradas: 0, saidas: 0, pecaId: mov.pecaId, corId: mov.corId };
                }
                itensCount[key].total += mov.quantidade;
                itensCount[key][mov.tipo + 's'] += mov.quantidade;
            });
            
            const topItens = Object.values(itensCount)
                .sort((a, b) => b.total - a.total)
                .slice(0, 5)
                .map(item => {
                    const peca = pecas.find(p => p.id === item.pecaId);
                    const cor = cores.find(c => c.id === item.corId);
                    return {
                        ...item,
                        pecaNome: peca?.nome || 'N/A',
                        corNome: cor?.nome || 'Sem cor',
                        valorTotal: (peca?.valor || 0) * item.total
                    };
                });
            
            const producaoPorFuncionario = {};
            producoesPeriodo.forEach(prod => {
                const funcId = prod.funcionarioId;
                if (!producaoPorFuncionario[funcId]) {
                    producaoPorFuncionario[funcId] = {
                        quantidade: 0,
                        valorTotal: 0,
                        dias: new Set()
                    };
                }
                
                const peca = pecas.find(p => p.id === prod.pecaId);
                const valorUnitarioBase = peca ? peca.valor : 0;
                const valorUnitario = prod.horaExtra ? valorUnitarioBase * 1.5 : valorUnitarioBase;
                const valorTotal = valorUnitario * prod.quantidade;
                
                producaoPorFuncionario[funcId].quantidade += prod.quantidade;
                producaoPorFuncionario[funcId].valorTotal += valorTotal;
                producaoPorFuncionario[funcId].dias.add(prod.data);
            });
            
            const producaoFuncionarios = Object.entries(producaoPorFuncionario)
                .map(([funcId, dados]) => {
                    const funcionario = funcionarios.find(f => f.id == funcId);
                    return {
                        id: funcId,
                        nome: funcionario?.nome || 'Funcionário Removido',
                        cargo: funcionario?.cargo || 'N/A',
                        quantidade: dados.quantidade,
                        valorTotal: dados.valorTotal,
                        diasTrabalhados: dados.dias.size
                    };
                })
                .sort((a, b) => b.valorTotal - a.valorTotal);
            
            let diaPico = { data: '', total: 0 };
            diasArray.forEach(([data, valores]) => {
                if (valores.total > diaPico.total) {
                    diaPico = { data: formatarData(data).slice(0,5), total: valores.total };
                }
            });
            
            return {
                totalEntradas,
                totalSaidas,
                totalProducoes,
                saldoAtual,
                mediaEntradas: diasArray.length > 0 ? (totalEntradas / diasArray.length).toFixed(1) : '0',
                mediaSaidas: diasArray.length > 0 ? (totalSaidas / diasArray.length).toFixed(1) : '0',
                totalMovimentacoes: movPeriodo.length,
                periodoAtual: periodo === '7dias' ? 'Últimos 7 dias' : 
                             periodo === '30dias' ? 'Últimos 30 dias' : 
                             periodo === 'mesAtual' ? 'Mês atual' : 'Período personalizado',
                dadosGrafico: {
                    labels: diasArray.map(([data]) => formatarData(data).slice(0,5)),
                    entradas: diasArray.map(([, v]) => v.entrada),
                    saidas: diasArray.map(([, v]) => v.saida)
                },
                movimentosPorDia: {
                    labels: diasArray.map(([data]) => formatarData(data).slice(0,5)),
                    valores: diasArray.map(([, v]) => v.total)
                },
                topItens: {
                    labels: topItens.map(item => `${item.pecaNome} (${item.corNome})`),
                    valores: topItens.map(item => item.total)
                },
                producaoFuncionarios: {
                    labels: producaoFuncionarios.map(f => f.nome.split(' ')[0] + (f.nome.split(' ')[1] ? ' ' + f.nome.split(' ')[1][0] + '.' : '')),
                    nomesCompletos: producaoFuncionarios.map(f => f.nome),
                    quantidades: producaoFuncionarios.map(f => f.quantidade),
                    valores: producaoFuncionarios.map(f => f.valorTotal),
                    detalhes: producaoFuncionarios
                },
                diaPico,
                ultimos7Dias: {
                    inicio: new Date(hoje.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                    fim: hojeISO()
                }
            };
        }

        function criarGraficoEntradaSaida(dados) {
            const ctx = document.getElementById('graficoEntradaSaida')?.getContext('2d');
            if (!ctx) return;
            
            if (entradaSaidaChart) {
                entradaSaidaChart.destroy();
            }
            
            entradaSaidaChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: dados.labels,
                    datasets: [
                        {
                            label: 'Entradas',
                            data: dados.entradas,
                            backgroundColor: '#27ae60',
                            borderRadius: 6,
                            barPercentage: 0.7
                        },
                        {
                            label: 'Saídas',
                            data: dados.saidas,
                            backgroundColor: '#e74c3c',
                            borderRadius: 6,
                            barPercentage: 0.7
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: {
                                usePointStyle: true,
                                boxWidth: 8
                            }
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                drawBorder: false,
                                color: 'rgba(0,0,0,0.05)'
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }

        function criarGraficoMovimentacoesDia(dados) {
            const ctx = document.getElementById('graficoMovimentacoesDia')?.getContext('2d');
            if (!ctx) return;
            
            if (movimentacoesPorDiaChart) {
                movimentacoesPorDiaChart.destroy();
            }
            
            movimentacoesPorDiaChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: dados.labels,
                    datasets: [{
                        label: 'Movimentações',
                        data: dados.valores,
                        borderColor: '#1abc9c',
                        backgroundColor: 'rgba(26, 188, 156, 0.1)',
                        tension: 0.4,
                        fill: true,
                        pointBackgroundColor: '#16a085',
                        pointBorderColor: '#fff',
                        pointBorderWidth: 2,
                        pointRadius: 4,
                        pointHoverRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: {
                                drawBorder: false
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }

        function criarGraficoTopItens(dados) {
            const ctx = document.getElementById('graficoTopItens')?.getContext('2d');
            if (!ctx) return;
            
            if (topItensChart) {
                topItensChart.destroy();
            }
            
            topItensChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: dados.labels,
                    datasets: [{
                        data: dados.valores,
                        backgroundColor: [
                            '#1abc9c',
                            '#3498db',
                            '#9b59b6',
                            '#f39c12',
                            '#e74c3c'
                        ],
                        borderWidth: 0,
                        hoverOffset: 8
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                            labels: {
                                boxWidth: 12,
                                padding: 15
                            }
                        }
                    },
                    cutout: '65%'
                }
            });
        }

        function criarGraficoProducaoFuncionarios(dados) {
            const ctx = document.getElementById('graficoProducaoFuncionarios')?.getContext('2d');
            if (!ctx) return;
            
            if (producaoFuncionariosChart) {
                producaoFuncionariosChart.destroy();
            }
            
            producaoFuncionariosChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: dados.labels,
                    datasets: [
                        {
                            label: 'Quantidade Produzida',
                            data: dados.quantidades,
                            backgroundColor: '#3498db',
                            borderRadius: 6,
                            barPercentage: 0.6,
                            yAxisID: 'y'
                        },
                        {
                            label: 'Valor Produzido (R$)',
                            data: dados.valores,
                            backgroundColor: '#f39c12',
                            borderRadius: 6,
                            barPercentage: 0.6,
                            yAxisID: 'y1'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'top',
                            labels: {
                                usePointStyle: true,
                                boxWidth: 8
                            }
                        },
                        tooltip: {
                            callbacks: {
                                label: (context) => {
                                    const label = context.dataset.label || '';
                                    const value = context.raw;
                                    if (context.dataset.label.includes('Valor')) {
                                        return `${label}: ${formatarMoeda(value)}`;
                                    }
                                    return `${label}: ${value} unidades`;
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            position: 'left',
                            title: {
                                display: true,
                                text: 'Quantidade'
                            },
                            grid: {
                                drawBorder: false
                            }
                        },
                        y1: {
                            beginAtZero: true,
                            position: 'right',
                            title: {
                                display: true,
                                text: 'Valor (R$)'
                            },
                            grid: {
                                drawOnChartArea: false
                            },
                            ticks: {
                                callback: (value) => formatarMoeda(value)
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }

        function gerarListaTopItens(topItens) {
            if (!topItens.labels || topItens.labels.length === 0) {
                return '<p class="text-center" style="padding: 20px;">Nenhum item movimentado no período</p>';
            }
            
            let html = '';
            for (let i = 0; i < topItens.labels.length; i++) {
                html += `
                    <div class="top-item">
                        <div class="position">${i + 1}</div>
                        <div class="info">
                            <div class="name">${topItens.labels[i]}</div>
                            <div class="details">${topItens.valores[i]} unidades</div>
                        </div>
                        <div class="value">
                            ${topItens.valores[i]}
                        </div>
                    </div>
                `;
            }
            return html;
        }

        function gerarListaTopFuncionarios(dados) {
            if (!dados.detalhes || dados.detalhes.length === 0) {
                return '<p class="text-center" style="padding: 20px;">Nenhuma produção no período</p>';
            }
            
            let html = '';
            dados.detalhes.slice(0, 5).forEach((func, index) => {
                html += `
                    <div class="top-item">
                        <div class="position">${index + 1}</div>
                        <div class="info">
                            <div class="name">${func.nome}</div>
                            <div class="details">${func.quantidade} itens • ${func.diasTrabalhados} dias</div>
                        </div>
                        <div class="value" style="color: #f39c12;">
                            ${formatarMoeda(func.valorTotal)}
                        </div>
                    </div>
                `;
            });
            return html;
        }

        async function atualizarDashboard(periodo, event) {
            if (event) {
                const botoes = document.querySelectorAll('.periodo-btn');
                botoes.forEach(btn => btn.classList.remove('active'));
                event.target.classList.add('active');
            }
            
            const dataRangeDiv = document.getElementById('dataRangePersonalizado');
            
            if (periodo === 'personalizado') {
                dataRangeDiv.style.display = 'grid';
                return;
            } else {
                dataRangeDiv.style.display = 'none';
            }
            
            const stats = await calcularEstatisticasDashboard(periodo);
            
            document.getElementById('totalEntradas').textContent = stats.totalEntradas;
            document.getElementById('totalSaidas').textContent = stats.totalSaidas;
            document.getElementById('totalProducoes').textContent = stats.totalProducoes;
            document.getElementById('saldoAtual').textContent = stats.saldoAtual;
            document.getElementById('mediaEntradas').textContent = stats.mediaEntradas;
            document.getElementById('mediaSaidas').textContent = stats.mediaSaidas;
            document.getElementById('totalMovimentacoes').textContent = stats.totalMovimentacoes;
            document.getElementById('diaPico').textContent = stats.diaPico.data;
            document.getElementById('movimentosPico').textContent = stats.diaPico.total;
            
            criarGraficoEntradaSaida(stats.dadosGrafico);
            criarGraficoMovimentacoesDia(stats.movimentosPorDia);
            criarGraficoTopItens(stats.topItens);
            criarGraficoProducaoFuncionarios(stats.producaoFuncionarios);
            
            document.getElementById('listaTopItens').innerHTML = gerarListaTopItens(stats.topItens);
            document.getElementById('listaTopFuncionarios').innerHTML = gerarListaTopFuncionarios(stats.producaoFuncionarios);
            
            window.dashboardData = stats;
        }

        async function aplicarDataPersonalizada() {
            const dataInicio = document.getElementById('dataInicioDash').value;
            const dataFim = document.getElementById('dataFimDash').value;
            
            if (!dataInicio || !dataFim) {
                alert('Selecione as datas de início e fim');
                return;
            }
            
            const stats = await calcularEstatisticasDashboard('personalizado', dataInicio, dataFim);
            
            document.getElementById('totalEntradas').textContent = stats.totalEntradas;
            document.getElementById('totalSaidas').textContent = stats.totalSaidas;
            document.getElementById('totalProducoes').textContent = stats.totalProducoes;
            document.getElementById('saldoAtual').textContent = stats.saldoAtual;
            document.getElementById('mediaEntradas').textContent = stats.mediaEntradas;
            document.getElementById('mediaSaidas').textContent = stats.mediaSaidas;
            document.getElementById('totalMovimentacoes').textContent = stats.totalMovimentacoes;
            document.getElementById('diaPico').textContent = stats.diaPico.data;
            document.getElementById('movimentosPico').textContent = stats.diaPico.total;
            
            criarGraficoEntradaSaida(stats.dadosGrafico);
            criarGraficoMovimentacoesDia(stats.movimentosPorDia);
            criarGraficoTopItens(stats.topItens);
            criarGraficoProducaoFuncionarios(stats.producaoFuncionarios);
            document.getElementById('listaTopItens').innerHTML = gerarListaTopItens(stats.topItens);
            document.getElementById('listaTopFuncionarios').innerHTML = gerarListaTopFuncionarios(stats.producaoFuncionarios);
            
            window.dashboardData = stats;
        }

        function fecharModalEstatisticas() {
            document.getElementById('modalEstatisticas').style.display = 'none';
            if (entradaSaidaChart) entradaSaidaChart.destroy();
            if (movimentacoesPorDiaChart) movimentacoesPorDiaChart.destroy();
            if (topItensChart) topItensChart.destroy();
            if (producaoFuncionariosChart) producaoFuncionariosChart.destroy();
        }

        function fecharComprovante() {
            document.getElementById('comprovanteSaida').classList.add('oculto');
        }

        function fecharComprovanteProducao() {
            document.getElementById('comprovanteProducao').classList.add('oculto');
        }

        function fecharModalSalvar() {
            document.getElementById('modalSalvar').style.display = 'none';
            document.getElementById('statusSalvar').innerHTML = '';
        }

        function salvarComprovante(tipo) {
            alert('Funcionalidade de salvar comprovante será implementada em breve.');
        }
